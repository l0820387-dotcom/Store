// ============================================================
// LOCAL JSON DATABASE (replaces Firebase)
// ============================================================
// Stores everything in JSON files under ./data/. This has ONE major
// tradeoff vs Firebase: on platforms like Railway, the filesystem is
// EPHEMERAL — every redeploy/restart wipes ./data/ and all data
// (products, orders, users, wallets) is permanently lost unless you
// download a backup first via the /backup admin command.
//
// All functions below mirror firebase.js's exact names and return
// shapes, so bot.js works with either module interchangeably.
// ============================================================

const fs = require('fs');
const path = require('path');

// Set DATA_DIR to a mounted persistent volume (e.g. /data on Railway) so data
// survives redeploys. Falls back to ./data (ephemeral on most PaaS).
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const FILES = {
  products: 'products.json',
  orders: 'orders.json',
  users: 'users.json',
  walletTransactions: 'walletTransactions.json',
  referralSettings: 'referralSettings.json',
  coupons: 'coupons.json',
  reviews: 'reviews.json',
  botSettings: 'botSettings.json',
  proPlanSettings: 'proPlanSettings.json',
  checkInSettings: 'checkInSettings.json',
  broadcastQueue: 'broadcastQueue.json',
  dmQueue: 'dmQueue.json',
  staff: 'staff.json',
  paymentSettings: 'paymentSettings.json',
  resellerSettings: 'resellerSettings.json'
};

// ---- Low-level file read/write with an in-process write queue so
// concurrent writes to the same file never race and corrupt data ----
const writeQueues = {};

function filePath(key) {
  return path.join(DATA_DIR, FILES[key]);
}

function readCollection(key) {
  const fp = filePath(key);
  if (!fs.existsSync(fp)) return {};
  try {
    const raw = fs.readFileSync(fp, 'utf8').trim();
    return raw ? JSON.parse(raw) : {};
  } catch (err) {
    console.error(`⚠️ Failed to read ${key}, treating as empty:`, err.message);
    return {};
  }
}

async function writeCollection(key, data) {
  const fp = filePath(key);
  const prev = writeQueues[key] || Promise.resolve();
  const next = prev.then(() => new Promise((resolve, reject) => {
    const tmp = fp + '.tmp';
    fs.writeFile(tmp, JSON.stringify(data, null, 2), (err) => {
      if (err) return reject(err);
      fs.rename(tmp, fp, (err2) => err2 ? reject(err2) : resolve());
    });
  }));
  writeQueues[key] = next.catch(() => {}); // don't let one failure jam the queue forever
  return next;
}

// Runs a read-modify-write cycle as ONE atomic step through the same
// per-collection queue used by writeCollection. This is critical: without
// it, two concurrent operations on the same collection (e.g. two products
// being created back-to-back, or an image-album debounce firing while
// another write is in flight) can both read the same stale snapshot and
// the second write silently discards the first — this was the root cause
// of products vanishing ("product not found") and other data loss.
// `mutator(collectionObj)` mutates the object in place (or returns a new one);
// its return value is passed back to the caller.
async function updateCollectionAtomic(key, mutator) {
  const prev = writeQueues[key] || Promise.resolve();
  const resultHolder = {};
  const next = prev.then(async () => {
    const current = readCollection(key);
    const result = await mutator(current);
    const toSave = result && result.__replaceWith !== undefined ? result.__replaceWith : current;
    await new Promise((resolve, reject) => {
      const fp = filePath(key);
      const tmp = fp + '.tmp';
      fs.writeFile(tmp, JSON.stringify(toSave, null, 2), (err) => {
        if (err) return reject(err);
        fs.rename(tmp, fp, (err2) => err2 ? reject(err2) : resolve());
      });
    });
    resultHolder.value = result && result.__value !== undefined ? result.__value : result;
  });
  writeQueues[key] = next.catch(() => {});
  await next;
  return resultHolder.value;
}

function generateId(prefix = '') {
  return prefix + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

// ================= USERS =================

async function getUser(telegramId) {
  const users = readCollection('users');
  return users[telegramId] || null;
}

async function createUserIfNotExists(telegramId, tgUser, referredByCode) {
  telegramId = String(telegramId);

  // Referral lookup happens outside the atomic block (read-only, fine to
  // race) — the actual user creation is the atomic part that matters.
  let referredBy = null;
  if (referredByCode) {
    const referrer = await getUserByReferralCode(referredByCode);
    if (referrer && referrer.telegramId != telegramId) {
      referredBy = referrer.telegramId;
    }
  }

  return updateCollectionAtomic('users', (users) => {
    if (users[telegramId]) return { __value: users[telegramId] };

    const newUser = {
      telegramId,
      name: tgUser.first_name || '',
      username: tgUser.username || '',
      joinedAt: Date.now(),
      walletBalance: 0,
      referralCode: generateReferralCode(telegramId),
      referredBy,
      hasFirstPurchase: false
    };
    users[telegramId] = newUser;
    return { __value: newUser };
  });
}

function generateReferralCode(telegramId) {
  return 'REF' + telegramId.toString().slice(-6);
}

async function getUserByReferralCode(code) {
  const users = readCollection('users');
  const entry = Object.entries(users).find(([, u]) => u.referralCode === code);
  if (!entry) return null;
  return { ...entry[1], telegramId: entry[0] };
}

async function getAllUsers() {
  return readCollection('users');
}

// ================= WALLET =================

async function getWalletBalance(telegramId) {
  const user = await getUser(telegramId);
  return user ? (user.walletBalance || 0) : 0;
}

async function creditWallet(telegramId, amount, reason) {
  telegramId = String(telegramId);
  const updated = await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return { __value: 0 }; // safety: user must exist
    const current = users[telegramId].walletBalance || 0;
    const newBalance = current + amount;
    users[telegramId].walletBalance = newBalance;
    return { __value: newBalance };
  });

  await logWalletTxn(telegramId, amount, 'credit', reason);
  return updated;
}

async function debitWallet(telegramId, amount, reason) {
  telegramId = String(telegramId);
  const updated = await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) throw new Error('USER_NOT_FOUND');
    const current = users[telegramId].walletBalance || 0;
    if (current < amount) {
      throw new Error('INSUFFICIENT_BALANCE');
    }
    const newBalance = current - amount;
    users[telegramId].walletBalance = newBalance;
    return { __value: newBalance };
  });

  await logWalletTxn(telegramId, amount, 'debit', reason);
  return updated;
}

async function logWalletTxn(telegramId, amount, type, reason) {
  const id = generateId('txn_');
  await updateCollectionAtomic('walletTransactions', (txns) => {
    txns[id] = { userId: String(telegramId), amount, type, reason, createdAt: Date.now() };
  });
}

// ================= USER BAN SYSTEM =================

async function banUser(telegramId, reason) {
  telegramId = String(telegramId);
  await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return;
    users[telegramId].banned = true;
    users[telegramId].banReason = reason || 'No reason given';
    users[telegramId].bannedAt = Date.now();
  });
}

async function unbanUser(telegramId) {
  telegramId = String(telegramId);
  await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return;
    users[telegramId].banned = false;
    users[telegramId].banReason = null;
    users[telegramId].bannedAt = null;
  });
}

async function isUserBanned(telegramId) {
  const user = await getUser(telegramId);
  return user ? !!user.banned : false;
}

// ================= PRODUCTS =================

async function getAllProducts(activeOnly = true) {
  const all = readCollection('products');
  if (!activeOnly) return all;

  const filtered = {};
  for (const [id, p] of Object.entries(all)) {
    if (p.active) filtered[id] = p;
  }
  return filtered;
}

async function getProductsByCategory(category) {
  const all = await getAllProducts(true);
  const filtered = {};
  for (const [id, p] of Object.entries(all)) {
    if (p.category === category) filtered[id] = p;
  }
  return filtered;
}

async function getAllCategories() {
  const all = await getAllProducts(true);
  const cats = new Set();
  Object.values(all).forEach(p => cats.add(p.category));
  return [...cats];
}

async function getProduct(productId) {
  const all = readCollection('products');
  return all[productId] || null;
}

async function searchProducts(query) {
  const all = await getAllProducts(true);
  const q = query.toLowerCase().trim();
  const results = {};
  for (const [id, p] of Object.entries(all)) {
    if (p.name && p.name.toLowerCase().includes(q)) results[id] = p;
  }
  return results;
}

async function createProduct(data) {
  const id = generateId('prod_');
  const product = { ...data, views: 0, active: true, createdAt: Date.now() };
  await updateCollectionAtomic('products', (products) => {
    products[id] = product;
  });
  return { id, ...product };
}

async function updateProduct(productId, updates) {
  return updateCollectionAtomic('products', (products) => {
    if (!products[productId]) return { __value: null };
    products[productId] = { ...products[productId], ...updates };
    return { __value: products[productId] };
  });
}

async function deleteProduct(productId) {
  await updateCollectionAtomic('products', (products) => {
    delete products[productId];
  });
}

async function incrementProductViews(productId) {
  await updateCollectionAtomic('products', (products) => {
    if (!products[productId]) return;
    products[productId].views = (products[productId].views || 0) + 1;
  });
}

async function decrementStock(productId) {
  return updateCollectionAtomic('products', (products) => {
    const p = products[productId];
    if (!p || p.stock === -1 || p.stock === undefined) return { __value: undefined };
    p.stock = Math.max(0, p.stock - 1);
    return { __value: p.stock };
  });
}

async function checkLowStock(productId) {
  const product = await getProduct(productId);
  if (!product || product.stock === -1 || product.stock === undefined) return null;

  const LOW_STOCK_THRESHOLD = 3;
  if (product.stock <= LOW_STOCK_THRESHOLD) {
    return { productName: product.name, stock: product.stock };
  }
  return null;
}

// ================= RATINGS & REVIEWS =================

async function addReview(productId, telegramId, userName, rating, comment) {
  const id = generateId('rev_');
  await updateCollectionAtomic('reviews', (reviews) => {
    if (!reviews[productId]) reviews[productId] = {};
    reviews[productId][id] = { userId: String(telegramId), userName, rating, comment: comment || '', createdAt: Date.now() };
  });
  return id;
}

async function getProductReviews(productId) {
  const reviews = readCollection('reviews');
  return reviews[productId] || {};
}

async function getProductAvgRating(productId) {
  const reviews = await getProductReviews(productId);
  const list = Object.values(reviews);
  if (list.length === 0) return { avg: 0, count: 0 };

  const sum = list.reduce((acc, r) => acc + (r.rating || 0), 0);
  return { avg: (sum / list.length).toFixed(1), count: list.length };
}

// ================= COUPONS =================

async function getCoupon(code) {
  const coupons = readCollection('coupons');
  return coupons[code.toUpperCase()] || null;
}

async function validateCoupon(code, orderAmount) {
  const coupon = await getCoupon(code);
  if (!coupon || !coupon.active) return { valid: false, reason: 'Invalid or inactive coupon' };

  if (coupon.expiresAt && Date.now() > coupon.expiresAt) {
    return { valid: false, reason: 'Coupon expired' };
  }
  if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
    return { valid: false, reason: 'Coupon usage limit reached' };
  }
  if (coupon.minAmount && orderAmount < coupon.minAmount) {
    return { valid: false, reason: `Minimum order amount ₹${coupon.minAmount} required` };
  }

  let discount = coupon.discountType === 'percent'
    ? Math.round((orderAmount * coupon.discountValue) / 100)
    : coupon.discountValue;

  discount = Math.min(discount, orderAmount);
  return { valid: true, discount, coupon };
}

async function incrementCouponUsage(code) {
  const key = code.toUpperCase();
  await updateCollectionAtomic('coupons', (coupons) => {
    if (!coupons[key]) return;
    coupons[key].usedCount = (coupons[key].usedCount || 0) + 1;
  });
}

async function createCoupon(code, data) {
  await updateCollectionAtomic('coupons', (coupons) => {
    coupons[code.toUpperCase()] = { ...data, usedCount: 0, active: true, createdAt: Date.now() };
  });
}

async function toggleCoupon(code, active) {
  const key = code.toUpperCase();
  await updateCollectionAtomic('coupons', (coupons) => {
    if (!coupons[key]) return;
    coupons[key].active = active;
  });
}

async function getAllCoupons() {
  return readCollection('coupons');
}

// ================= ORDERS =================

async function createOrder(orderData) {
  const id = generateId('ord_');
  // FamPay rejects order_id values with hyphens/underscores as order_id —
  // this clean alphanumeric ref is what gets sent to them.
  const payRef = 'ord' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  const order = { ...orderData, id, payRef, createdAt: Date.now(), status: 'pending' };

  await updateCollectionAtomic('orders', (orders) => {
    orders[id] = order;
  });
  return order;
}

async function updateOrderStatus(orderId, status, extra = {}) {
  await updateCollectionAtomic('orders', (orders) => {
    if (!orders[orderId]) return;
    orders[orderId] = { ...orders[orderId], status, ...extra };
  });
}

async function getOrder(orderId) {
  const orders = readCollection('orders');
  return orders[orderId] || null;
}

async function getOrderByPayRef(payRef) {
  const orders = readCollection('orders');
  const entry = Object.entries(orders).find(([, o]) => o.payRef === payRef);
  return entry ? { ...entry[1], id: entry[0] } : null;
}

async function getUserOrders(telegramId) {
  const orders = readCollection('orders');
  telegramId = String(telegramId);
  const filtered = {};
  for (const [id, o] of Object.entries(orders)) {
    if (String(o.userId) === telegramId) filtered[id] = o;
  }
  return filtered;
}

async function getAllOrders() {
  return readCollection('orders');
}

async function hasUserBoughtProduct(telegramId, productId) {
  const orders = await getUserOrders(telegramId);
  return Object.values(orders).some(o =>
    o.productId === productId && (o.status === 'paid' || o.status === 'delivered')
  );
}

async function getBoughtOrder(telegramId, productId) {
  const orders = await getUserOrders(telegramId);
  return Object.values(orders).find(o =>
    o.productId === productId && (o.status === 'paid' || o.status === 'delivered')
  ) || null;
}

// ================= SALES REPORTS =================

async function getSalesReport(periodDays) {
  const cutoff = Date.now() - (periodDays * 24 * 60 * 60 * 1000);
  const orders = readCollection('orders');
  const list = Object.values(orders).filter(o => o.createdAt >= cutoff && (o.status === 'paid' || o.status === 'delivered'));

  const totalSales = list.reduce((sum, o) => sum + (o.amount || 0), 0);
  const productCounts = {};
  list.forEach(o => { productCounts[o.productName] = (productCounts[o.productName] || 0) + 1; });

  const topProducts = Object.entries(productCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, count]) => `${name} (${count} sold)`);

  return { totalSales, orderCount: list.length, topProducts };
}

// ================= REFERRAL =================

async function getReferralSettings() {
  const s = readCollection('referralSettings');
  return Object.keys(s).length ? s : { bonusAmount: 20, bonusType: 'flat' };
}

async function setReferralSettings(data) {
  await writeCollection('referralSettings', data);
}

async function processReferralBonus(buyerTelegramId, orderAmount) {
  const buyer = await getUser(buyerTelegramId);
  if (!buyer || buyer.hasFirstPurchase || !buyer.referredBy) return;

  const settings = await getReferralSettings();
  let bonus = settings.bonusType === 'percent'
    ? Math.round((orderAmount * settings.bonusAmount) / 100)
    : settings.bonusAmount;

  await creditWallet(buyer.referredBy, bonus, 'referral_bonus');

  await updateCollectionAtomic('users', (users) => {
    if (users[String(buyerTelegramId)]) users[String(buyerTelegramId)].hasFirstPurchase = true;
  });

  return { referrerId: buyer.referredBy, bonus };
}

// ================= PRO PLAN / VIP =================

// ================= PAYMENT SETTINGS (FamPay + Binance) =================
// Lets the admin override the .env values from inside the bot — the .env
// values are used as the initial defaults on first run. Both gateways can
// be independently enabled/disabled — at least one should stay on, but we
// don't hard-enforce that here (the bot.js UI guards against showing zero
// payment options).

const DEFAULT_TC = '📜 *Payment Terms & Conditions*\n\n1. Payment is non-refundable once the product is delivered.\n2. Verification may take up to 30 seconds after you submit your UTR.\n3. Do not close this chat until you receive confirmation.\n4. In case of a failed payment, contact support with your UTR number.';

function defaultPaymentSettings() {
  return {
    // FamPay (automatic, UTR-based)
    fampayEnabled: true,
    apiKey: process.env.FAMPAY_API_KEY || '',
    baseUrl: process.env.FAMPAY_BASE_URL || 'https://payment-getaway-bot-production.up.railway.app',
    upiId: process.env.FAMPAY_UPI_ID || '',
    // Binance (manual, screenshot-review based)
    binanceEnabled: false,
    binanceId: process.env.BINANCE_ID || '',
    usdRate: Number(process.env.BINANCE_USD_RATE) || 90, // 1 USD = ₹90 default; admin-editable
    termsAndConditions: DEFAULT_TC
  };
}

async function getPaymentSettings() {
  const s = readCollection('paymentSettings');
  if (Object.keys(s).length) return { ...defaultPaymentSettings(), ...s };
  return defaultPaymentSettings();
}

async function updatePaymentSettings(updates) {
  return updateCollectionAtomic('paymentSettings', (current) => {
    const hasData = Object.keys(current).length > 0;
    const base = hasData ? current : defaultPaymentSettings();
    const merged = { ...base, ...updates };
    return { __replaceWith: merged, __value: merged };
  });
}

async function getProPlanSettings() {
  const s = readCollection('proPlanSettings');
  return Object.keys(s).length ? s : { price: 1499, durationDays: 30, active: true, description: '30 days of unlimited downloads' };
}

async function setProPlanSettings(data) {
  await writeCollection('proPlanSettings', data);
}

async function activateProPlan(telegramId, durationDays) {
  telegramId = String(telegramId);
  const now = Date.now();

  return updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return { __value: now + (durationDays * 24 * 60 * 60 * 1000) };
    const currentExpiry = (users[telegramId].vipExpiresAt && users[telegramId].vipExpiresAt > now) ? users[telegramId].vipExpiresAt : now;
    const newExpiry = currentExpiry + (durationDays * 24 * 60 * 60 * 1000);
    users[telegramId].isVip = true;
    users[telegramId].vipExpiresAt = newExpiry;
    users[telegramId].vipActivatedAt = now;
    return { __value: newExpiry };
  });
}

async function isUserVip(telegramId) {
  const user = await getUser(telegramId);
  if (!user || !user.isVip) return false;

  if (user.vipExpiresAt && user.vipExpiresAt < Date.now()) {
    await updateCollectionAtomic('users', (users) => {
      if (users[String(telegramId)]) users[String(telegramId)].isVip = false;
    });
    return false;
  }
  return true;
}

async function getVipDaysLeft(telegramId) {
  const user = await getUser(telegramId);
  if (!user || !user.isVip || !user.vipExpiresAt) return 0;
  const msLeft = user.vipExpiresAt - Date.now();
  return msLeft > 0 ? Math.ceil(msLeft / (24 * 60 * 60 * 1000)) : 0;
}

// ================= BOT SETTINGS (admin-editable) =================

async function getBotSettings() {
  const s = readCollection('botSettings');
  if (Object.keys(s).length) return s;
  return {
    welcomeMessage: '✨ *Welcome, {name}!* ✨\n\n💎 Quality you can count on, delivery you can rely on.\n\n🛍 *Curated Products* — paid & free\n💳 *Secure Payments* via UPI\n⚡ *Instant Delivery* after payment\n🛡 *Dedicated Support*, whenever you need it\n\n👇 Select an option below to begin',
    channels: [],
    supportTelegram: '',
    supportWhatsapp: '',
    botName: '',
    botDescription: '',
    maintenanceMode: false,
    maintenanceMessage: '🛠 Bot abhi maintenance mein hai. Thodi der baad try karo.',
    menuCustomButtons: [],
    menuLabels: {},
    menuColors: {},
    menuHidden: {}
  };
}

async function updateBotSettings(updates) {
  return updateCollectionAtomic('botSettings', (current) => {
    const hasData = Object.keys(current).length > 0;
    const base = hasData ? current : {
      welcomeMessage: '✨ *Welcome, {name}!* ✨\n\n💎 Quality you can count on, delivery you can rely on.\n\n🛍 *Curated Products* — paid & free\n💳 *Secure Payments* via UPI\n⚡ *Instant Delivery* after payment\n🛡 *Dedicated Support*, whenever you need it\n\n👇 Select an option below to begin',
      channels: [], supportTelegram: '', supportWhatsapp: '', botName: '', botDescription: '',
      maintenanceMode: false, maintenanceMessage: '🛠 Bot abhi maintenance mein hai. Thodi der baad try karo.',
      menuCustomButtons: [], menuLabels: {}, menuColors: {}, menuHidden: {}
    };
    const merged = { ...base, ...updates };
    return { __replaceWith: merged, __value: merged };
  });
}

// ================= DAILY CHECK-IN =================

async function getCheckInSettings() {
  const s = readCollection('checkInSettings');
  return Object.keys(s).length ? s : { active: true, rewardAmount: 5 };
}

async function setCheckInSettings(data) {
  await writeCollection('checkInSettings', data);
}

async function performCheckIn(telegramId) {
  const settings = await getCheckInSettings();
  if (!settings.active) return { success: false, reason: 'disabled' };

  const user = await getUser(telegramId);
  const today = new Date().toDateString();
  const lastCheckIn = user?.lastCheckInDate;

  if (lastCheckIn === today) {
    return { success: false, reason: 'already_checked_in', streak: user.checkInStreak || 0 };
  }

  const yesterday = new Date(Date.now() - 86400000).toDateString();
  const streak = (lastCheckIn === yesterday) ? (user.checkInStreak || 0) + 1 : 1;

  telegramId = String(telegramId);
  await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return;
    users[telegramId].lastCheckInDate = today;
    users[telegramId].checkInStreak = streak;
  });

  const bonus = Math.min(settings.rewardAmount * Math.ceil(streak / 3), settings.rewardAmount * 5);
  await creditWallet(telegramId, bonus, 'daily_checkin');

  return { success: true, streak, bonus };
}

// ================= LEADERBOARD =================

async function getTopBuyers(limit = 10) {
  const orders = readCollection('orders');
  const spendByUser = {};
  Object.values(orders).forEach(o => {
    if (o.status === 'paid' || o.status === 'delivered') {
      spendByUser[o.userId] = (spendByUser[o.userId] || 0) + (o.amount || 0);
    }
  });

  const users = readCollection('users');
  return Object.entries(spendByUser)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([uid, spent]) => ({ telegramId: uid, name: users[uid]?.name || 'Unknown', totalSpent: spent }));
}

async function getTopReferrers(limit = 10) {
  const users = readCollection('users');
  const referralCounts = {};
  Object.entries(users).forEach(([uid, u]) => {
    if (u.referredBy) referralCounts[u.referredBy] = (referralCounts[u.referredBy] || 0) + 1;
  });

  return Object.entries(referralCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([uid, count]) => ({ telegramId: uid, name: users[uid]?.name || 'Unknown', referralCount: count }));
}

// ================= USER ANALYTICS =================

async function getUserAnalytics(telegramId) {
  const user = await getUser(telegramId);
  if (!user) return null;

  const orders = await getUserOrders(telegramId);
  const orderList = Object.values(orders);
  const paidOrders = orderList.filter(o => o.status === 'paid' || o.status === 'delivered');
  const totalSpent = paidOrders.reduce((sum, o) => sum + (o.amount || 0), 0);

  const allUsers = await getAllUsers();
  const referredCount = Object.values(allUsers).filter(u => u.referredBy === String(telegramId)).length;

  return { ...user, totalOrders: orderList.length, completedOrders: paidOrders.length, totalSpent, referredCount };
}

// ================= BROADCAST / DM QUEUES =================
// bot.js originally listened to Firebase's real-time child_added/child_changed
// events for these. Local mode has no such push mechanism, so bot.js uses
// these direct functions instead (see the updated queue-processing section).

async function queueBroadcast(data) {
  const id = generateId('bc_');
  await updateCollectionAtomic('broadcastQueue', (queue) => {
    queue[id] = { ...data, id, sent: false, createdAt: Date.now() };
  });
  return id;
}

async function queueDm(data) {
  const id = generateId('dm_');
  await updateCollectionAtomic('dmQueue', (queue) => {
    queue[id] = { ...data, id, sent: false, createdAt: Date.now() };
  });
  return id;
}

async function getBroadcastQueue() { return readCollection('broadcastQueue'); }
async function getDmQueue() { return readCollection('dmQueue'); }

async function updateBroadcastEntry(id, updates) {
  await updateCollectionAtomic('broadcastQueue', (queue) => {
    if (!queue[id]) return;
    queue[id] = { ...queue[id], ...updates };
  });
}

async function updateDmEntry(id, updates) {
  await updateCollectionAtomic('dmQueue', (queue) => {
    if (!queue[id]) return;
    queue[id] = { ...queue[id], ...updates };
  });
}

async function deleteBroadcastEntry(id) {
  await updateCollectionAtomic('broadcastQueue', (queue) => {
    delete queue[id];
  });
}

async function deleteDmEntry(id) {
  await updateCollectionAtomic('dmQueue', (queue) => {
    delete queue[id];
  });
}


// ================= ATOMIC ORDER HELPERS =================
// Compare-and-set style update: applies `updater(order)` only if
// `predicate(order)` is true, all inside ONE queued read-modify-write.
// Returns the updated order, or null if the order is missing / predicate
// failed. This is what stops double-delivery when the payment poller, a
// webhook and an admin tap all race on the same order.
async function updateOrderIf(orderId, predicate, updater) {
  return updateCollectionAtomic('orders', (orders) => {
    const o = orders[orderId];
    if (!o || !predicate(o)) return { __value: null };
    orders[orderId] = { ...o, ...(typeof updater === 'function' ? updater(o) : updater) };
    return { __value: { ...orders[orderId], id: orderId } };
  });
}

async function updateOrder(orderId, updates) {
  return updateOrderIf(orderId, () => true, updates);
}

async function getOrdersWhere(predicate) {
  const orders = readCollection('orders');
  return Object.entries(orders)
    .filter(([, o]) => predicate(o))
    .map(([id, o]) => ({ ...o, id }));
}

async function adjustStock(productId, delta) {
  return updateCollectionAtomic('products', (products) => {
    const p = products[productId];
    if (!p || p.stock === -1 || p.stock === undefined) return { __value: undefined };
    p.stock = Math.max(0, p.stock + delta);
    return { __value: p.stock };
  });
}

// ================= RESELLER (Qamify) SETTINGS =================

function defaultResellerSettings() {
  return {
    enabled: !!process.env.QAMIFY_API_KEY,
    apiKey: process.env.QAMIFY_API_KEY || '',
    baseUrl: process.env.QAMIFY_BASE_URL || 'https://api.qamify.site',
    usdRate: 0,               // 0 = reuse Payment Settings USD rate
    markupType: 'percent',    // 'percent' | 'flat' (flat = INR per unit)
    markupValue: 30,
    autoSync: true,
    syncIntervalMin: 10,
    autoPublish: false,       // newly imported products start hidden until admin reviews price
    defaultCategory: '🔑 Premium Accounts',
    lowBalanceUsd: 5,         // alert admins when Qamify balance falls below this
    maxQtyPerOrder: 20,       // bot-side cap on top of the API's own max_qty
    lastSyncAt: 0,
    lastSyncStats: null,
    lastBalanceCents: null,
    lastBalanceAt: 0,
    lastError: null
  };
}

async function getResellerSettings() {
  const s = readCollection('resellerSettings');
  return { ...defaultResellerSettings(), ...s };
}

async function updateResellerSettings(updates) {
  return updateCollectionAtomic('resellerSettings', (current) => {
    const base = Object.keys(current).length ? current : {};
    const merged = { ...defaultResellerSettings(), ...base, ...updates };
    return { __replaceWith: merged, __value: merged };
  });
}

// Upserts the whole Qamify catalog in ONE atomic write (never sync by name —
// ids are stable, names/prices change; see Qamify docs "Best practices").
// `items` = [{ qamifyId, fields, priceInr, meta }]. Admin edits to locked
// fields (name/description/category/price) are never overwritten.
async function upsertQamifyProducts(items, { autoPublish = false, defaultCategory = 'Reseller', seenIds = [], partial = false } = {}) {
  const stats = { added: 0, updated: 0, disabled: 0, restored: 0, total: items.length, priceChanges: [] };
  const seen = new Set(seenIds.map(String));

  await updateCollectionAtomic('products', (products) => {
    for (const it of items) {
      const key = 'prod_qm' + it.qamifyId;
      const existing = products[key];
      const q = it.meta; // upstream snapshot

      if (!existing) {
        products[key] = {
          name: it.fields.name,
          description: it.fields.description,
          category: defaultCategory,
          price: it.priceInr,
          stock: q.stock,
          active: !!autoPublish,
          views: 0,
          deliveryType: 'qamify',
          source: 'qamify',
          qamifyId: it.qamifyId,
          emoji: it.fields.emoji || '',
          instructions: it.fields.instructions || '',
          lockedFields: [],
          notifiedNewProduct: true, // silent import — never spam users with 50 "new product" pushes
          createdAt: Date.now(),
          qamify: q
        };
        stats.added++;
        continue;
      }

      const locked = new Set(existing.lockedFields || []);
      const next = { ...existing, qamify: q, stock: q.stock, emoji: it.fields.emoji || existing.emoji || '', instructions: it.fields.instructions || '' };
      if (!locked.has('name')) next.name = it.fields.name;
      if (!locked.has('description')) next.description = it.fields.description;
      if (!locked.has('price')) {
        if (existing.price !== it.priceInr) stats.priceChanges.push({ name: next.name, from: existing.price, to: it.priceInr });
        next.price = it.priceInr;
      }
      // Came back after being auto-hidden → restore (never re-enable admin-disabled products)
      if (existing.autoDisabled && !existing.ignored) {
        next.active = true; next.autoDisabled = false; stats.restored++;
      }
      products[key] = next;
      stats.updated++;
    }

    // Products that vanished upstream: auto-hide (keeps order history intact).
    // Skipped for partial (single-product) refreshes.
    if (!partial) for (const [key, p] of Object.entries(products)) {
      if (p.source !== 'qamify' || seen.has(String(p.qamifyId))) continue;
      if (p.active) { p.active = false; p.autoDisabled = true; stats.disabled++; }
      p.stock = 0;
    }
  });

  return stats;
}

async function getQamifyProducts() {
  const all = readCollection('products');
  return Object.entries(all).filter(([, p]) => p.source === 'qamify').map(([id, p]) => ({ ...p, id }));
}

// ================= BACKUP / RESTORE =================
// Since local storage can vanish on redeploy, these let an admin export
// everything to a single JSON file (and re-import it after a redeploy).

function getFullBackup() {
  const backup = {};
  for (const key of Object.keys(FILES)) {
    backup[key] = readCollection(key);
  }
  backup._exportedAt = new Date().toISOString();
  return backup;
}

async function restoreFromBackup(backupObj) {
  for (const key of Object.keys(FILES)) {
    if (backupObj[key]) {
      await writeCollection(key, backupObj[key]);
    }
  }
}

// ================= ADMIN CHECK =================

function isAdmin(telegramId) {
  const adminIds = (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim());
  return adminIds.includes(String(telegramId));
}

// ================= MISC USER FIELD HELPERS =================
// Generic get/set for one-off per-user fields bot.js needs (seen-tracking
// markers, pending deep-link state) — avoids needing a dedicated function
// for every small piece of transient state.

async function setUserField(telegramId, field, value) {
  telegramId = String(telegramId);
  await updateCollectionAtomic('users', (users) => {
    if (!users[telegramId]) return;
    users[telegramId][field] = value;
  });
}

async function getUserField(telegramId, field) {
  const user = await getUser(telegramId);
  return user ? user[field] : undefined;
}

async function clearUserField(telegramId, field) {
  await setUserField(telegramId, field, null);
}

async function getUserWalletTransactions(telegramId) {
  const txns = readCollection('walletTransactions');
  telegramId = String(telegramId);
  return Object.values(txns).filter(t => String(t.userId) === telegramId);
}

async function getPendingOrdersByMethod(paymentMethod, sinceTimestamp) {
  const orders = readCollection('orders');
  return Object.entries(orders).filter(([id, o]) =>
    o.status === 'pending' &&
    o.paymentMethod === paymentMethod &&
    (!sinceTimestamp || o.createdAt >= sinceTimestamp)
  );
}

// Binance orders awaiting manual admin screenshot review.
async function getBinancePendingReview() {
  const orders = readCollection('orders');
  return Object.entries(orders)
    .filter(([, o]) => o.paymentMethod === 'binance' && o.status === 'pending_review')
    .sort((a, b) => (a[1].createdAt || 0) - (b[1].createdAt || 0));
}

// ================= STAFF SYSTEM =================
// Staff are non-owner admins with limited permissions (managed via a
// separate list from ADMIN_TELEGRAM_IDS, which remains the full-owner list).

async function getAllStaff() {
  const s = readCollection('staff');
  return s;
}

async function addStaff(telegramId, permissions) {
  await updateCollectionAtomic('staff', (staff) => {
    staff[String(telegramId)] = {
      telegramId: String(telegramId),
      permissions: permissions || ['products', 'orders'], // default limited scope
      addedAt: Date.now()
    };
  });
}

async function removeStaff(telegramId) {
  await updateCollectionAtomic('staff', (staff) => {
    delete staff[String(telegramId)];
  });
}

async function isStaff(telegramId) {
  const staff = readCollection('staff');
  return !!staff[String(telegramId)];
}

async function getStaffPermissions(telegramId) {
  const staff = readCollection('staff');
  return staff[String(telegramId)]?.permissions || [];
}

module.exports = {
  updateOrderIf,
  updateOrder,
  getOrdersWhere,
  adjustStock,
  getResellerSettings,
  updateResellerSettings,
  upsertQamifyProducts,
  getQamifyProducts,
  getUser,
  createUserIfNotExists,
  getUserByReferralCode,
  getAllUsers,
  getWalletBalance,
  creditWallet,
  debitWallet,
  banUser,
  unbanUser,
  isUserBanned,
  getAllProducts,
  getProductsByCategory,
  getAllCategories,
  getProduct,
  searchProducts,
  createProduct,
  updateProduct,
  deleteProduct,
  incrementProductViews,
  decrementStock,
  checkLowStock,
  addReview,
  getProductReviews,
  getProductAvgRating,
  getCoupon,
  validateCoupon,
  incrementCouponUsage,
  createCoupon,
  toggleCoupon,
  getAllCoupons,
  createOrder,
  updateOrderStatus,
  getOrder,
  getOrderByPayRef,
  getUserOrders,
  getAllOrders,
  hasUserBoughtProduct,
  getBoughtOrder,
  getSalesReport,
  getReferralSettings,
  setReferralSettings,
  processReferralBonus,
  getPaymentSettings,
  updatePaymentSettings,
  getProPlanSettings,
  setProPlanSettings,
  activateProPlan,
  isUserVip,
  getVipDaysLeft,
  getBotSettings,
  updateBotSettings,
  getCheckInSettings,
  setCheckInSettings,
  performCheckIn,
  getTopBuyers,
  getTopReferrers,
  getUserAnalytics,
  queueBroadcast,
  queueDm,
  getBroadcastQueue,
  getDmQueue,
  updateBroadcastEntry,
  updateDmEntry,
  deleteBroadcastEntry,
  deleteDmEntry,
  getFullBackup,
  restoreFromBackup,
  setUserField,
  getUserField,
  clearUserField,
  getUserWalletTransactions,
  getPendingOrdersByMethod,
  getBinancePendingReview,
  getAllStaff,
  addStaff,
  removeStaff,
  isStaff,
  getStaffPermissions,
  isAdmin
};
