// Full bot flow with stubbed telegraf/express/axios (run with NODE_PATH pointing at stubs)
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'e2e-'));
process.env.ADMIN_TELEGRAM_IDS = '999';
process.env.BOT_TOKEN = 'x';

const up = { orders: {}, posts: 0, balance: 100000, products: [
  { id: 10, name: 'Example account', description: 'desc', instructions: 'Sign in.', unit_price_cents: 39, stock: 50, min_qty: 1, max_qty: 0, units_per_item: 1, order_cooldown_sec: 0 }
]};
const J = (res, c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const server = http.createServer((req, res) => {
  let b = ''; req.on('data', d => b += d); req.on('end', () => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/v1/products') return J(res, 200, { ok: true, products: up.products });
    const pm = u.pathname.match(/^\/v1\/products\/(\d+)$/);
    if (pm) return J(res, 200, { ok: true, product: up.products.find(p => p.id == pm[1]) });
    if (u.pathname === '/v1/balance') return J(res, 200, { ok: true, balance_cents: up.balance });
    const im = u.pathname.match(/^\/v1\/orders\/by-idempotency\/(.+)$/);
    if (im) return up.orders[im[1]] ? J(res, 200, { ok: true, order: up.orders[im[1]] }) : J(res, 404, { ok: false, error: { code: 'order_not_found', message: 'nf' } });
    if (u.pathname === '/v1/orders' && req.method === 'POST') {
      up.posts++;
      const key = req.headers['idempotency-key']; const body = JSON.parse(b);
      const p = up.products.find(x => x.id === body.product_id);
      up.orders[key] = { code: 'RA-' + up.posts, product_id: body.product_id, qty: body.qty, unit_price_cents: p.unit_price_cents, total_cents: p.unit_price_cents * body.qty, status: 'completed', items: Array.from({ length: body.qty }, (_, i) => ({ content: `acc${i}:pw${i}` })), instructions: 'Sign in.' };
      up.balance -= up.orders[key].total_cents;
      return J(res, 201, { ok: true, order: up.orders[key], balance_cents: up.balance });
    }
    J(res, 404, { ok: false, error: { code: 'not_found', message: 'nf' } });
  });
});

let mod, fb, tg;
function ctxFor(id, extra = {}) {
  const replies = [];
  const c = { from: { id, first_name: 'T' }, replies,
    callbackQuery: { message: {} }, match: extra.match,
    answerCbQuery: async (t, o) => { replies.push({ cb: t, o }); },
    editMessageText: async (t, o) => { replies.push({ text: t, o }); return { message_id: 1 }; },
    reply: async (t, o) => { replies.push({ text: t, o }); return { chat: { id }, message_id: 2 }; },
    replyWithPhoto: async (p, o) => { replies.push({ photo: p, o }); return { chat: { id }, message_id: 3, photo: [1] }; },
    replyWithDocument: async () => ({}), deleteMessage: async () => {}, editMessageCaption: async () => {} };
  return c;
}
async function tap(id, data) {
  for (const [pat, fn] of tg.actions) {
    const m = typeof pat === 'string' ? (pat === data ? [data] : null) : data.match(pat);
    if (m) { const c = ctxFor(id, { match: m }); await fn(c); return c; }
  }
  throw new Error('no handler for ' + data);
}
const say = async (id, text) => { const c = ctxFor(id); c.message = { text }; await tg.ons.text(c); return c; };
const sentTo = (id) => tg.calls.filter(x => x.name === 'sendMessage' && String(x.a[0]) === String(id)).map(x => x.a[1]).join('\n');

test.before(async () => {
  await new Promise(r => server.listen(0, r));
  process.env.QAMIFY_BASE_URL = `http://127.0.0.1:${server.address().port}`;
  fb = require('../localdb');
  mod = require('../bot.js');
  tg = require('telegraf').__state.bot;
  await fb.updateResellerSettings({ enabled: true, apiKey: 'shop_' + 'b'.repeat(48), baseUrl: process.env.QAMIFY_BASE_URL, markupType: 'percent', markupValue: 30, usdRate: 90, autoPublish: true });
  await fb.updatePaymentSettings({ upiId: 'a@fam', apiKey: 'k' });
  await fb.createUserIfNotExists('111', { first_name: 'Buyer' });
  await fb.creditWallet('111', 500, 'test');
  await require('../reseller').syncCatalog();
});
test.after(() => { server.close(); setTimeout(() => process.exit(0), 50); });

test('browse: category button uses short hash id, reseller label shows price', async () => {
  const c = await tap(111, 'menu_browse');
  const kb = c.replies.at(-1).o.reply_markup.inline_keyboard;
  const catBtn = kb[0][0];
  assert.match(catBtn.callback_data, /^cat_[0-9a-f]{10}$/);
  const c2 = await tap(111, catBtn.callback_data);
  const label = c2.replies.at(-1).o.reply_markup.inline_keyboard[0][0].text;
  assert.match(label, /Example account \| ₹46/);
});

test('wallet purchase ×2 via qty picker → 2 credentials delivered, wallet debited once', async () => {
  const b = await tap(111, 'buy_prod_qm10');
  assert.match(b.replies.at(-1).text, /Select Quantity/);
  await tap(111, 'qtyset_prod_qm10_2');
  const go = await tap(111, 'qtygo_prod_qm10');
  assert.match(go.replies.at(-1).text, /₹46 × 2 = ₹92/);
  const before = await fb.getWalletBalance('111'); up.posts = 0;
  await tap(111, 'paywallet_prod_qm10');
  assert.equal(await fb.getWalletBalance('111'), before - 92);
  assert.equal(up.posts, 1);
  const msgs = sentTo(111);
  assert.ok(msgs.includes('acc0:pw0') && msgs.includes('acc1:pw1'));
  const orders = await fb.getOrdersWhere(o => o.isQamify && o.userId === '111');
  assert.equal(orders[0].status, 'delivered');
});

test('repeat purchase of same reseller product is allowed (not blocked as "already bought")', async () => {
  const b = await tap(111, 'buy_prod_qm10');
  assert.match(b.replies.at(-1).text, /Select Quantity/);
});

test('double-tap wallet pay only charges once', async () => {
  await tap(111, 'qtyset_prod_qm10_1');
  const before = await fb.getWalletBalance('111'); up.posts = 0;
  await Promise.all([tap(111, 'paywallet_prod_qm10'), tap(111, 'paywallet_prod_qm10')]);
  assert.equal(await fb.getWalletBalance('111'), before - 46);
  assert.equal(up.posts, 1);
});

test('FamPay: poller + duplicate settle race → exactly ONE Qamify purchase', async () => {
  await fb.creditWallet('111', 0, 'noop');
  await tap(111, 'qtyset_prod_qm10_1');
  await tap(111, 'agreepay_prod_qm10');
  const [order] = await fb.getOrdersWhere(o => o.paymentMethod === 'fampay' && o.status === 'pending');
  assert.ok(order, 'fampay order created');
  await fb.updateOrder(order.id, { famTxnId: 'TXN1', utr: '123456789012' });
  up.posts = 0;
  await Promise.all([mod.checkAndProcessOrder(order.id), mod.checkAndProcessOrder(order.id), mod.checkAndProcessOrder(order.id)]);
  assert.equal(up.posts, 1, 'no double purchase');
  assert.equal((await fb.getOrder(order.id)).status, 'delivered');
});

test('FamPay order with submitted UTR is NOT auto-cancelled / cancellable mid-verification', async () => {
  await tap(111, 'agreepay_prod_qm10');
  const list = await fb.getOrdersWhere(o => o.paymentMethod === 'fampay' && o.status === 'pending');
  const order = list[0];
  await fb.updateOrder(order.id, { famTxnId: 'TXN9' });
  const c = await tap(111, `cancelorder_${order.id}`);
  assert.equal((await fb.getOrder(order.id)).status, 'pending');
  assert.ok(c.replies.some(r => /verify ho raha/.test(r.cb || '')));
});

test("someone else's order can't be cancelled", async () => {
  const [order] = await fb.getOrdersWhere(o => o.status === 'pending' && !o.famTxnId).then(l => l.length ? l : fb.getOrdersWhere(o => o.status === 'pending'));
  const c = await tap(222, `cancelorder_${order.id}`);
  assert.equal((await fb.getOrder(order.id)).status, 'pending');
});

test('duplicate UTR rejected', async () => {
  const [o1] = await fb.getOrdersWhere(o => o.status === 'delivered' && o.utr === '123456789012');
  assert.ok(o1);
  await tap(111, 'agreepay_prod_qm10');
  const [fresh] = await fb.getOrdersWhere(o => o.paymentMethod === 'fampay' && o.status === 'pending' && !o.famTxnId);
  mod.userState[111] = { step: 'awaiting_utr', data: { orderId: fresh.id } };
  const c = await say(111, '123456789012');
  assert.match(c.replies.at(-1).text, /pehle hi/);
});

test('redeliver reseller order re-sends stored credentials', async () => {
  const [o] = await fb.getOrdersWhere(o => o.isQamify && o.status === 'delivered' && o.userId === '111');
  tg.calls.length = 0;
  await tap(111, `redeliver_${o.id}`);
  assert.ok(sentTo(111).includes('acc0:pw0'));
});
