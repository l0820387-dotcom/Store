// Run: node --test test/
const test = require('node:test');
const assert = require('node:assert');
const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');

process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'qm-'));
process.env.ADMIN_TELEGRAM_IDS = '999';
process.env.QAMIFY_API_KEY = 'shop_' + 'a'.repeat(48);

// ---------- mock Qamify server ----------
const srv = { orders: {}, balance: 1000, postCalls: 0, mode: 'ok', products: [
  { id: 10, name: 'Example account', description: 'd', instructions: 'Sign in.', unit_price_cents: 39, stock: 50, min_qty: 1, max_qty: 0, units_per_item: 1, order_cooldown_sec: 0, emoji: '🔑' },
  { id: 11, name: 'Other', description: '', instructions: '', unit_price_cents: 100, stock: 5, min_qty: 1, max_qty: 3, units_per_item: 1, order_cooldown_sec: 600 }
]};
const json = (res, code, obj, headers = {}) => { res.writeHead(code, { 'Content-Type': 'application/json', ...headers }); res.end(JSON.stringify(obj)); };
const server = http.createServer((req, res) => {
  let body = ''; req.on('data', c => body += c);
  req.on('end', () => {
    const url = new URL(req.url, 'http://x');
    if (!req.headers.authorization?.startsWith('Bearer shop_')) return json(res, 401, { ok: false, error: { code: 'invalid_key', message: 'bad key' } });
    if (url.pathname === '/v1/products') return json(res, 200, { ok: true, products: srv.products });
    const pm = url.pathname.match(/^\/v1\/products\/(\d+)$/);
    if (pm) { const p = srv.products.find(x => x.id == pm[1]); return p ? json(res, 200, { ok: true, product: p }) : json(res, 404, { ok: false, error: { code: 'product_not_found', message: 'nf' } }); }
    if (url.pathname === '/v1/balance') return json(res, 200, { ok: true, balance_cents: srv.balance });
    const im = url.pathname.match(/^\/v1\/orders\/by-idempotency\/(.+)$/);
    if (im) { const o = srv.orders[im[1]]; return o ? json(res, 200, { ok: true, order: { ...o, replayed: true } }) : json(res, 404, { ok: false, error: { code: 'order_not_found', message: 'nf' } }); }
    if (url.pathname === '/v1/orders' && req.method === 'POST') {
      srv.postCalls++;
      const key = req.headers['idempotency-key'];
      const b = JSON.parse(body);
      if (srv.orders[key]) return json(res, 200, { ok: true, order: { ...srv.orders[key], replayed: true }, balance_cents: srv.balance });
      if (srv.mode === 'oos') return json(res, 409, { ok: false, error: { code: 'out_of_stock', message: 'oos' } });
      if (srv.mode === 'cooldown') return json(res, 429, { ok: false, error: { code: 'cooldown', message: 'c', retry_after_seconds: 60 } }, { 'Retry-After': '60' });
      if (srv.mode === 'fail500_first' && srv.postCalls === 1) return json(res, 500, { ok: false, error: { code: 'internal_error', message: 'boom' } });
      const p = srv.products.find(x => x.id === b.product_id);
      const commit = () => {
        srv.orders[key] = { code: 'RA-' + Object.keys(srv.orders).length, idempotency_key: key, product_id: b.product_id, qty: b.qty, unit_price_cents: p.unit_price_cents, total_cents: p.unit_price_cents * b.qty, status: 'completed', replayed: false, items: Array.from({ length: b.qty }, (_, i) => ({ content: `user${i}:pass${i}` })), instructions: 'Sign in.' };
        srv.balance -= srv.orders[key].total_cents;
      };
      if (srv.mode === 'commit_then_500') { commit(); return json(res, 500, { ok: false, error: { code: 'internal_error', message: 'lost' } }); }
      commit();
      return json(res, 201, { ok: true, order: srv.orders[key], balance_cents: srv.balance, balance: '' });
    }
    json(res, 404, { ok: false, error: { code: 'not_found', message: 'nf' } });
  });
});

// ---------- fake telegram ----------
const sent = [];
const fakeBot = { telegram: {
  sendMessage: async (id, text, extra) => { sent.push({ id: String(id), text, extra }); return {}; },
  sendDocument: async (id, doc) => { sent.push({ id: String(id), doc: true }); return {}; }
} };

let fb, reseller, port;
test.before(async () => {
  await new Promise(r => server.listen(0, r));
  port = server.address().port;
  process.env.QAMIFY_BASE_URL = `http://127.0.0.1:${port}`;
  fb = require('../localdb');
  reseller = require('../reseller');
  await fb.updateResellerSettings({ enabled: true, apiKey: process.env.QAMIFY_API_KEY, baseUrl: process.env.QAMIFY_BASE_URL, markupType: 'percent', markupValue: 30, usdRate: 90, autoPublish: true, maxQtyPerOrder: 20 });
  await fb.createUserIfNotExists('111', { first_name: 'Buyer' });
  reseller.start(fakeBot); // background timers are unref'd below
});
test.after(() => { server.close(); setTimeout(() => process.exit(0), 50); });

async function makeOrder(qty = 1, productId = 'prod_qm10', amount = 46) {
  const product = await fb.getProduct(productId);
  const fields = reseller.buildOrderFields(productId, product, qty);
  const order = await fb.createOrder({ userId: '111', productId, productName: fields.displayName, amount, originalAmount: amount, paymentMethod: 'wallet', ...fields });
  await fb.updateOrderIf(order.id, o => o.status === 'pending', { status: 'paid', paidAt: Date.now() });
  return order.id;
}

test('sync imports catalog with markup, rounds up, publishes', async () => {
  const st = await reseller.syncCatalog();
  assert.equal(st.added, 2);
  const p = await fb.getProduct('prod_qm10');
  assert.equal(p.price, 46);             // 0.39*90*1.3 = 45.63 → 46
  assert.equal(p.active, true);
  assert.equal(p.notifiedNewProduct, true);
  assert.equal(p.stock, 50);
});

test('admin-locked price survives sync; upstream removal hides product', async () => {
  await fb.updateProduct('prod_qm10', { price: 99, lockedFields: ['price'] });
  srv.products[0].stock = 40;
  await reseller.syncCatalog();
  let p = await fb.getProduct('prod_qm10');
  assert.equal(p.price, 99); assert.equal(p.stock, 40);
  const removed = srv.products.pop();
  const st = await reseller.syncCatalog();
  assert.equal(st.disabled, 1);
  assert.equal((await fb.getProduct('prod_qm11')).active, false);
  srv.products.push(removed);
  const st2 = await reseller.syncCatalog();
  assert.equal(st2.restored, 1);
  assert.equal((await fb.getProduct('prod_qm11')).active, true);
  await fb.updateProduct('prod_qm10', { price: 46, lockedFields: [] });
});

test('successful fulfilment delivers, saves items, is exactly-once under concurrency', async () => {
  sent.length = 0; srv.postCalls = 0;
  const id = await makeOrder(2);
  const [a, b] = await Promise.all([reseller.fulfil(id), reseller.fulfil(id)]);
  const o = await fb.getOrder(id);
  assert.equal(o.status, 'delivered'); assert.equal(o.fulfilment, 'done');
  assert.equal(o.qamifyItems.length, 2);
  assert.equal(srv.postCalls, 1, 'must call Qamify exactly once');
  assert.ok(sent.some(m => m.id === '111' && m.text.includes('user0:pass0')));
  assert.equal(o.costCents, 78);
  // idempotent: fulfilling again does nothing
  const again = await reseller.fulfil(id);
  assert.equal(again.reason, 'not_claimable');
  assert.equal(srv.postCalls, 1);
});

test('out_of_stock → wallet refund, order refunded, user told', async () => {
  srv.mode = 'oos'; sent.length = 0;
  const before = await fb.getWalletBalance('111');
  const id = await makeOrder(1);
  await reseller.fulfil(id);
  srv.mode = 'ok';
  const o = await fb.getOrder(id);
  assert.equal(o.status, 'refunded'); assert.equal(o.refundCredited, true);
  assert.equal(await fb.getWalletBalance('111'), before + 46);
  assert.ok(sent.some(m => /refund/i.test(m.text)));
  // refunding twice never double-credits
  assert.equal(await reseller.refundOrder(id, 'again'), null);
  assert.equal(await fb.getWalletBalance('111'), before + 46);
});

test('500 before commit → retried with SAME key, one purchase', async () => {
  srv.mode = 'fail500_first'; srv.postCalls = 0; const n0 = Object.keys(srv.orders).length;
  const id = await makeOrder(1);
  await reseller.fulfil(id);
  srv.mode = 'ok';
  assert.equal((await fb.getOrder(id)).status, 'delivered');
  assert.equal(Object.keys(srv.orders).length, n0 + 1);
});

test('LOST RESPONSE (server committed, returned 500) → reconciled, never double-charged', async () => {
  srv.mode = 'commit_then_500'; srv.postCalls = 0; const n0 = Object.keys(srv.orders).length; const bal0 = srv.balance;
  const id = await makeOrder(1);
  await reseller.fulfil(id);   // client retries same key → server replays the original
  srv.mode = 'ok';
  const o = await fb.getOrder(id);
  assert.equal(o.status, 'delivered');
  assert.equal(Object.keys(srv.orders).length, n0 + 1, 'only ONE upstream order');
  assert.equal(bal0 - srv.balance, 39, 'charged exactly once');
});

test('crash mid-flight: processing → uncertain → looked up by idempotency key', async () => {
  const id = await makeOrder(1);
  const o = await fb.getOrder(id);
  // simulate: request reached Qamify and committed, then process died
  srv.orders[o.idemKey] = { code: 'RA-CRASH', product_id: 10, qty: 1, unit_price_cents: 39, total_cents: 39, status: 'completed', items: [{ content: 'c:c' }], instructions: '' };
  await fb.updateOrder(id, { fulfilment: 'processing', processingSince: Date.now() - 999999 });
  const n0 = srv.postCalls;
  // what recoverOnBoot does:
  await fb.updateOrder(id, { fulfilment: 'uncertain', wasUncertain: true, nextAttemptAt: 0 });
  await reseller.fulfil(id);
  assert.equal(srv.postCalls, n0, 'must NOT POST again — found via lookup');
  assert.equal((await fb.getOrder(id)).qamifyCode, 'RA-CRASH');
  assert.equal((await fb.getOrder(id)).status, 'delivered');
});

test('cooldown → order queued (not refunded), customer notified', async () => {
  srv.mode = 'cooldown'; sent.length = 0;
  const id = await makeOrder(1);
  const r = await reseller.fulfil(id);
  srv.mode = 'ok';
  const o = await fb.getOrder(id);
  assert.equal(r.reason, 'queued'); assert.equal(o.fulfilment, 'queued'); assert.equal(o.status, 'paid');
  assert.ok(o.nextAttemptAt > Date.now());
  // when the time comes it succeeds
  await fb.updateOrder(id, { nextAttemptAt: 0 });
  await reseller.fulfil(id);
  assert.equal((await fb.getOrder(id)).status, 'delivered');
});

test('availability: qty limits, stock, cooldown-after-order, balance', async () => {
  const p = await fb.getProduct('prod_qm11');
  assert.equal((await reseller.checkAvailability(p, 1)).ok, true);
  assert.equal((await reseller.checkAvailability(p, 4)).code, 'above_max');   // max_qty 3
  await fb.updateProduct('prod_qm11', { qamifyLastOrderAt: Date.now() });
  const p2 = await fb.getProduct('prod_qm11');
  assert.equal((await reseller.checkAvailability(p2, 1)).code, 'cooldown');
  srv.balance = 10; await reseller.getBalance(true);
  const p10 = await fb.getProduct('prod_qm10');
  assert.equal((await reseller.checkAvailability(p10, 1)).code, 'reseller_balance');
  srv.balance = 100000; await reseller.getBalance(true);
});

test('bad API key → customer refunded + admin alerted', async () => {
  const s = await fb.getResellerSettings();
  await fb.updateResellerSettings({ apiKey: 'wrongkey' });
  sent.length = 0;
  const id = await makeOrder(1);
  await reseller.fulfil(id);
  await fb.updateResellerSettings({ apiKey: s.apiKey });
  assert.equal((await fb.getOrder(id)).status, 'refunded');
  assert.ok(sent.some(m => m.id === '999'), 'admin alerted');
});

test('profit report', async () => {
  const r = await reseller.getProfitReport(30);
  assert.ok(r.orders >= 3 && r.revenue > r.costInr);
});
