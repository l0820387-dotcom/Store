// Coloured inline buttons (Telegram Bot API 9.4+: InlineKeyboardButton.style)
// Valid values: 'primary' (blue), 'success' (green), 'danger' (red).
// No style = Telegram's default (theme colour). Older clients simply ignore it.

const STYLE_CYCLE = ['primary', 'success', 'danger', 'default'];
const STYLE_ICON = { primary: '🔵', success: '🟢', danger: '🔴', default: '⚪' };
const STYLE_NAME = { primary: 'Blue', success: 'Green', danger: 'Red', default: 'Default' };

// Built-in main-menu buttons: key -> default colour (blue/green alternating like Qamify)
const DEFAULT_MENU_COLORS = {
  wallet: 'success',
  profile: 'primary',
  browse: 'success',
  free: 'primary',
  proplan: 'success',
  purchases: 'primary',
  orders: 'success',
  referrals: 'primary',
  stats: 'success',
  paymenthistory: 'primary',
  checkin: 'success',
  leaderboard: 'primary',
  support: 'success',
  language: 'primary'
};

const ENABLED = String(process.env.BUTTON_COLORS || 'on').toLowerCase() !== 'off';

function normStyle(s) {
  return STYLE_CYCLE.includes(s) ? s : 'default';
}

function nextStyle(s) {
  const i = STYLE_CYCLE.indexOf(normStyle(s));
  return STYLE_CYCLE[(i + 1) % STYLE_CYCLE.length];
}

// Colour for a built-in menu key (admin override > default)
function menuColor(settings, key) {
  const over = settings && settings.menuColors && settings.menuColors[key];
  return normStyle(over || DEFAULT_MENU_COLORS[key] || 'default');
}

function isHidden(settings, key) {
  return !!(settings && settings.menuHidden && settings.menuHidden[key]);
}

// Same as Markup.button.callback but with an optional colour.
function styledCallback(text, data, style) {
  const b = { text, callback_data: data };
  const s = normStyle(style);
  if (ENABLED && s !== 'default') b.style = s;
  return b;
}

function styledUrl(text, url, style) {
  const b = { text, url };
  const s = normStyle(style);
  if (ENABLED && s !== 'default') b.style = s;
  return b;
}

// Auto-colour EVERY button that has no explicit style, based on its label/callback.
// Rules (first match wins): red = cancel/delete/back-out, green = pay/confirm/add,
// blue = navigation (Home/Back/menus). Anything else alternates blue/green by
// position so no button is left uncoloured.
function autoStyleFor(btn, pos) {
  const t = String(btn.text || '');
  const d = String(btn.callback_data || '');
  if (/^(🏠|⬅️|🔙|◀️)/.test(t) || d === 'nav_back' || d === 'menu_home') return 'primary';
  if (/❌|🗑|🚫|⛔|🧹/.test(t) || /cancel|reject|decline|remove|delete|ban|clear/i.test(d)) return 'danger';
  if (/✅|💳|💰|🛒|📥|➕|🟡|🎁|💎|👑/.test(t) || /^(buy_|pay|agree|qtygo|addmoney|quickadd|freedownload|redeliver|approve|topup)/i.test(d)) return 'success';
  if (/^(admin_|menu_|viewproduct_|cat_)/.test(d)) return 'primary';
  return pos % 2 === 0 ? 'primary' : 'success';
}

function autoStyleMarkup(markup) {
  if (!ENABLED || !markup) return markup;
  const kb = markup.inline_keyboard;
  if (!Array.isArray(kb)) return markup;
  kb.forEach((row, r) => {
    if (!Array.isArray(row)) return;
    row.forEach((btn, c) => {
      if (!btn || btn.style) return;
      btn.style = autoStyleFor(btn, r + c);
    });
  });
  return markup;
}

// Reply-keyboard buttons (the ones that replace the phone keyboard) can be coloured too.
function autoStyleReplyKeyboard(markup) {
  if (!ENABLED || !markup || !Array.isArray(markup.keyboard)) return markup;
  markup.keyboard = markup.keyboard.map((row, r) => {
    if (!Array.isArray(row)) return row;
    return row.map((btn, c) => {
      const o = typeof btn === 'string' ? { text: btn } : btn;
      if (o && !o.style) o.style = /cancel|no\b|❌/i.test(o.text || '') ? 'danger' : (c % 2 === 0 ? 'primary' : 'success');
      return o;
    });
  });
  return markup;
}

function styleAnyMarkup(data) {
  if (!data || !data.reply_markup) return;
  let rm = data.reply_markup;
  if (typeof rm === 'string') {
    try { rm = JSON.parse(rm); } catch (e) { return; }
    data.reply_markup = rm;
  }
  autoStyleMarkup(rm);
  autoStyleReplyKeyboard(rm);
}

function wrapCallApi(tg) {
  if (!tg || typeof tg.callApi !== 'function' || tg.__autoStyled) return;
  const orig = tg.callApi.bind(tg);
  tg.callApi = (method, data, ...rest) => {
    try { styleAnyMarkup(data); } catch (e) { /* never block a send because of colours */ }
    return orig(method, data, ...rest);
  };
  tg.__autoStyled = true;
}

// IMPORTANT: Telegraf creates a NEW Telegram object for every incoming update
// (ctx.telegram !== bot.telegram), so patching only bot.telegram misses every
// ctx.reply / ctx.editMessageText. We therefore patch (1) the Telegram class
// prototype, (2) bot.telegram, and (3) ctx.telegram in a first middleware.
function installAutoStyle(bot) {
  if (!ENABLED || !bot) return;
  try {
    const { Telegram } = require('telegraf');
    const proto = Telegram && Telegram.prototype;
    if (proto && typeof proto.callApi === 'function' && !proto.__autoStyled) {
      const orig = proto.callApi;
      proto.callApi = function (method, data, ...rest) {
        try { styleAnyMarkup(data); } catch (e) { /* ignore */ }
        return orig.call(this, method, data, ...rest);
      };
      proto.__autoStyled = true;
    }
  } catch (e) { /* stub / older telegraf */ }

  wrapCallApi(bot.telegram);
  if (typeof bot.use === 'function') {
    bot.use((ctx, next) => { wrapCallApi(ctx && ctx.telegram); return next(); });
  }
}

module.exports = {
  STYLE_CYCLE, STYLE_ICON, STYLE_NAME, DEFAULT_MENU_COLORS,
  normStyle, nextStyle, menuColor, isHidden,
  styledCallback, styledUrl, autoStyleMarkup, autoStyleReplyKeyboard, installAutoStyle
};
