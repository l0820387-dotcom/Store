// ============================================================
// ADMIN PANEL (Telegram-based, replaces admin.html)
// ============================================================
// Everything the old web admin.html did is now available via /admin inside
// the bot itself — no browser, no Firebase client SDK, no separate hosting.
// All actions require the user's Telegram ID to be in ADMIN_TELEGRAM_IDS.

const { Markup } = require('telegraf');
const bs = require('./buttonStyle');
const { setupResellerAdmin } = require('./resellerAdmin');

// Sanitizes any admin/user-provided text before it goes into a Telegram
// button label or message. Strips lone/unpaired UTF-16 surrogates (the
// cause of Telegram's opaque "must be encoded in UTF-8" rejection — these
// can come from copy-pasted "stylish" fancy-text fonts, or from naive
// truncation elsewhere cutting a multi-byte character in half), plus
// zero-width and control characters that can also trip Telegram's strict
// validation. Optionally hard-caps length without ever splitting a valid
// surrogate pair in the process.
function sanitizeForTelegram(text, maxLen) {
  if (text === undefined || text === null) return '';
  let s = String(text);

  // eslint-disable-next-line no-control-regex
  s = s.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g, '');   // lone high surrogate
  s = s.replace(/(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '');   // lone low surrogate
  s = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u200B-\u200F\u2028\u2029\uFEFF]/g, '');
  s = s.trim();

  if (maxLen && s.length > maxLen) {
    let sliced = s.slice(0, maxLen);
    const lastCode = sliced.charCodeAt(sliced.length - 1);
    if (lastCode >= 0xD800 && lastCode <= 0xDBFF) sliced = sliced.slice(0, -1);
    s = sliced;
  }
  return s;
}

// Truncates text to at most `max` characters WITHOUT ever splitting a UTF-16
// surrogate pair in half — kept as a thin alias over sanitizeForTelegram so
// existing call sites keep working.
function safeTruncate(text, max) {
  return sanitizeForTelegram(text, max);
}

function setupAdminPanel(bot, fb, mdEscape) {
  const adminState = {}; // { telegramId: { step, data } } — separate from user-facing userState

  // Full owners (ADMIN_TELEGRAM_IDS) always pass. Staff pass a lighter check
  // since their menu is filtered by permission — isAdmin() itself just gates
  // "can open the panel at all", not which buttons they see.
  function isAdmin(ctx) {
    return fb.isAdmin(ctx.from.id);
  }

  async function isAdminOrStaff(ctx) {
    if (fb.isAdmin(ctx.from.id)) return true;
    return await fb.isStaff(ctx.from.id);
  }

  async function isOwner(ctx) {
    return fb.isAdmin(ctx.from.id); // only full owners, never staff
  }

  // 🤝 Reseller (Qamify) admin section — owner-only, self-contained
  const resellerAdmin = setupResellerAdmin({ bot, fb, mdEscape, adminState, isOwner });

  // ============ MAIN ADMIN MENU ============

  bot.command('admin', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    delete adminState[ctx.from.id];
    await sendAdminMenu(ctx);
  });

  async function sendAdminMenu(ctx) {
    const owner = await isOwner(ctx);
    const perms = owner ? null : await fb.getStaffPermissions(ctx.from.id);
    const has = (p) => owner || perms.includes(p);

    const text = owner ? '🛠 *Admin Control Panel*\n\nChoose a section:' : '🛠 *Staff Panel*\n\nChoose a section:';
    const rows = [];
    if (has('products')) rows.push([Markup.button.callback('📦 Products', 'admin_products'), Markup.button.callback('🧾 Orders', 'admin_orders')]);
    if (has('users')) rows.push([Markup.button.callback('👥 Users', 'admin_users'), Markup.button.callback('🟡 Binance Payments', 'admin_binancequeue')]);
    if (has('coupons')) rows.push([Markup.button.callback('🎟 Coupons', 'admin_coupons'), Markup.button.callback('🔗 Referral', 'admin_referral')]);
    if (has('broadcast')) rows.push([Markup.button.callback('📢 Broadcast', 'admin_broadcast'), Markup.button.callback('📩 Direct Message', 'admin_dm')]);
    if (has('broadcast')) rows.push([Markup.button.callback('📜 Message History', 'admin_msghistory')]);
    if (owner) rows.push([Markup.button.callback('⚙️ Bot Settings', 'admin_settings'), Markup.button.callback('🔘 Menu Buttons', 'admin_menubuttons')]);
    if (owner) rows.push([Markup.button.callback('🤝 Reseller (Qamify)', 'admin_reseller')]);
    if (owner) rows.push([Markup.button.callback('👑 Pro Plan', 'admin_proplan'), Markup.button.callback('🎯 Check-in', 'admin_checkin')]);
    if (has('products')) rows.push([Markup.button.callback('📊 Sales Report', 'admin_report'), Markup.button.callback('🏆 Leaderboard', 'admin_leaderboard')]);
    if (owner) rows.push([Markup.button.callback('🧑‍💼 Staff', 'admin_staff'), Markup.button.callback('💾 Backup Data', 'admin_backup')]);
    else if (has('products')) rows.push([Markup.button.callback('💾 Backup Data', 'admin_backup')]);

    const buttons = Markup.inlineKeyboard(rows);
    if (ctx.callbackQuery) {
      try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...buttons }); return; }
      catch (e) { try { await ctx.deleteMessage(); } catch (e2) {} }
    }
    await ctx.reply(text, { parse_mode: 'Markdown', ...buttons });
  }

  function adminBackButton(target = 'admin_home') {
    return Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', target)]]);
  }

  bot.action('admin_home', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    delete adminState[ctx.from.id];
    await sendAdminMenu(ctx);
  });

  // ============ PRODUCTS ============

  bot.action('admin_products', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendProductsList(ctx);
  });

  async function sendProductsList(ctx) {
    const products = await fb.getAllProducts(false);
    const entries = Object.entries(products);

    let text = `📦 *Products* (${entries.length})\n\n`;
    if (entries.length === 0) {
      text += '_No products yet._';
    } else {
      entries.slice(0, 20).forEach(([id, p]) => {
        text += `${p.active ? '✅' : '🙈'}${p.source === 'qamify' ? '🤝' : ''} *${mdEscape(sanitizeForTelegram(p.name, 200))}* — ₹${p.price} | 👁 ${p.views || 0}${p.stock !== undefined && p.stock !== -1 ? ` | 📦 ${p.stock}` : ''}\n`;
      });
      if (entries.length > 20) text += `\n_...and ${entries.length - 20} more_`;
    }

    const buttons = [[Markup.button.callback('➕ Add Product', 'admin_addproduct')]];
    entries.slice(0, 20).forEach(([id, p]) => {
      buttons.push([Markup.button.callback(`✏️ ${sanitizeForTelegram(p.name, 25) || '(no name)'}`, `admin_prod_${id}`)]);
    });
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_prod_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    const p = await fb.getProduct(productId);
    if (!p) return ctx.answerCbQuery('Product not found.');
    await ctx.answerCbQuery();

    const text = `📦 *${mdEscape(sanitizeForTelegram(p.name, 200))}*\n\n💰 ₹${p.price}\n📁 ${mdEscape(sanitizeForTelegram(p.category, 100))}\n${p.source === 'qamify' ? `🤝 Qamify reseller product #${p.qamifyId} (cost $${((p.qamify?.unitCents || 0) / 100).toFixed(2)}/unit${(p.lockedFields || []).includes('price') ? ', custom price locked' : ''})` : (p.deliveryType === 'file' ? '📎 File delivery' : '🔗 Link delivery')}\n📦 Stock: ${p.stock === -1 || p.stock === undefined ? 'Unlimited' : p.stock}\n👁 ${p.views || 0} views\n${p.active ? '✅ Active' : '🙈 Hidden'}\n\n${mdEscape(sanitizeForTelegram(p.description, 2000) || '')}`;

    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback('✏️ Edit', `admin_editprod_${productId}`)],
      [Markup.button.callback(p.active ? '🙈 Hide' : '✅ Show', `admin_toggleprod_${productId}`)],
      [Markup.button.callback('🔗 Get Share Link', `admin_prodlink_${productId}`)],
      [Markup.button.callback('🗑 Delete', `admin_delprod_${productId}`)],
      [Markup.button.callback('⬅️ Back', 'admin_products')]
    ]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...buttons }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...buttons }); }
  });

  bot.action(/^admin_toggleprod_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    const p = await fb.getProduct(productId);
    if (!p) return ctx.answerCbQuery('Not found.');
    await fb.updateProduct(productId, { active: !p.active });
    await ctx.answerCbQuery(p.active ? '🙈 Hidden' : '✅ Shown');
    const updated = await fb.getProduct(productId);
    const text = `📦 *${mdEscape(updated.name)}*\n\n💰 ₹${updated.price}\n${updated.active ? '✅ Active' : '🙈 Hidden'}`;
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback('✏️ Edit', `admin_editprod_${productId}`)],
      [Markup.button.callback(updated.active ? '🙈 Hide' : '✅ Show', `admin_toggleprod_${productId}`)],
      [Markup.button.callback('🔗 Get Share Link', `admin_prodlink_${productId}`)],
      [Markup.button.callback('🗑 Delete', `admin_delprod_${productId}`)],
      [Markup.button.callback('⬅️ Back', 'admin_products')]
    ]);
    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...buttons }); } catch (e) {}
  });

  bot.action(/^admin_prodlink_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    await ctx.answerCbQuery();
    const botInfo = await bot.telegram.getMe();
    const link = `https://t.me/${botInfo.username}?start=PROD_${productId}`;
    await ctx.reply(`🔗 *Share Link*\n\n\`${link}\`\n\nTap to copy, or forward this message.`, { parse_mode: 'Markdown' });
  });

  bot.action(/^admin_delprod_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    const p = await fb.getProduct(productId);
    if (!p) return ctx.answerCbQuery('Not found.');

    const orders = await fb.getAllOrders();
    const orderCount = Object.values(orders).filter(o => o.productId === productId).length;

    await ctx.answerCbQuery();
    const warning = orderCount > 0
      ? `⚠️ *${orderCount} user(s) purchased this product.*\n\nTheir order history keeps the product name, but re-download uses a saved snapshot — deleting is generally safe. Delete anyway?`
      : `Delete "${mdEscape(p.name)}" permanently?`;

    await ctx.reply(warning, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✅ Yes, Delete', `admin_confirmdelprod_${productId}`)],
        [Markup.button.callback('❌ Cancel', `admin_prod_${productId}`)]
      ])
    });
  });

  bot.action(/^admin_confirmdelprod_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    const pd = await fb.getProduct(productId);
    if (pd && pd.source === 'qamify') {
      // Deleting would just re-import it on the next sync — hide it permanently instead.
      await fb.updateProduct(productId, { active: false, ignored: true, autoDisabled: false });
      await ctx.answerCbQuery('🙈 Hidden');
      return ctx.editMessageText('🙈 Reseller product hidden. (Deleting is not possible — it would come back on the next sync. Use Reseller → Publish All to bring it back.)', adminBackButton('admin_products'));
    }
    await fb.deleteProduct(productId);
    await ctx.answerCbQuery('🗑️ Deleted');
    await ctx.editMessageText('🗑️ Product deleted.', adminBackButton('admin_products'));
  });

  // ---- Add / Edit product flow (conversational) ----

  bot.action('admin_addproduct', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'prod_name', data: { isEdit: false } };
    await ctx.reply('📦 *Add Product*\n\nStep 1/8 — Product name?', { parse_mode: 'Markdown' });
  });

  // ---- Edit product: pick a single field to change instead of a full wizard ----
  bot.action(/^admin_editprod_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const productId = ctx.match[1];
    const p = await fb.getProduct(productId);
    if (!p) return ctx.answerCbQuery('Not found.');
    await ctx.answerCbQuery();
    await sendEditFieldMenu(ctx, productId, p);
  });

  async function sendEditFieldMenu(ctx, productId, p) {
    const safeName = sanitizeForTelegram(p.name, 200);
    const text = `✏️ *Edit — ${mdEscape(safeName)}*\n\nKaunsi field change karni hai? (sirf wahi update hogi, baaki sab waisa hi rahega)`;
    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback(`Name: ${sanitizeForTelegram(p.name, 20) || '(no name)'}`, `admin_editfield_name_${productId}`)],
      [Markup.button.callback(`Price: ₹${p.price}`, `admin_editfield_price_${productId}`)],
      [Markup.button.callback(`Category: ${sanitizeForTelegram(p.category, 25) || 'none'}`, `admin_editfield_category_${productId}`)],
      [Markup.button.callback('Description', `admin_editfield_description_${productId}`)],
      [Markup.button.callback(`Stock: ${p.stock === -1 || p.stock === undefined ? 'Unlimited' : p.stock}`, `admin_editfield_stock_${productId}`)],
      [Markup.button.callback(`Delivery: ${p.deliveryType === 'file' ? '📎 File' : '🔗 Link'}`, `admin_editfield_deliverytype_${productId}`)],
      [Markup.button.callback(p.deliveryType === 'file' ? '📎 Replace File' : '🔗 Change Link', `admin_editfield_deliveryvalue_${productId}`)],
      [Markup.button.callback('🖼 Change Image', `admin_editfield_image_${productId}`)],
      [Markup.button.callback('⬅️ Back', `admin_prod_${productId}`)]
    ]);
    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...buttons }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...buttons }); }
  }

  const EDIT_FIELD_PROMPTS = {
    name: 'Naya *name* bhejo:',
    price: 'Naya *price* bhejo (₹, 0 for free):',
    category: 'Nayi *category* bhejo:',
    description: 'Nayi *description* bhejo:',
    stock: 'Nayi *stock quantity* bhejo (-1 for unlimited):',
    deliverytype: 'Delivery type "file" ya "link"?',
    deliveryvalue: null, // depends on current deliveryType, filled in below
    image: 'Nayi product *image* (photo) bhejo:'
  };

  bot.action(/^admin_editfield_([a-z]+)_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const field = ctx.match[1];
    const productId = ctx.match[2];
    const p = await fb.getProduct(productId);
    if (!p) return ctx.answerCbQuery('Not found.');
    await ctx.answerCbQuery();

    adminState[ctx.from.id] = { step: 'prod_editfield', data: { field, productId } };

    if (field === 'deliveryvalue') {
      const prompt = p.deliveryType === 'file'
        ? 'Nayi *file* bhejo (as document):'
        : 'Naya *download link* (URL) bhejo:';
      return ctx.reply(prompt, { parse_mode: 'Markdown' });
    }

    if (field === 'deliverytype') {
      return ctx.reply(EDIT_FIELD_PROMPTS.deliverytype, Markup.keyboard(['file', 'link']).oneTime().resize());
    }

    await ctx.reply(EDIT_FIELD_PROMPTS[field], { parse_mode: 'Markdown' });
  });

  // Handles the single-field edit text replies (name/price/category/description/stock/deliverytype/link)
  async function handleEditFieldText(ctx, state, text) {
    const { field, productId } = state.data;
    const p = await fb.getProduct(productId);
    if (!p) { delete adminState[ctx.from.id]; await ctx.reply('⚠️ Product no longer exists.'); return true; }

    const updates = {};

    switch (field) {
      case 'name':
        updates.name = text;
        break;
      case 'price': {
        const price = parseInt(text);
        if (isNaN(price)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
        updates.price = price;
        break;
      }
      case 'category':
        updates.category = text;
        break;
      case 'description':
        updates.description = text;
        break;
      case 'stock': {
        const stock = parseInt(text);
        updates.stock = isNaN(stock) ? -1 : stock;
        break;
      }
      case 'deliverytype': {
        const type = text.toLowerCase();
        if (type !== 'file' && type !== 'link') { await ctx.reply('⚠️ Reply "file" or "link".'); return true; }
        updates.deliveryType = type;
        break;
      }
      case 'deliveryvalue':
        if (p.deliveryType === 'link') {
          updates.deliveryLink = text;
        } else {
          await ctx.reply('⚠️ Please send the file as a document, not text.');
          return true;
        }
        break;
      default:
        return false;
    }

    // Reseller products auto-sync from Qamify — fields the admin edits by hand are locked
    // so the next sync never overwrites them (Reseller → Unlock Custom Prices reverts price).
    if (p.source === 'qamify' && ['name', 'price', 'description'].includes(field)) {
      updates.lockedFields = [...new Set([...(p.lockedFields || []), field])];
    }
    await fb.updateProduct(productId, updates);
    delete adminState[ctx.from.id];
    await ctx.reply('✅ Updated!', Markup.removeKeyboard());
    const updated = await fb.getProduct(productId);
    await sendEditFieldMenu(ctx, productId, updated);
    return true;
  }

  // ============ ORDERS ============

  bot.action('admin_orders', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendOrdersMenu(ctx, 'all', 0);
  });

  async function sendOrdersMenu(ctx, filter = 'all', page = 0) {
    const orders = await fb.getAllOrders();
    let list = Object.entries(orders).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
    if (filter !== 'all') list = list.filter(([, o]) => o.status === filter);

    const pageSize = 10;
    const pageItems = list.slice(page * pageSize, (page + 1) * pageSize);

    let text = `🧾 *Orders* (${list.length}${filter !== 'all' ? ` ${filter}` : ''})\n\nTap any order for full details:`;
    if (list.length === 0) text += '\n\n_No orders in this category._';

    const buttons = [
      [
        Markup.button.callback('All', 'admin_orderf_all'),
        Markup.button.callback('✅ Success', 'admin_orderf_delivered'),
        Markup.button.callback('⏳ Pending', 'admin_orderf_pending')
      ],
      [
        Markup.button.callback('❌ Failed', 'admin_orderf_failed'),
        Markup.button.callback('↩️ Refunded', 'admin_orderf_refunded')
      ]
    ];

    pageItems.forEach(([id, o]) => {
      const emoji = o.status === 'delivered' ? '✅' : o.status === 'pending' ? '⏳' : o.status === 'failed' ? '❌' : o.status === 'refunded' ? '↩️' : '🔄';
      const label = `${emoji} ${o.productName} — ₹${o.amount} (${o.userId})`;
      buttons.push([Markup.button.callback(label.slice(0, 60), `admin_orderdetail_${id}`)]);
    });

    const navRow = [];
    if (page > 0) navRow.push(Markup.button.callback('⬅️ Prev', `admin_orderpage_${filter}_${page - 1}`));
    if ((page + 1) * pageSize < list.length) navRow.push(Markup.button.callback('Next ➡️', `admin_orderpage_${filter}_${page + 1}`));
    if (navRow.length) buttons.push(navRow);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_orderf_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendOrdersMenu(ctx, ctx.match[1], 0);
  });

  bot.action(/^admin_orderpage_(\w+)_(\d+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendOrdersMenu(ctx, ctx.match[1], parseInt(ctx.match[2]));
  });

  bot.action(/^admin_orderdetail_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const orderId = ctx.match[1];
    const o = await fb.getOrder(orderId);
    if (!o) return ctx.answerCbQuery('Not found.');
    await ctx.answerCbQuery();

    const emoji = o.status === 'delivered' ? '✅' : o.status === 'pending' ? '⏳' : o.status === 'failed' ? '❌' : o.status === 'refunded' ? '↩️' : '🔄';
    let text = `${emoji} *Order Details*\n\n`;
    text += `📦 Product: ${mdEscape(o.productName)}\n`;
    text += `💰 Amount: ₹${o.amount}${o.originalAmount && o.originalAmount !== o.amount ? ` (original ₹${o.originalAmount})` : ''}\n`;
    text += `👤 User: \`${o.userId}\`\n`;
    text += `💳 Method: ${o.paymentMethod || 'unknown'}\n`;
    text += `📊 Status: ${o.status}\n`;
    if (o.utr) text += `🔢 UTR: \`${o.utr}\`\n`;
    if (o.couponUsed) text += `🎟 Coupon: \`${o.couponUsed}\`\n`;
    if (o.refundStatus) text += `↩️ Refund: ${o.refundStatus}\n`;
    text += `📅 Created: ${o.createdAt ? new Date(o.createdAt).toLocaleString() : '-'}\n`;
    if (o.deliveredAt) text += `📬 Delivered: ${new Date(o.deliveredAt).toLocaleString()}\n`;
    const qmRows = [];
    if (o.isQamify) {
      text += `\n🤝 *Reseller order*\n🔢 Qty: ${o.qty}\n⚙️ State: ${o.fulfilment || 'pending'} (attempts ${o.fulfilAttempts || 0})\n`;
      if (o.qamifyCode) text += `🧾 Qamify: \`${mdEscape(o.qamifyCode)}\`\n`;
      if (typeof o.costCents === 'number') text += `🏭 Cost: $${(o.costCents / 100).toFixed(2)} → profit ≈ ₹${Math.round(o.amount - (o.costCents / 100) * (o.usdRateUsed || 90))}\n`;
      if (o.lastError) text += `⚠️ Last error: ${mdEscape(String(o.lastError).slice(0, 100))}\n`;
      if (o.status === 'paid' && ['needs_review', 'queued', 'uncertain', 'pending'].includes(o.fulfilment || 'pending') && (await isOwner(ctx))) {
        qmRows.push([Markup.button.callback('🔁 Retry Delivery', `admin_qmretry_${o.id}`), Markup.button.callback('↩️ Refund', `admin_qmrefund_${o.id}`)]);
      }
    }

    await ctx.reply(text, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        ...qmRows,
        [Markup.button.callback('👤 View User', `admin_viewuser_${o.userId}`)],
        [Markup.button.callback('⬅️ Back to Orders', 'admin_orders')]
      ])
    });
  });

  // ============ USERS ============

  bot.action('admin_users', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendUsersList(ctx, 0);
  });

  async function sendUsersList(ctx, page) {
    const users = await fb.getAllUsers();
    const entries = Object.entries(users).sort((a, b) => (b[1].joinedAt || 0) - (a[1].joinedAt || 0));
    const pageSize = 8;
    const pageItems = entries.slice(page * pageSize, (page + 1) * pageSize);

    let text = `👥 *Users* (${entries.length} total)\n\nTap a user to view full details:`;

    const buttons = pageItems.map(([id, u]) => {
      const label = `${u.banned ? '🚫 ' : ''}${u.name || 'Unknown'}${u.username ? ' (@' + u.username + ')' : ''} — ₹${u.walletBalance || 0}`;
      return [Markup.button.callback(label.slice(0, 60), `admin_viewuser_${id}`)];
    });

    const navRow = [];
    if (page > 0) navRow.push(Markup.button.callback('⬅️ Prev', `admin_userspage_${page - 1}`));
    if ((page + 1) * pageSize < entries.length) navRow.push(Markup.button.callback('Next ➡️', `admin_userspage_${page + 1}`));
    if (navRow.length) buttons.push(navRow);
    buttons.push([Markup.button.callback('🔍 Search by ID', 'admin_usersearch')]);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_userspage_(\d+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendUsersList(ctx, parseInt(ctx.match[1]));
  });

  bot.action(/^admin_viewuser_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendUserDetails(ctx, ctx.match[1]);
  });

  bot.action('admin_usersearch', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_user_lookup' };
    await ctx.reply('🔍 Send a Telegram ID to view details:', adminBackButton('admin_users'));
  });

  async function sendUserDetails(ctx, telegramId) {
    const analytics = await fb.getUserAnalytics(telegramId);
    if (!analytics) return ctx.reply('⚠️ User not found.');

    const isVip = analytics.isVip && analytics.vipExpiresAt > Date.now();
    const orders = await fb.getUserOrders(telegramId);
    const orderList = Object.values(orders).sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const statusCounts = {};
    orderList.forEach(o => { statusCounts[o.status] = (statusCounts[o.status] || 0) + 1; });
    const statusLine = Object.entries(statusCounts).map(([s, c]) => `${s}: ${c}`).join(', ') || 'none';

    let text = `👤 *${mdEscape(analytics.name)}* ${analytics.username ? '(@' + mdEscape(analytics.username) + ')' : ''}\n\n`;
    text += `🆔 Telegram ID: \`${telegramId}\`\n`;
    text += `📅 Joined: ${analytics.joinedAt ? new Date(analytics.joinedAt).toLocaleDateString() : 'unknown'}\n`;
    text += `💰 Wallet Balance: ₹${analytics.walletBalance || 0}\n`;
    text += `📦 Total Orders: ${analytics.totalOrders} (${statusLine})\n`;
    text += `💎 Total Spent: ₹${analytics.totalSpent}\n`;
    text += `🔗 Referral Code: \`${analytics.referralCode || 'none'}\`\n`;
    text += `👥 Referred By: ${analytics.referredBy ? '`' + analytics.referredBy + '`' : 'nobody (direct signup)'}\n`;
    text += `🤝 Users They Referred: ${analytics.referredCount}\n`;
    text += `🎯 Check-in Streak: ${analytics.checkInStreak || 0} days\n`;
    text += `${isVip ? `👑 VIP Active (expires ${new Date(analytics.vipExpiresAt).toLocaleDateString()})` : '👤 Not VIP'}\n`;
    text += `${analytics.banned ? `🚫 Banned — reason: ${mdEscape(analytics.banReason || 'not given')}` : '✅ Not banned'}\n`;

    if (orderList.length > 0) {
      text += `\n📋 *Recent Orders:*\n`;
      orderList.slice(0, 5).forEach(o => {
        const emoji = o.status === 'delivered' ? '✅' : o.status === 'pending' ? '⏳' : o.status === 'failed' ? '❌' : o.status === 'refunded' ? '↩️' : '🔄';
        text += `${emoji} ${mdEscape(o.productName)} — ₹${o.amount}\n`;
      });
    }

    await ctx.reply(text, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('💰 Adjust Wallet', `admin_wallet_${telegramId}`)],
        [analytics.banned ? Markup.button.callback('✅ Unban', `admin_unban_${telegramId}`) : Markup.button.callback('🚫 Ban', `admin_banuser_${telegramId}`)],
        [Markup.button.callback('📩 Message', `admin_msguser_${telegramId}`)],
        [Markup.button.callback('⬅️ Back to List', 'admin_users')]
      ])
    });
  }

  bot.action(/^admin_wallet_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const telegramId = ctx.match[1];
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_wallet_amount', data: { telegramId } };
    await ctx.reply('💰 Enter new wallet balance (₹):');
  });

  bot.action(/^admin_banuser_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const telegramId = ctx.match[1];
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_ban_reason', data: { telegramId } };
    await ctx.reply('🚫 Ban reason:');
  });

  bot.action(/^admin_unban_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const telegramId = ctx.match[1];
    await fb.unbanUser(telegramId);
    await ctx.answerCbQuery('✅ Unbanned');
    await ctx.reply(`✅ User ${telegramId} unbanned.`);
  });

  bot.action(/^admin_msguser_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const telegramId = ctx.match[1];
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'dm_message', data: { telegramId } };
    await ctx.reply('📩 Type the message to send:');
  });

  // ============ BINANCE PAYMENTS (pending screenshot review) ============
  // The actual Approve/Reject buttons are sent directly with each screenshot
  // (see bot.js's handleBinanceScreenshot + admin_binapprove_/admin_binreject_
  // handlers) — this screen is just a browsable list/reminder of what's
  // still waiting, useful if an admin missed the original notification.

  bot.action('admin_binancequeue', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendBinanceQueue(ctx);
  });

  async function sendBinanceQueue(ctx) {
    const pending = await fb.getBinancePendingReview();

    let text = `🟡 *Pending Binance Payments* (${pending.length})\n\nTap any to resend the screenshot with Approve/Reject buttons.`;
    if (pending.length === 0) text += '\n\n_No pending Binance payments._';

    const buttons = pending.slice(0, 15).map(([id, o]) => [
      Markup.button.callback(`${o.productName} — ₹${o.amount} ($${o.usdAmount || '?'}) (${o.userId})`, `admin_binresend_${id}`)
    ]);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_binresend_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const orderId = ctx.match[1];
    const order = await fb.getOrder(orderId);
    if (!order) return ctx.answerCbQuery('Not found.');
    if (order.status !== 'pending_review') {
      await ctx.answerCbQuery('Already processed.');
      return sendBinanceQueue(ctx);
    }
    await ctx.answerCbQuery();

    if (order.screenshotFileId) {
      await ctx.replyWithPhoto(order.screenshotFileId, {
        caption: `🟡 *Binance Payment*\n\n📦 ${mdEscape(order.productName)}\n💰 ₹${order.amount} ($${order.usdAmount || '?'})\n👤 User: \`${order.userId}\`\n🆔 Order: \`${order.id}\``,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('✅ Approve', `admin_binapprove_${order.id}`), Markup.button.callback('❌ Reject', `admin_binreject_${order.id}`)]
        ])
      });
    } else {
      await ctx.reply('⚠️ Screenshot not found for this order.');
    }
  });

  // ============ COUPONS ============

  bot.action('admin_coupons', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendCouponsList(ctx);
  });

  async function sendCouponsList(ctx) {
    const coupons = await fb.getAllCoupons();
    const entries = Object.entries(coupons);

    let text = `🎟 *Coupons* (${entries.length})\n\n`;
    entries.forEach(([code, c]) => {
      text += `${c.active ? '✅' : '🚫'} \`${code}\` — ${c.discountType === 'percent' ? c.discountValue + '%' : '₹' + c.discountValue} off (used ${c.usedCount || 0}${c.usageLimit ? '/' + c.usageLimit : ''})\n`;
    });
    if (entries.length === 0) text += '_No coupons yet._';

    const buttons = [[Markup.button.callback('➕ Create Coupon', 'admin_addcoupon')]];
    entries.forEach(([code]) => {
      buttons.push([Markup.button.callback(`${code}`, `admin_coupon_${code}`)]);
    });
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_coupon_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const code = ctx.match[1];
    const coupon = await fb.getCoupon(code);
    if (!coupon) return ctx.answerCbQuery('Not found.');
    await ctx.answerCbQuery();
    await ctx.reply(`🎟 \`${code}\`\n\n${coupon.active ? '✅ Active' : '🚫 Disabled'}`, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback(coupon.active ? '🚫 Disable' : '✅ Enable', `admin_togglecoupon_${code}`)],
        [Markup.button.callback('⬅️ Back', 'admin_coupons')]
      ])
    });
  });

  bot.action(/^admin_togglecoupon_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const code = ctx.match[1];
    const coupon = await fb.getCoupon(code);
    if (!coupon) return ctx.answerCbQuery('Not found.');
    await fb.toggleCoupon(code, !coupon.active);
    await ctx.answerCbQuery(coupon.active ? '🚫 Disabled' : '✅ Enabled');
    await sendCouponsList(ctx);
  });

  bot.action('admin_addcoupon', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'coupon_code', data: {} };
    await ctx.reply('🎟 *New Coupon*\n\nStep 1/4 — Coupon code? (e.g. WELCOME50)', { parse_mode: 'Markdown' });
  });

  // ============ REFERRAL SETTINGS ============

  bot.action('admin_referral', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    const settings = await fb.getReferralSettings();
    await ctx.reply(
      `🔗 *Referral Settings*\n\nBonus Type: ${settings.bonusType}\nBonus Amount: ${settings.bonusType === 'percent' ? settings.bonusAmount + '%' : '₹' + settings.bonusAmount}`,
      { parse_mode: 'Markdown', ...Markup.inlineKeyboard([[Markup.button.callback('✏️ Edit', 'admin_editreferral')], [Markup.button.callback('⬅️ Back', 'admin_home')]]) }
    );
  });

  bot.action('admin_editreferral', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'referral_type', data: {} };
    await ctx.reply('Bonus type? Reply "flat" (₹) or "percent" (%)', Markup.keyboard(['flat', 'percent']).oneTime().resize());
  });

  // ============ BROADCAST ============

  bot.action('admin_broadcast', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'bc_message', data: {} };
    await ctx.reply('📢 *Broadcast*\n\nType the message to send to all users:', { parse_mode: 'Markdown', ...adminBackButton('admin_home') });
  });

  // ============ DIRECT MESSAGE ============

  bot.action('admin_dm', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendDmUserPicker(ctx, 0);
  });

  async function sendDmUserPicker(ctx, page) {
    const users = await fb.getAllUsers();
    const entries = Object.entries(users).sort((a, b) => (b[1].joinedAt || 0) - (a[1].joinedAt || 0));
    const pageSize = 8;
    const pageItems = entries.slice(page * pageSize, (page + 1) * pageSize);

    let text = `📩 *Direct Message*\n\nSelect a user to message (${entries.length} total):`;

    const buttons = pageItems.map(([id, u]) => {
      const label = `${u.name || 'Unknown'}${u.username ? ' (@' + u.username + ')' : ''} — \`${id}\``;
      return [Markup.button.callback(label.replace(/`/g, '').slice(0, 60), `admin_dmpick_${id}`)];
    });

    const navRow = [];
    if (page > 0) navRow.push(Markup.button.callback('⬅️ Prev', `admin_dmpage_${page - 1}`));
    if ((page + 1) * pageSize < entries.length) navRow.push(Markup.button.callback('Next ➡️', `admin_dmpage_${page + 1}`));
    if (navRow.length) buttons.push(navRow);
    buttons.push([Markup.button.callback('🔍 Search by ID instead', 'admin_dmbyid')]);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action(/^admin_dmpage_(\d+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await sendDmUserPicker(ctx, parseInt(ctx.match[1]));
  });

  bot.action(/^admin_dmpick_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const telegramId = ctx.match[1];
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'dm_message', data: { telegramId } };
    await ctx.reply(`📩 Message for \`${telegramId}\`? Type it now:`, { parse_mode: 'Markdown' });
  });

  bot.action('admin_dmbyid', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'dm_userid', data: {} };
    await ctx.reply('📩 Enter the Telegram ID to message:', adminBackButton('admin_dm'));
  });

  // ============ BOT SETTINGS ============

  bot.action('admin_settings', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    const settings = await fb.getBotSettings();
    const text = `⚙️ *Bot Settings*\n\n🛠 Maintenance: ${settings.maintenanceMode ? 'ON 🔴' : 'OFF 🟢'}\n📢 Required Channels: ${(settings.channels || []).filter(c => c.required).length}\n💬 Support TG: ${settings.supportTelegram ? '@' + mdEscape(settings.supportTelegram) : 'not set'}\n📱 Support WA: ${settings.supportWhatsapp || 'not set'}`;

    try {
      await ctx.editMessageText(text, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('✏️ Welcome Message', 'admin_setwelcome')],
          [Markup.button.callback(settings.maintenanceMode ? '🟢 Disable Maintenance' : '🔴 Enable Maintenance', 'admin_togglemaintenance')],
          [Markup.button.callback('📢 Manage Channels', 'admin_channels')],
          [Markup.button.callback('💬 Set Support Info', 'admin_setsupport')],
          [Markup.button.callback('💳 Payment Settings', 'admin_paymentsettings')],
          [Markup.button.callback('⬅️ Back', 'admin_home')]
        ])
      });
    } catch (e) { await ctx.reply(text, { parse_mode: 'Markdown' }); }
  });

  // ============ PAYMENT SETTINGS (FamPay + Binance) ============

  bot.action('admin_paymentsettings', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await sendPaymentSettingsMenu(ctx);
  });

  async function sendPaymentSettingsMenu(ctx) {
    const s = await fb.getPaymentSettings();
    const maskedKey = s.apiKey ? s.apiKey.slice(0, 12) + '...' + s.apiKey.slice(-4) : 'not set';
    const text = `💳 *Payment Settings*\n\n` +
      `*FamPay* — ${s.fampayEnabled !== false ? '🟢 ON' : '🔴 OFF'}\n` +
      `🔑 API Key: \`${maskedKey}\`\n🌐 Base URL: ${mdEscape(s.baseUrl)}\n💰 UPI ID: \`${s.upiId || 'not set'}\`\n\n` +
      `*Binance* — ${s.binanceEnabled ? '🟢 ON' : '🔴 OFF'}\n` +
      `📤 Binance ID: \`${s.binanceId || 'not set'}\`\n💱 Rate: ₹${s.usdRate || 90} = $1\n\n` +
      `📜 T&C: ${s.termsAndConditions ? 'set' : 'not set'}`;

    const buttons = Markup.inlineKeyboard([
      [Markup.button.callback(s.fampayEnabled !== false ? '🔴 Disable FamPay' : '🟢 Enable FamPay', 'admin_togglefampay')],
      [Markup.button.callback('🔑 Edit API Key', 'admin_editfamkey')],
      [Markup.button.callback('🌐 Edit Base URL', 'admin_editfamurl')],
      [Markup.button.callback('💰 Edit UPI ID', 'admin_editfamupi')],
      [Markup.button.callback(s.binanceEnabled ? '🔴 Disable Binance' : '🟢 Enable Binance', 'admin_togglebinance')],
      [Markup.button.callback('📤 Edit Binance ID', 'admin_editbinanceid')],
      [Markup.button.callback('💱 Edit USD Rate', 'admin_editusdrate')],
      [Markup.button.callback('📜 Edit Terms & Conditions', 'admin_editfamtc')],
      [Markup.button.callback('⬅️ Back', 'admin_settings')]
    ]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...buttons }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...buttons }); }
  }

  // Guards against turning off the last remaining payment method — leaves
  // users with no way to pay at all (wallet still works but can never be
  // topped up).
  async function toggleGatewayGuarded(ctx, field, otherField) {
    const s = await fb.getPaymentSettings();
    const turningOff = field === 'fampayEnabled' ? s.fampayEnabled !== false : !!s.binanceEnabled;
    const otherOn = otherField === 'fampayEnabled' ? s.fampayEnabled !== false : !!s.binanceEnabled;

    if (turningOff && !otherOn) {
      await ctx.answerCbQuery('⚠️ Kam se kam ek payment method ON rehna chahiye.', { show_alert: true });
      return;
    }

    const newValue = field === 'fampayEnabled' ? !(s.fampayEnabled !== false) : !s.binanceEnabled;
    await fb.updatePaymentSettings({ [field]: newValue });
    await ctx.answerCbQuery(newValue ? '🟢 Enabled' : '🔴 Disabled');
    await sendPaymentSettingsMenu(ctx);
  }

  bot.action('admin_togglefampay', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await toggleGatewayGuarded(ctx, 'fampayEnabled', 'binanceEnabled');
  });

  bot.action('admin_togglebinance', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await toggleGatewayGuarded(ctx, 'binanceEnabled', 'fampayEnabled');
  });

  bot.action('admin_editfamkey', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_fam_apikey' };
    await ctx.reply('🔑 Send the new FamPay API key:');
  });

  bot.action('admin_editfamurl', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_fam_baseurl' };
    await ctx.reply('🌐 Send the new FamPay base URL:');
  });

  bot.action('admin_editfamupi', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_fam_upi' };
    await ctx.reply('💰 Send the new UPI ID (e.g. yourname@fam):');
  });

  bot.action('admin_editbinanceid', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_binance_id' };
    await ctx.reply('📤 Send the new Binance ID / UID (jahan users payment bhejenge):');
  });

  bot.action('admin_editusdrate', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_usd_rate' };
    await ctx.reply('💱 Naya rate bhejo — ₹ kitne ka $1 hai? (e.g. 90):');
  });

  bot.action('admin_editfamtc', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_fam_tc' };
    await ctx.reply('📜 Send the new Terms & Conditions text (shown to users before every payment). Markdown formatting supported:');
  });

  bot.action('admin_setwelcome', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_welcome_message' };
    await ctx.reply('✏️ Send the new welcome message. Use {name} for the user\'s first name:');
  });

  bot.action('admin_togglemaintenance', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const settings = await fb.getBotSettings();
    await fb.updateBotSettings({ maintenanceMode: !settings.maintenanceMode });
    await ctx.answerCbQuery(settings.maintenanceMode ? '🟢 Maintenance OFF' : '🔴 Maintenance ON');
  });

  bot.action('admin_channels', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await sendChannelsMenu(ctx);
  });

  async function sendChannelsMenu(ctx) {
    const settings = await fb.getBotSettings();
    const channels = settings.channels || [];
    let text = '📢 *Required Channels*\n\n';
    if (channels.length === 0) text += '_None set._';

    const buttons = channels.map((c, i) => [
      Markup.button.callback(`${c.required ? '✅' : '⬜'} @${c.username}`, `admin_togglechannel_${i}`),
      Markup.button.callback('🗑', `admin_removechannel_${i}`)
    ]);
    buttons.push([Markup.button.callback('➕ Add Channel', 'admin_addchannel')]);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_settings')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action('admin_addchannel', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_channel_username', data: {} };
    await ctx.reply('Send a channel username (without @) to add it as required. Make sure the bot is an admin in that channel!');
  });

  bot.action(/^admin_togglechannel_(\d+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const idx = parseInt(ctx.match[1]);
    const settings = await fb.getBotSettings();
    const channels = settings.channels || [];
    if (channels[idx]) channels[idx].required = !channels[idx].required;
    await fb.updateBotSettings({ channels });
    await ctx.answerCbQuery('Updated');
    await sendChannelsMenu(ctx);
  });

  bot.action(/^admin_removechannel_(\d+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const idx = parseInt(ctx.match[1]);
    const settings = await fb.getBotSettings();
    const channels = settings.channels || [];
    channels.splice(idx, 1);
    await fb.updateBotSettings({ channels });
    await ctx.answerCbQuery('🗑️ Removed');
    await sendChannelsMenu(ctx);
  });

  bot.action('admin_setsupport', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_support_telegram', data: {} };
    await ctx.reply('💬 Send support Telegram username (without @), or "skip":');
  });

  // ============ MENU BUTTONS MANAGER ============

  const MENU_LABEL_KEYS = {
    profile: '👤 My Profile', wallet: '💰 Wallet', browse: '🛍 Browse Products', free: '🎁 Free Products',
    proplan: '👑 Pro Plan', purchases: '📦 My Purchases', orders: '📋 Order Status',
    referrals: '🔗 My Referrals', stats: '📊 My Stats', paymenthistory: '🧾 Payment History',
    support: '📞 Support', language: '🌐 Hindi / English', checkin: '🎯 Daily Check-in',
    leaderboard: '🏆 Leaderboard'
  };

  bot.action('admin_menubuttons', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await sendMenuButtonsMenu(ctx);
  });

  async function sendMenuButtonsMenu(ctx) {
    const settings = await fb.getBotSettings();
    const customButtons = settings.menuCustomButtons || [];

    let text = '🔘 *Menu Buttons Manager*\n\nRename any built-in button, or add unlimited custom link buttons to the main menu.';

    const buttons = [
      [Markup.button.callback('✏️ Rename Built-in Buttons', 'admin_renamebuttons')],
      [Markup.button.callback('🎨 Button Colours', 'admin_btncolors')],
      [Markup.button.callback('👁 Show / Hide Buttons', 'admin_btnvisibility')],
      [Markup.button.callback('➕ Add Custom Link Button', 'admin_addmenubutton')]
    ];
    customButtons.forEach((btn, i) => {
      buttons.push([
        Markup.button.callback(`${bs.STYLE_ICON[bs.normStyle(btn.style || 'primary')]} ${btn.text}`, `admin_custcolor_${i}`),
        Markup.button.callback('🗑', `admin_removemenubutton_${i}`)
      ]);
    });
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action('noop', async (ctx) => { await ctx.answerCbQuery(); });

  // ---- Button colours: tap a button to cycle Blue → Green → Red → Default ----
  async function renderColorPicker(ctx, edit) {
    const settings = await fb.getBotSettings();
    const labels = { ...MENU_LABEL_KEYS, ...(settings.menuLabels || {}) };
    const rows = Object.keys(MENU_LABEL_KEYS).map(key => {
      const st = bs.menuColor(settings, key);
      return [Markup.button.callback(`${bs.STYLE_ICON[st]} ${labels[key]} — ${bs.STYLE_NAME[st]}`, `admin_setcolor_${key}`)];
    });
    rows.push([Markup.button.callback('♻️ Reset All to Default', 'admin_resetcolors')]);
    rows.push([Markup.button.callback('⬅️ Back', 'admin_menubuttons')]);
    const text = '🎨 *Button Colours*\n\nTap a button to change its colour (Blue → Green → Red → Default).\nUsers see the new colours immediately.';
    if (edit) {
      try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) }); return; } catch (e) { /* fall through */ }
    }
    await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
  }

  bot.action('admin_btncolors', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await renderColorPicker(ctx, false);
  });

  bot.action(/^admin_setcolor_(\w+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const key = ctx.match[1];
    if (!MENU_LABEL_KEYS[key]) return ctx.answerCbQuery('Unknown button');
    const settings = await fb.getBotSettings();
    const menuColors = { ...(settings.menuColors || {}) };
    menuColors[key] = bs.nextStyle(bs.menuColor(settings, key));
    await fb.updateBotSettings({ menuColors });
    await ctx.answerCbQuery(`${bs.STYLE_ICON[menuColors[key]]} ${bs.STYLE_NAME[menuColors[key]]}`);
    await renderColorPicker(ctx, true);
  });

  bot.action('admin_resetcolors', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await fb.updateBotSettings({ menuColors: {} });
    await ctx.answerCbQuery('♻️ Reset');
    await renderColorPicker(ctx, true);
  });

  bot.action(/^admin_custcolor_(\d+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const idx = parseInt(ctx.match[1]);
    const settings = await fb.getBotSettings();
    const customButtons = [...(settings.menuCustomButtons || [])];
    if (!customButtons[idx]) return ctx.answerCbQuery('Not found');
    customButtons[idx] = { ...customButtons[idx], style: bs.nextStyle(customButtons[idx].style || 'primary') };
    await fb.updateBotSettings({ menuCustomButtons: customButtons });
    await ctx.answerCbQuery(`${bs.STYLE_ICON[customButtons[idx].style]} ${bs.STYLE_NAME[customButtons[idx].style]}`);
    await sendMenuButtonsMenu(ctx);
  });

  // ---- Show / Hide main-menu buttons ----
  async function renderVisibility(ctx, edit) {
    const settings = await fb.getBotSettings();
    const labels = { ...MENU_LABEL_KEYS, ...(settings.menuLabels || {}) };
    const rows = Object.keys(MENU_LABEL_KEYS).map(key => {
      const hidden = bs.isHidden(settings, key);
      return [Markup.button.callback(`${hidden ? '🚫 Hidden' : '✅ Visible'} — ${labels[key]}`, `admin_togglehide_${key}`)];
    });
    rows.push([Markup.button.callback('👁 Show All', 'admin_showall')]);
    rows.push([Markup.button.callback('⬅️ Back', 'admin_menubuttons')]);
    const text = '👁 *Show / Hide Buttons*\n\nTap to hide or show a button on the user Home menu.\nHidden buttons disappear from the menu; your data stays safe.';
    if (edit) {
      try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) }); return; } catch (e) { /* fall through */ }
    }
    await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) });
  }

  bot.action('admin_btnvisibility', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await renderVisibility(ctx, false);
  });

  bot.action(/^admin_togglehide_(\w+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const key = ctx.match[1];
    if (!MENU_LABEL_KEYS[key]) return ctx.answerCbQuery('Unknown button');
    const settings = await fb.getBotSettings();
    const menuHidden = { ...(settings.menuHidden || {}) };
    if (menuHidden[key]) delete menuHidden[key]; else menuHidden[key] = true;
    await fb.updateBotSettings({ menuHidden });
    await ctx.answerCbQuery(menuHidden[key] ? '🚫 Hidden' : '✅ Visible');
    await renderVisibility(ctx, true);
  });

  bot.action('admin_showall', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await fb.updateBotSettings({ menuHidden: {} });
    await ctx.answerCbQuery('✅ All visible');
    await renderVisibility(ctx, true);
  });


  bot.action('admin_renamebuttons', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    const settings = await fb.getBotSettings();
    const labels = { ...MENU_LABEL_KEYS, ...(settings.menuLabels || {}) };

    const buttons = Object.keys(MENU_LABEL_KEYS).map(key => [Markup.button.callback(labels[key], `admin_renamebtn_${key}`)]);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_menubuttons')]);
    await ctx.reply('Tap a button to rename it:', Markup.inlineKeyboard(buttons));
  });

  bot.action(/^admin_renamebtn_(.+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const key = ctx.match[1];
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_button_rename', data: { key } };
    await ctx.reply(`New label for this button? (include emoji if you want one)`);
  });

  bot.action('admin_addmenubutton', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'menubutton_text', data: {} };
    await ctx.reply('🔗 Button text? (e.g. "Join Community")');
  });

  bot.action(/^admin_removemenubutton_(\d+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const idx = parseInt(ctx.match[1]);
    const settings = await fb.getBotSettings();
    const customButtons = settings.menuCustomButtons || [];
    customButtons.splice(idx, 1);
    await fb.updateBotSettings({ menuCustomButtons: customButtons });
    await ctx.answerCbQuery('🗑️ Removed');
    await sendMenuButtonsMenu(ctx);
  });

  // ============ DAILY CHECK-IN SETTINGS ============

  bot.action('admin_checkin', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    const settings = await fb.getCheckInSettings();
    await ctx.reply(
      `🎯 *Daily Check-in*\n\nStatus: ${settings.active ? '✅ Active' : '🚫 Disabled'}\nBase Reward: ₹${settings.rewardAmount}`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback(settings.active ? '🚫 Disable' : '✅ Enable', 'admin_togglecheckin')],
          [Markup.button.callback('✏️ Edit Reward', 'admin_editcheckinreward')],
          [Markup.button.callback('⬅️ Back', 'admin_home')]
        ])
      }
    );
  });

  bot.action('admin_togglecheckin', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const settings = await fb.getCheckInSettings();
    await fb.setCheckInSettings({ ...settings, active: !settings.active });
    await ctx.answerCbQuery(settings.active ? '🚫 Disabled' : '✅ Enabled');
  });

  bot.action('admin_editcheckinreward', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_checkin_reward', data: {} };
    await ctx.reply('💰 New base reward amount (₹)?');
  });

  // ============ MESSAGE HISTORY ============

  bot.action('admin_msghistory', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    await ctx.reply('📜 *Message History*\n\nChoose which history to view:', {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('📩 DM History', 'admin_dmhistory_0')],
        [Markup.button.callback('📢 Broadcast History', 'admin_bchistory_0')],
        [Markup.button.callback('⬅️ Back', 'admin_home')]
      ])
    });
  });

  bot.action(/^admin_dmhistory_(\d+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const page = parseInt(ctx.match[1]);
    await ctx.answerCbQuery();
    const queue = await fb.getDmQueue();
    const entries = Object.entries(queue).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
    const pageSize = 5;
    const pageItems = entries.slice(page * pageSize, (page + 1) * pageSize);

    let text = `📩 *DM History* (${entries.length} total)\n\n`;
    if (pageItems.length === 0) text += '_No messages yet._';
    const buttons = [];
    pageItems.forEach(([id, d]) => {
      const status = d.sent ? (d.success !== false ? '✅' : '❌') : '⏳';
      const seen = d.seen ? '👁' : '';
      text += `${status}${seen} \`${d.userId}\` — ${(d.message || '').slice(0, 40)}\n`;
      if (d.sentChatId && !d.deleted) buttons.push([Markup.button.callback(`🗑 Unsend to ${d.userId}`, `admin_unsenddm_${id}`)]);
    });
    const navRow = [];
    if (page > 0) navRow.push(Markup.button.callback('⬅️ Prev', `admin_dmhistory_${page - 1}`));
    if ((page + 1) * pageSize < entries.length) navRow.push(Markup.button.callback('Next ➡️', `admin_dmhistory_${page + 1}`));
    if (navRow.length) buttons.push(navRow);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_msghistory')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  });

  bot.action(/^admin_unsenddm_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const id = ctx.match[1];
    await fb.updateDmEntry(id, { deleteRequested: true });
    await ctx.answerCbQuery('📤 Unsend requested — processing...');
  });

  bot.action(/^admin_bchistory_(\d+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const page = parseInt(ctx.match[1]);
    await ctx.answerCbQuery();
    const queue = await fb.getBroadcastQueue();
    const entries = Object.entries(queue).sort((a, b) => (b[1].createdAt || 0) - (a[1].createdAt || 0));
    const pageSize = 5;
    const pageItems = entries.slice(page * pageSize, (page + 1) * pageSize);

    let text = `📢 *Broadcast History* (${entries.length} total)\n\n`;
    if (pageItems.length === 0) text += '_No broadcasts yet._';
    const buttons = [];
    pageItems.forEach(([id, b]) => {
      const status = b.sent ? `✅ ${b.sentCount ?? 0}/${b.targetCount ?? '?'}` : '⏳ sending...';
      text += `${status} 👁${b.seenCount || 0} — ${(b.message || '').slice(0, 35)}\n`;
      if (b.sentMessages && !b.deleted) buttons.push([Markup.button.callback('🗑 Unsend from everyone', `admin_unsendbc_${id}`)]);
    });
    const navRow = [];
    if (page > 0) navRow.push(Markup.button.callback('⬅️ Prev', `admin_bchistory_${page - 1}`));
    if ((page + 1) * pageSize < entries.length) navRow.push(Markup.button.callback('Next ➡️', `admin_bchistory_${page + 1}`));
    if (navRow.length) buttons.push(navRow);
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_msghistory')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  });

  bot.action(/^admin_unsendbc_(.+)$/, async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    const id = ctx.match[1];
    await fb.updateBroadcastEntry(id, { deleteRequested: true });
    await ctx.answerCbQuery('📤 Unsend requested — processing for all recipients...');
  });

  // ============ STAFF SYSTEM ============

  bot.action('admin_staff', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    await sendStaffMenu(ctx);
  });

  async function sendStaffMenu(ctx) {
    const staff = await fb.getAllStaff();
    const entries = Object.entries(staff);

    let text = `🧑‍💼 *Staff* (${entries.length})\n\nStaff can access Products, Orders, Users, Binance Payments, Coupons, Broadcast, and Message History — but not Bot Settings, Pro Plan, Menu Buttons, Check-in settings, or Staff management.\n\n`;
    if (entries.length === 0) text += '_No staff added yet._';
    entries.forEach(([id, s]) => { text += `👤 \`${id}\`\n`; });

    const buttons = [[Markup.button.callback('➕ Add Staff', 'admin_addstaff')]];
    entries.forEach(([id]) => buttons.push([Markup.button.callback(`🗑 Remove ${id}`, `admin_removestaff_${id}`)]));
    buttons.push([Markup.button.callback('⬅️ Back', 'admin_home')]);

    try { await ctx.editMessageText(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
    catch (e) { await ctx.reply(text, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }); }
  }

  bot.action('admin_addstaff', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'awaiting_staff_id', data: {} };
    await ctx.reply('🧑‍💼 Enter the Telegram ID to make staff:');
  });

  bot.action(/^admin_removestaff_(.+)$/, async (ctx) => {
    if (!(await isOwner(ctx))) return;
    const id = ctx.match[1];
    await fb.removeStaff(id);
    await ctx.answerCbQuery('🗑️ Removed');
    await sendStaffMenu(ctx);
  });

  // ============ PRO PLAN ============

  bot.action('admin_proplan', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    const settings = await fb.getProPlanSettings();
    await ctx.reply(`👑 *Pro Plan Settings*\n\n💰 Price: ₹${settings.price}\n📅 Duration: ${settings.durationDays} days`, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✏️ Edit', 'admin_editproplan')],
        [Markup.button.callback('⬅️ Back', 'admin_home')]
      ])
    });
  });

  bot.action('admin_editproplan', async (ctx) => {
    if (!(await isOwner(ctx))) return;
    await ctx.answerCbQuery();
    adminState[ctx.from.id] = { step: 'proplan_price', data: {} };
    await ctx.reply('👑 New price (₹)?');
  });

  // ============ SALES REPORT ============

  bot.action('admin_report', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    const weekly = await fb.getSalesReport(7);
    const monthly = await fb.getSalesReport(30);
    const text = `📊 *Sales Report*\n\n*Last 7 days:*\n💰 ₹${weekly.totalSales} — ${weekly.orderCount} orders\n${weekly.topProducts.join('\n')}\n\n*Last 30 days:*\n💰 ₹${monthly.totalSales} — ${monthly.orderCount} orders\n${monthly.topProducts.join('\n')}`;
    await ctx.reply(text, { parse_mode: 'Markdown', ...adminBackButton() });
  });

  // ============ LEADERBOARD ============

  bot.action('admin_leaderboard', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery();
    const [buyers, referrers] = await Promise.all([fb.getTopBuyers(5), fb.getTopReferrers(5)]);
    let text = '🏆 *Leaderboard*\n\n💰 *Top Buyers*\n';
    buyers.forEach((b, i) => { text += `${i + 1}. ${mdEscape(b.name)} — ₹${b.totalSpent}\n`; });
    text += '\n🔗 *Top Referrers*\n';
    referrers.forEach((r, i) => { text += `${i + 1}. ${mdEscape(r.name)} — ${r.referralCount}\n`; });
    await ctx.reply(text, { parse_mode: 'Markdown', ...adminBackButton() });
  });

  // ============ BACKUP ============

  bot.action('admin_backup', async (ctx) => {
    if (!(await isAdminOrStaff(ctx))) return;
    await ctx.answerCbQuery('Generating backup...');
    const backup = fb.getFullBackup();
    const json = JSON.stringify(backup, null, 2);
    const buffer = Buffer.from(json, 'utf8');
    await ctx.replyWithDocument(
      { source: buffer, filename: `backup_${new Date().toISOString().slice(0, 10)}.json` },
      { caption: '💾 Full data backup. Keep this safe — local storage is wiped on every redeploy!' }
    );
  });

  // ============ SHARED TEXT HANDLER FOR ALL WIZARDS ============
  // Returns true if it handled the message (so bot.js's own text handler
  // knows to skip its own processing for this update).

  async function handleAdminText(ctx) {
    const state = adminState[ctx.from.id];
    if (!state || !isAdmin(ctx)) return false;

    const text = ctx.message.text.trim();

    // ---- Reseller (Qamify) settings wizards ----
    if (state.step && state.step.startsWith('awaiting_qm_')) {
      return resellerAdmin.handleText(ctx, state, text);
    }

    // ---- Single-field edit (from the Edit menu) ----
    if (state.step === 'prod_editfield') {
      return handleEditFieldText(ctx, state, text);
    }

    // ---- Product add/edit wizard (used only for "Add Product") ----
    if (state.step && state.step.startsWith('prod_')) {
      return handleProductWizard(ctx, state, text);
    }

    // ---- Coupon creation wizard ----
    if (state.step && state.step.startsWith('coupon_')) {
      return handleCouponWizard(ctx, state, text);
    }

    // ---- Pro Plan edit wizard ----
    if (state.step === 'proplan_price') {
      const price = parseInt(text);
      if (isNaN(price)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
      state.data.price = price;
      state.step = 'proplan_duration';
      await ctx.reply('📅 Duration (days)?');
      return true;
    }
    if (state.step === 'proplan_duration') {
      const days = parseInt(text);
      if (isNaN(days)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
      await fb.setProPlanSettings({ price: state.data.price, durationDays: days, active: true });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Pro Plan updated: ₹${state.data.price} for ${days} days.`);
      return true;
    }

    // ---- Simple single-step flows ----
    if (state.step === 'awaiting_wallet_amount') {
      const amount = parseInt(text);
      if (isNaN(amount) || amount < 0) { await ctx.reply('⚠️ Valid amount daalo.'); return true; }
      const users = await fb.getAllUsers();
      const current = users[state.data.telegramId]?.walletBalance || 0;
      const delta = amount - current;
      if (delta > 0) await fb.creditWallet(state.data.telegramId, delta, 'admin_adjustment');
      else if (delta < 0) await fb.debitWallet(state.data.telegramId, -delta, 'admin_adjustment').catch(() => {});
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Wallet set to ₹${amount}.`);
      return true;
    }

    if (state.step === 'awaiting_ban_reason') {
      await fb.banUser(state.data.telegramId, text);
      delete adminState[ctx.from.id];
      await ctx.reply(`🚫 User ${state.data.telegramId} banned.\nReason: ${text}`);
      return true;
    }

    // ---- Direct Message wizard: userid -> message -> image? -> file? -> button? -> popup? -> send
    if (state.step === 'dm_userid') {
      state.data.telegramId = text;
      state.step = 'dm_message';
      await ctx.reply('📩 Now type the message:');
      return true;
    }
    if (state.step === 'dm_message') {
      state.data.message = text;
      state.step = 'dm_image';
      await ctx.reply('🖼 Send a photo to attach (or type "skip"):');
      return true;
    }
    if (state.step === 'dm_image') {
      if (text.toLowerCase() === 'skip') {
        state.step = 'dm_file';
        await ctx.reply('📎 Send a file to attach (or type "skip"):');
        return true;
      }
      await ctx.reply('⚠️ Send a photo, or type "skip".');
      return true;
    }
    if (state.step === 'dm_file') {
      if (text.toLowerCase() === 'skip') {
        state.step = 'dm_button';
        await ctx.reply('🔗 Add a button? Send as `Button Text | https://url.com`, or type "skip":', { parse_mode: 'Markdown' });
        return true;
      }
      await ctx.reply('⚠️ Send a file, or type "skip".');
      return true;
    }
    if (state.step === 'dm_button') {
      if (text.toLowerCase() !== 'skip') {
        const parts = text.split('|').map(s => s.trim());
        if (parts.length === 2) { state.data.buttonText = parts[0]; state.data.buttonUrl = parts[1]; }
      }
      state.step = 'dm_popup';
      await ctx.reply('🔔 Send as popup notification (with a Close ❌ button)? Reply "yes" or "no":', Markup.keyboard(['yes', 'no']).oneTime().resize());
      return true;
    }
    if (state.step === 'dm_popup') {
      state.data.isPopup = text.toLowerCase() === 'yes';
      await fb.queueDm({
        userId: state.data.telegramId, message: state.data.message,
        imageIds: state.data.imageId ? [state.data.imageId] : null,
        fileIds: state.data.fileId ? [state.data.fileId] : null,
        buttonText: state.data.buttonText || null, buttonUrl: state.data.buttonUrl || null,
        isPopup: state.data.isPopup
      });
      delete adminState[ctx.from.id];
      await ctx.reply('📩 Message queued — sending shortly.', Markup.removeKeyboard());
      return true;
    }

    // ---- Broadcast wizard: message -> image? -> file? -> button? -> popup? -> send
    if (state.step === 'bc_message') {
      state.data.message = text;
      state.step = 'bc_image';
      await ctx.reply('🖼 Send a photo to attach (or type "skip"):');
      return true;
    }
    if (state.step === 'bc_image') {
      if (text.toLowerCase() === 'skip') {
        state.step = 'bc_file';
        await ctx.reply('📎 Send a file to attach (or type "skip"):');
        return true;
      }
      await ctx.reply('⚠️ Send a photo, or type "skip".');
      return true;
    }
    if (state.step === 'bc_file') {
      if (text.toLowerCase() === 'skip') {
        state.step = 'bc_button';
        await ctx.reply('🔗 Add a button? Send as `Button Text | https://url.com`, or type "skip":', { parse_mode: 'Markdown' });
        return true;
      }
      await ctx.reply('⚠️ Send a file, or type "skip".');
      return true;
    }
    if (state.step === 'bc_button') {
      if (text.toLowerCase() !== 'skip') {
        const parts = text.split('|').map(s => s.trim());
        if (parts.length === 2) { state.data.buttonText = parts[0]; state.data.buttonUrl = parts[1]; }
      }
      state.step = 'bc_popup';
      await ctx.reply('🔔 Send as popup notification (with a Close ❌ button)? Reply "yes" or "no":', Markup.keyboard(['yes', 'no']).oneTime().resize());
      return true;
    }
    if (state.step === 'bc_popup') {
      state.data.isPopup = text.toLowerCase() === 'yes';
      await fb.queueBroadcast({
        message: state.data.message,
        imageIds: state.data.imageId ? [state.data.imageId] : null,
        fileIds: state.data.fileId ? [state.data.fileId] : null,
        buttonText: state.data.buttonText || null, buttonUrl: state.data.buttonUrl || null,
        isPopup: state.data.isPopup
      });
      delete adminState[ctx.from.id];
      await ctx.reply('📢 Broadcast queued — sending to all users shortly.', Markup.removeKeyboard());
      return true;
    }

    if (state.step === 'awaiting_welcome_message') {
      await fb.updateBotSettings({ welcomeMessage: text });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ Welcome message updated.');
      return true;
    }

    if (state.step === 'awaiting_channel_username') {
      const settings = await fb.getBotSettings();
      const channels = settings.channels || [];
      const username = text.replace('@', '');
      channels.push({ username, label: username, required: true });
      await fb.updateBotSettings({ channels });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Channel @${username} added as required. Make sure the bot is an admin in that channel!`);
      return true;
    }

    if (state.step === 'awaiting_support_telegram') {
      if (text.toLowerCase() !== 'skip') {
        await fb.updateBotSettings({ supportTelegram: text.replace('@', '') });
      }
      state.step = 'awaiting_support_whatsapp';
      await ctx.reply('📱 Send support WhatsApp number (with country code), or "skip":');
      return true;
    }
    if (state.step === 'awaiting_support_whatsapp') {
      if (text.toLowerCase() !== 'skip') {
        await fb.updateBotSettings({ supportWhatsapp: text.replace(/[^0-9]/g, '') });
      }
      delete adminState[ctx.from.id];
      await ctx.reply('✅ Support info updated.');
      return true;
    }

    if (state.step === 'awaiting_user_lookup') {
      delete adminState[ctx.from.id];
      await sendUserDetails(ctx, text);
      return true;
    }

    // ---- Payment Settings (FamPay) ----
    if (state.step === 'awaiting_fam_apikey') {
      await fb.updatePaymentSettings({ apiKey: text });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ FamPay API key updated.');
      return true;
    }
    if (state.step === 'awaiting_fam_baseurl') {
      await fb.updatePaymentSettings({ baseUrl: text });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ FamPay base URL updated.');
      return true;
    }
    if (state.step === 'awaiting_fam_upi') {
      await fb.updatePaymentSettings({ upiId: text });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ UPI ID updated to \`${text}\`.`, { parse_mode: 'Markdown' });
      return true;
    }
    if (state.step === 'awaiting_fam_tc') {
      await fb.updatePaymentSettings({ termsAndConditions: text });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ Terms & Conditions updated.');
      return true;
    }

    // ---- Payment Settings (Binance) ----
    if (state.step === 'awaiting_binance_id') {
      await fb.updatePaymentSettings({ binanceId: text });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Binance ID updated to \`${mdEscape(text)}\`.`, { parse_mode: 'Markdown' });
      return true;
    }
    if (state.step === 'awaiting_usd_rate') {
      const rate = parseFloat(text);
      if (isNaN(rate) || rate <= 0) {
        await ctx.reply('⚠️ Valid number daalo (e.g. 90).');
        return true;
      }
      await fb.updatePaymentSettings({ usdRate: rate });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Rate updated: ₹${rate} = $1`);
      return true;
    }

    // ---- Menu button rename ----
    if (state.step === 'awaiting_button_rename') {
      const settings = await fb.getBotSettings();
      const menuLabels = { ...(settings.menuLabels || {}) };
      menuLabels[state.data.key] = text;
      await fb.updateBotSettings({ menuLabels });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Button renamed to "${text}"`);
      return true;
    }

    // ---- Add custom menu button wizard ----
    if (state.step === 'menubutton_text') {
      state.data.text = text;
      state.step = 'menubutton_url';
      await ctx.reply('🔗 Button URL?');
      return true;
    }
    if (state.step === 'menubutton_url') {
      const settings = await fb.getBotSettings();
      const customButtons = [...(settings.menuCustomButtons || []), { text: state.data.text, url: text }];
      await fb.updateBotSettings({ menuCustomButtons: customButtons });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Custom button "${state.data.text}" added to main menu.`);
      return true;
    }

    // ---- Check-in reward edit ----
    if (state.step === 'awaiting_checkin_reward') {
      const amount = parseInt(text);
      if (isNaN(amount) || amount < 0) { await ctx.reply('⚠️ Valid amount daalo.'); return true; }
      const settings = await fb.getCheckInSettings();
      await fb.setCheckInSettings({ ...settings, rewardAmount: amount });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Check-in reward set to ₹${amount}.`);
      return true;
    }

    // ---- Add staff ----
    if (state.step === 'awaiting_staff_id') {
      await fb.addStaff(text, ['products', 'orders', 'users', 'coupons', 'broadcast']);
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ User \`${text}\` added as staff.`, { parse_mode: 'Markdown' });
      return true;
    }

    // ---- Referral settings wizard ----
    if (state.step === 'referral_type') {
      const type = text.toLowerCase();
      if (type !== 'flat' && type !== 'percent') { await ctx.reply('⚠️ Reply "flat" or "percent".'); return true; }
      state.data.bonusType = type;
      state.step = 'referral_amount';
      await ctx.reply(`Bonus amount? (${type === 'flat' ? '₹' : '%'})`, Markup.removeKeyboard());
      return true;
    }
    if (state.step === 'referral_amount') {
      const amount = parseInt(text);
      if (isNaN(amount)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
      await fb.setReferralSettings({ bonusType: state.data.bonusType, bonusAmount: amount });
      delete adminState[ctx.from.id];
      await ctx.reply(`✅ Referral bonus set: ${state.data.bonusType === 'percent' ? amount + '%' : '₹' + amount}`);
      return true;
    }

    return false;
  }

  // ---- Coupon creation wizard ----
  async function handleCouponWizard(ctx, state, text) {
    switch (state.step) {
      case 'coupon_code':
        state.data.code = text.toUpperCase();
        state.step = 'coupon_type';
        await ctx.reply('Step 2/4 — Discount type? Reply "flat" (₹ amount) or "percent" (%)', Markup.keyboard(['flat', 'percent']).oneTime().resize());
        return true;

      case 'coupon_type': {
        const type = text.toLowerCase();
        if (type !== 'flat' && type !== 'percent') { await ctx.reply('⚠️ Reply "flat" or "percent".'); return true; }
        state.data.discountType = type;
        state.step = 'coupon_value';
        await ctx.reply(`Step 3/4 — Discount value? (${type === 'flat' ? '₹ amount' : '% amount'})`, Markup.removeKeyboard());
        return true;
      }

      case 'coupon_value': {
        const value = parseInt(text);
        if (isNaN(value)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
        state.data.discountValue = value;
        state.step = 'coupon_limit';
        await ctx.reply('Step 4/4 — Usage limit? (number, or "unlimited")');
        return true;
      }

      case 'coupon_limit': {
        const limit = text.toLowerCase() === 'unlimited' ? null : parseInt(text);
        await fb.createCoupon(state.data.code, {
          discountType: state.data.discountType,
          discountValue: state.data.discountValue,
          usageLimit: isNaN(limit) ? null : limit,
          minAmount: 0
        });
        delete adminState[ctx.from.id];
        await ctx.reply(`✅ Coupon \`${state.data.code}\` created!`, { parse_mode: 'Markdown' });
        return true;
      }

      default:
        return false;
    }
  }

  // ---- Product add/edit wizard steps ----
  async function handleProductWizard(ctx, state, text) {
    const skip = text.toLowerCase() === 'skip' && state.data.isEdit;

    switch (state.step) {
      case 'prod_name':
        if (!skip) state.data.name = text;
        state.step = 'prod_price';
        await ctx.reply(`Step 2/8 — Price (₹, 0 for free)?${state.data.isEdit ? ` Current: ${state.data.price}` : ''}`);
        return true;

      case 'prod_price': {
        if (!skip) {
          const price = parseInt(text);
          if (isNaN(price)) { await ctx.reply('⚠️ Valid number daalo.'); return true; }
          state.data.price = price;
        }
        state.step = 'prod_category';
        await ctx.reply(`Step 3/8 — Category?${state.data.isEdit ? ` Current: ${state.data.category}` : ''}`);
        return true;
      }

      case 'prod_category':
        if (!skip) state.data.category = text;
        state.step = 'prod_description';
        await ctx.reply('Step 4/8 — Description? (or "skip")');
        return true;

      case 'prod_description':
        if (text.toLowerCase() !== 'skip') state.data.description = text;
        state.step = 'prod_stock';
        await ctx.reply('Step 5/8 — Stock quantity? (-1 for unlimited)');
        return true;

      case 'prod_stock': {
        const stock = parseInt(text);
        state.data.stock = isNaN(stock) ? -1 : stock;
        state.step = 'prod_deliverytype';
        await ctx.reply('Step 6/8 — Delivery type? Reply "file" or "link"', Markup.keyboard(['file', 'link']).oneTime().resize());
        return true;
      }

      case 'prod_deliverytype': {
        const type = text.toLowerCase();
        if (type !== 'file' && type !== 'link') { await ctx.reply('⚠️ Reply "file" or "link".'); return true; }
        state.data.deliveryType = type;
        state.step = 'prod_deliveryvalue';
        if (type === 'file') {
          await ctx.reply('Step 7/8 — Now send the FILE (as document) you want delivered:', Markup.removeKeyboard());
        } else {
          await ctx.reply('Step 7/8 — Send the download link (URL):', Markup.removeKeyboard());
        }
        return true;
      }

      case 'prod_deliveryvalue':
        if (state.data.deliveryType === 'link') {
          state.data.deliveryLink = text;
          state.step = 'prod_image';
          await ctx.reply('Step 8/8 — Send a product image (photo), or type "skip":');
          return true;
        }
        await ctx.reply('⚠️ Please send the file as a document, not text.');
        return true;

      case 'prod_image':
        if (text.toLowerCase() === 'skip') {
          await finalizeProduct(ctx, state);
          return true;
        }
        await ctx.reply('⚠️ Send a photo, or type "skip".');
        return true;

      default:
        return false;
    }
  }

  async function finalizeProduct(ctx, state) {
    const d = state.data;
    const imageFileIds = d.imageFileIds && d.imageFileIds.length > 0 ? d.imageFileIds : (d.imageFileId ? [d.imageFileId] : []);
    const productData = {
      name: d.name, price: d.price, category: d.category,
      description: d.description || '', stock: d.stock,
      deliveryType: d.deliveryType,
      fileId: d.fileId || '',
      deliveryLink: d.deliveryLink || '',
      imageUrl: '',
      imageFileId: imageFileIds[0] || null,
      imageFileIds: imageFileIds.length > 0 ? imageFileIds : null
    };

    if (d.isEdit) {
      await fb.updateProduct(d.productId, productData);
      await ctx.reply(`✅ Product updated: *${mdEscape(d.name)}*${imageFileIds.length > 1 ? ` (${imageFileIds.length} images)` : ''}`, { parse_mode: 'Markdown' });
    } else {
      await fb.createProduct(productData);
      await ctx.reply(`✅ Product added: *${mdEscape(d.name)}*${imageFileIds.length > 1 ? ` (${imageFileIds.length} images)` : ''}\n\nUsers will be notified automatically! 🆕`, { parse_mode: 'Markdown' });
    }
    delete adminState[ctx.from.id];
  }

  // Called from bot.js's document/photo handlers when an admin is mid-wizard
  async function handleAdminDocument(ctx) {
    const state = adminState[ctx.from.id];
    if (!state) return false;

    if (state.step === 'prod_editfield' && state.data.field === 'deliveryvalue') {
      const { productId } = state.data;
      const p = await fb.getProduct(productId);
      if (!p || p.deliveryType !== 'file') { await ctx.reply('⚠️ Send text/link instead, this product uses link delivery.'); return true; }
      await fb.updateProduct(productId, { fileId: ctx.message.document.file_id });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ File updated!');
      const updated = await fb.getProduct(productId);
      await sendEditFieldMenu(ctx, productId, updated);
      return true;
    }

    if (state.step === 'prod_deliveryvalue' && state.data.deliveryType === 'file') {
      state.data.fileId = ctx.message.document.file_id;
      state.step = 'prod_image';
      await ctx.reply('✅ File saved.\n\nStep 8/8 — Send a product image (photo), or type "skip":');
      return true;
    }

    if (state.step === 'dm_file') {
      state.data.fileId = ctx.message.document.file_id;
      state.step = 'dm_button';
      await ctx.reply('✅ File attached.\n\n🔗 Add a button? Send as `Button Text | https://url.com`, or type "skip":', { parse_mode: 'Markdown' });
      return true;
    }
    if (state.step === 'bc_file') {
      state.data.fileId = ctx.message.document.file_id;
      state.step = 'bc_button';
      await ctx.reply('✅ File attached.\n\n🔗 Add a button? Send as `Button Text | https://url.com`, or type "skip":', { parse_mode: 'Markdown' });
      return true;
    }

    return false;
  }

  async function handleAdminPhoto(ctx) {
    const state = adminState[ctx.from.id];
    if (!state) return false;
    const sizes = ctx.message.photo;
    const fileId = sizes[sizes.length - 1].file_id;
    const mediaGroupId = ctx.message.media_group_id || null;

    if (state.step === 'prod_editfield' && state.data.field === 'image') {
      const { productId } = state.data;
      await fb.updateProduct(productId, { imageFileId: fileId, imageFileIds: [fileId] });
      delete adminState[ctx.from.id];
      await ctx.reply('✅ Image updated!');
      const updated = await fb.getProduct(productId);
      await sendEditFieldMenu(ctx, productId, updated);
      return true;
    }

    if (state.step === 'prod_image') {
      // Telegram's multi-select photo picker sends each photo as a SEPARATE
      // message sharing the same media_group_id — not one message with many
      // photos. We collect them into an array and only finalize once, after
      // a short debounce window (so the last photo in the album has time to
      // arrive) instead of finalizing on the very first photo received.
      if (!state.data.imageFileIds) state.data.imageFileIds = [];
      state.data.imageFileIds.push(fileId);

      if (!mediaGroupId) {
        // Single photo, no album — finalize immediately as before.
        await finalizeProduct(ctx, state);
        return true;
      }

      // Part of an album — debounce so we catch all photos in the group
      // before creating the product once with every image attached.
      if (state.data._mediaGroupTimer) clearTimeout(state.data._mediaGroupTimer);
      state.data._mediaGroupId = mediaGroupId;
      state.data._mediaGroupTimer = setTimeout(async () => {
        if (!adminState[ctx.from.id]) return; // already finalized/cancelled
        await finalizeProduct(ctx, state);
      }, 1200);
      return true;
    }

    if (state.step === 'dm_image') {
      state.data.imageId = fileId;
      state.step = 'dm_file';
      await ctx.reply('✅ Photo attached.\n\n📎 Send a file to attach (or type "skip"):');
      return true;
    }
    if (state.step === 'bc_image') {
      state.data.imageId = fileId;
      state.step = 'bc_file';
      await ctx.reply('✅ Photo attached.\n\n📎 Send a file to attach (or type "skip"):');
      return true;
    }

    return false;
  }

  return { handleAdminText, handleAdminDocument, handleAdminPhoto, isAdmin, isAdminOrStaff, adminState };
}

module.exports = { setupAdminPanel };
