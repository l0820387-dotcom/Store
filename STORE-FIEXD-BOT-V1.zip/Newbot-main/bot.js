require('dotenv').config();
const { Telegraf, Markup } = require('telegraf');
const express = require('express');
const fb = require('./localdb');
const fampay = require('./fampay');
const { setupAdminPanel } = require('./adminPanel');
const reseller = require('./reseller');
const bs = require('./buttonStyle');
const crypto = require('crypto');

const bot = new Telegraf(process.env.BOT_TOKEN);
bs.installAutoStyle(bot); // coloured buttons (blue/green/red) on every screen
const app = express();
app.use(express.json());

// In-memory temp state (for multi-step flows like "buy via wallet confirm")
const userState = {}; // { telegramId: { step, data } }

// ============ EDIT-IN-PLACE NAVIGATION ============
// We edit the previous bot message when possible so the chat stays clean.
// editMessageText fails on photo/media-group messages (Telegram limitation) —
// in that case we delete the old message and send a fresh one instead of
// leaving a stray photo behind, which is what caused the "jumpy" feel.

// Escapes Telegram Markdown (legacy) special characters in dynamic values
// (names, product titles, etc.) so user-generated or DB text never breaks
// message parsing. Use around any {variable} inserted into a Markdown string.
function mdEscape(text) {
  if (text === undefined || text === null) return '';
  // Strip lone/unpaired UTF-16 surrogates first — these are what make
  // Telegram reject a request outright with an opaque "must be encoded in
  // UTF-8" error. They can slip in from copy-pasted "stylish" fancy-text
  // fonts or emoji, especially if some other code path truncated the
  // string at an unsafe boundary before it got here. Doing this inside
  // mdEscape itself means every existing call site is automatically
  // protected, not just the ones explicitly updated to call
  // sanitizeForTelegram first.
  let s = String(text);
  s = s.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g, '');
  s = s.replace(/(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '');
  return s.replace(/([_*[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

// Sanitizes any admin/user-provided text before it goes into a Telegram
// button label or message. Strips lone/unpaired UTF-16 surrogates (the
// cause of Telegram's opaque "must be encoded in UTF-8" rejection — these
// can come from copy-pasted "stylish" fancy-text fonts, or from naive
// truncation elsewhere cutting a multi-byte character in half), plus
// zero-width and control characters that can also trip Telegram's strict
// validation. Optionally hard-caps length without ever splitting a valid
// surrogate pair in the process.
function sanitizeForTelegram(text, maxLen) {
  if (text === undefined || text === null) return '';
  let s = String(text);

  s = s.replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g, '');   // lone high surrogate
  s = s.replace(/(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, '');   // lone low surrogate
  s = s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u200B-\u200F\u2028\u2029\uFEFF]/g, '');
  s = s.trim();

  if (maxLen && s.length > maxLen) {
    let sliced = s.slice(0, maxLen);
    const lastCode = sliced.charCodeAt(sliced.length - 1);
    if (lastCode >= 0xD800 && lastCode <= 0xDBFF) sliced = sliced.slice(0, -1);
    s = sliced;
  }
  return s;
}

// Truncates an ALREADY markdown-escaped/formatted string to at most maxLen
// characters without ever leaving an odd number of (unescaped) "*" bold
// markers behind — which would make Telegram reject the whole message as
// malformed Markdown. Used as a last-resort safety net for captions, on
// top of (not instead of) capping the raw description length up front.
function truncateMarkdownSafe(text, maxLen) {
  if (text.length <= maxLen) return text;
  let cut = text.slice(0, maxLen - 1); // leave room for the trailing ellipsis
  const lastNewline = cut.lastIndexOf('\n');
  if (lastNewline > maxLen * 0.5) cut = cut.slice(0, lastNewline);
  const starCount = (cut.match(/(?<!\\)\*/g) || []).length;
  if (starCount % 2 !== 0) {
    const idx = cut.lastIndexOf('*');
    if (idx !== -1) cut = cut.slice(0, idx);
  }
  return cut + '…';
}

// Sets up all /admin commands and callback handlers (products, orders,
// users, coupons, broadcast, settings, backup) — see adminPanel.js.
const adminPanel = setupAdminPanel(bot, fb, mdEscape);

async function smartReply(ctx, text, extra = {}) {
  const payload = { parse_mode: 'Markdown', ...extra };

  if (ctx.callbackQuery) {
    try {
      const edited = await ctx.editMessageText(text, payload);
      // editMessageText returns `true` for inline messages or the message
      // object for regular ones — normalize to the original message.
      return typeof edited === 'object' ? edited : ctx.callbackQuery.message;
    } catch (err) {
      // Can't edit (likely a photo message, or a Markdown parse error) —
      // clean up instead of stacking messages
      try { await ctx.deleteMessage(); } catch (e) { /* delete also failed, fine — we still send below */ }
    }
  }

  // Guaranteed to run if edit wasn't possible. If Markdown parsing itself is
  // the problem, retry once as plain text so the user always sees *something*.
  try {
    return await ctx.reply(text, payload);
  } catch (err) {
    return await ctx.reply(text, { ...extra, parse_mode: undefined });
  }
}

// ---- Navigation stack: tracks which screen to return to on "Back" ----
// Stored per-user in memory. Each screen push is just an action name string
// (e.g. 'menu_profile', 'cat_Bots') that we can re-trigger to go back.
const navStack = {}; // { telegramId: ['menu_home', 'menu_browse', 'cat_Bots'] }

function pushNav(telegramId, screen) {
  if (!navStack[telegramId]) navStack[telegramId] = [];
  const stack = navStack[telegramId];
  if (stack[stack.length - 1] !== screen) stack.push(screen);
  if (stack.length > 15) stack.shift(); // cap memory use per user
}

function popNav(telegramId) {
  const stack = navStack[telegramId];
  if (!stack || stack.length <= 1) return 'menu_home';
  stack.pop(); // remove current screen
  return stack[stack.length - 1] || 'menu_home';
}

function navButtons(extraRows, telegramId) {
  const stack = navStack[telegramId];
  const canGoBack = stack && stack.length > 1;
  const row = canGoBack
    ? [Markup.button.callback('⬅️ Back', 'nav_back'), Markup.button.callback('🏠 Home', 'menu_home')]
    : [Markup.button.callback('🏠 Home', 'menu_home')];
  return Markup.inlineKeyboard(extraRows ? [...extraRows, row] : [row]);
}

// ============ SEEN TRACKING (runs first, before any middleware that might
// short-circuit the request) ============
// Marks any pending DM/broadcast as "seen" whenever the user sends any
// update to the bot at all — this is the closest proxy Telegram's Bot API
// allows for read-receipts, since bots have no real access to that data.

bot.use(async (ctx, next) => {
  if (ctx.from) {
    try {
      const dmId = await fb.getUserField(ctx.from.id, 'lastUnseenDmId');
      if (dmId) {
        await fb.updateDmEntry(dmId, { seen: true, seenAt: Date.now() });
        await fb.clearUserField(ctx.from.id, 'lastUnseenDmId');
      }

      const bId = await fb.getUserField(ctx.from.id, 'lastUnseenBroadcastId');
      if (bId) {
        const queue = await fb.getBroadcastQueue();
        const current = queue[bId]?.seenCount || 0;
        await fb.updateBroadcastEntry(bId, { seenCount: current + 1 });
        await fb.clearUserField(ctx.from.id, 'lastUnseenBroadcastId');
      }
    } catch (e) { /* non-critical — never block the actual request */ }
  }
  return next();
});

// ============ ANTI-SPAM THROTTLE ============
// Drops floods (>25 updates / 10s per user). Admins are exempt.
const rateBuckets = new Map();
bot.use(async (ctx, next) => {
  if (!ctx.from || fb.isAdmin(ctx.from.id)) return next();
  const now = Date.now();
  let b = rateBuckets.get(ctx.from.id);
  if (!b || now - b.t > 10000) { b = { t: now, n: 0 }; rateBuckets.set(ctx.from.id, b); }
  if (++b.n > 25) {
    if (ctx.callbackQuery) ctx.answerCbQuery('⏳ Thoda slow karo…').catch(() => {});
    return;
  }
  return next();
});
setInterval(() => { const cut = Date.now() - 60000; for (const [k, v] of rateBuckets) if (v.t < cut) rateBuckets.delete(k); }, 60000).unref();

// ============ BAN CHECK MIDDLEWARE ============

bot.use(async (ctx, next) => {
  if (!ctx.from) return next();
  const banned = await fb.isUserBanned(ctx.from.id);
  if (banned) {
    if (ctx.callbackQuery) await ctx.answerCbQuery().catch(() => {});
    return ctx.reply('🚫 Aapko is bot se block kar diya gaya hai. Support se contact karo agar galti lagti hai.');
  }
  return next();
});

// ============ MAINTENANCE MODE MIDDLEWARE ============

bot.use(async (ctx, next) => {
  if (!ctx.from) return next();

  const settings = await fb.getBotSettings();
  if (!settings.maintenanceMode) return next();

  // Admins bypass maintenance mode so they can still manage the bot
  if (fb.isAdmin(ctx.from.id)) return next();

  const msg = settings.maintenanceMessage || '🛠 Bot abhi maintenance mein hai. Thodi der baad try karo.';
  if (ctx.callbackQuery) {
    await ctx.answerCbQuery(msg, { show_alert: true });
  } else {
    await ctx.reply(msg);
  }
  return; // block everything else
});

// ============ MANDATORY CHANNEL JOIN MIDDLEWARE (supports multiple channels) ============
// Blocks all bot interaction until user joins every required channel.
// Skips the check itself for the "check_joined" button so users can retry.

bot.use(async (ctx, next) => {
  if (!ctx.from) return next();

  // Let the "I've Joined" button always through (it does the check itself)
  if (ctx.callbackQuery && ctx.callbackQuery.data === 'check_joined') return next();

  const settings = await fb.getBotSettings();
  const requiredChannels = (settings.channels || []).filter(c => c.required && c.username);
  if (requiredChannels.length === 0) return next();

  const notJoined = await getUnjoinedChannels(ctx.from.id, requiredChannels);
  if (notJoined.length > 0) {
    // If they arrived via a deep-link (e.g. a shared product URL), remember
    // it so we can send them there after they finish joining, instead of
    // dropping them on the generic main menu.
    if (ctx.startPayload) {
      await fb.setUserField(ctx.from.id, 'pendingDeepLink', ctx.startPayload);
    }
    await sendJoinPrompt(ctx, notJoined);
    return; // block everything else
  }

  return next();
});

async function checkChannelMembership(telegramId, channelUsername) {
  try {
    const handle = channelUsername.startsWith('@') ? channelUsername : `@${channelUsername}`;
    const member = await bot.telegram.getChatMember(handle, telegramId);
    return ['member', 'administrator', 'creator'].includes(member.status);
  } catch (err) {
    console.error(`Channel membership check failed for ${channelUsername}:`, err.message);
    // If the bot isn't an admin in the channel or channel is misconfigured,
    // fail open for that channel so a config mistake doesn't block everyone.
    return true;
  }
}

async function getUnjoinedChannels(telegramId, channels) {
  const results = [];
  for (const ch of channels) {
    const isMember = await checkChannelMembership(telegramId, ch.username);
    if (!isMember) results.push(ch);
  }
  return results;
}

async function sendJoinPrompt(ctx, channels) {
  const buttons = channels.map(ch => {
    const handle = ch.username.startsWith('@') ? ch.username.slice(1) : ch.username;
    return [Markup.button.url(`📢 Join ${ch.label || handle}`, `https://t.me/${handle}`)];
  });
  buttons.push([Markup.button.callback('✅ I\'ve Joined All', 'check_joined')]);

  await ctx.reply(
    `📢 *Ek chhota sa step baaki hai!*\n\nBot use karne se pehle neeche diye channel(s) join karo:`,
    { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) }
  );
}

bot.action('check_joined', async (ctx) => {
  const settings = await fb.getBotSettings();
  const requiredChannels = (settings.channels || []).filter(c => c.required && c.username);
  const notJoined = await getUnjoinedChannels(ctx.from.id, requiredChannels);

  if (notJoined.length === 0) {
    await ctx.answerCbQuery('✅ Verified!');
    const telegramId = ctx.from.id;
    await fb.createUserIfNotExists(telegramId, ctx.from, null);

    // If they arrived via a product deep-link before joining, send them
    // straight to that product now instead of the generic main menu.
    const pendingPayload = await fb.getUserField(telegramId, 'pendingDeepLink');
    if (pendingPayload) {
      await fb.clearUserField(telegramId, 'pendingDeepLink');
      if (pendingPayload.startsWith('PROD_')) {
        const productId = pendingPayload.slice('PROD_'.length);
        const product = await fb.getProduct(productId);
        if (product) {
          await fb.incrementProductViews(productId);
          pushNav(telegramId, `viewproduct_${productId}`);
          return sendProductCard(ctx, productId, product);
        }
      }
    }

    await sendMainMenu(ctx);
  } else {
    await ctx.answerCbQuery('❌ Abhi bhi kuch channels join nahi kiye.', { show_alert: true });
  }
});

// ============ START / REGISTER ============

bot.start(async (ctx) => {
  const telegramId = ctx.from.id;
  const payload = ctx.startPayload; // e.g. REF123456 (referral) or PROD_<productId> (direct product link)

  const isProductLink = payload && payload.startsWith('PROD_');
  const referralCode = isProductLink ? null : payload;

  await fb.createUserIfNotExists(telegramId, ctx.from, referralCode);

  if (isProductLink) {
    const productId = payload.slice('PROD_'.length);
    const product = await fb.getProduct(productId);
    if (product) {
      await fb.incrementProductViews(productId);
      pushNav(telegramId, `viewproduct_${productId}`);
      return sendProductCard(ctx, productId, product);
    }
    // Product not found (deleted/invalid link) — fall through to normal menu
  }

  await sendMainMenu(ctx);
});

async function sendMainMenu(ctx) {
  const settings = await fb.getBotSettings();
  const text = settings.welcomeMessage.replace('{name}', ctx.from.first_name);

  await smartReply(ctx, text, mainMenu(settings));
}

// Default labels for the built-in menu buttons — admin can override any of
// these from the Bot Settings > Menu Buttons panel without touching code.
const DEFAULT_MENU_LABELS = {
  profile: '👤 My Profile',
  wallet: '💰 Wallet',
  browse: '🛍 Browse Products',
  free: '🎁 Free Products',
  proplan: '👑 Pro Plan',
  purchases: '📦 My Purchases',
  orders: '📋 Order Status',
  referrals: '🔗 My Referrals',
  stats: '📊 My Stats',
  paymenthistory: '🧾 Payment History',
  support: '📞 Support',
  language: '🌐 Hindi / English',
  checkin: '🎯 Daily Check-in',
  leaderboard: '🏆 Leaderboard'
};

function mainMenu(settings) {
  const labels = { ...DEFAULT_MENU_LABELS, ...(settings?.menuLabels || {}) };

  // Layout: each inner array is one row of menu keys.
  const layout = [
    ['wallet', 'profile'],
    ['browse'],
    ['free'],
    ['proplan', 'purchases'],
    ['orders', 'referrals'],
    ['stats', 'paymenthistory'],
    ['checkin', 'leaderboard'],
    ['support', 'language']
  ];

  // Hidden buttons (admin: Menu Buttons > Show/Hide) are skipped; a row that
  // loses one button collapses to the remaining one automatically.
  const rows = layout
    .map(keys => keys
      .filter(k => !bs.isHidden(settings, k))
      .map(k => bs.styledCallback(labels[k], `menu_${k}`, bs.menuColor(settings, k))))
    .filter(r => r.length > 0);

  // Admin-configured custom link buttons on the main menu (e.g. "Join Community").
  // Supports multiple — each one is its own row, with its own colour.
  const customButtons = Array.isArray(settings?.menuCustomButtons) ? settings.menuCustomButtons : [];
  customButtons.forEach(btn => {
    if (btn.text && btn.url) rows.push([bs.styledUrl(`🔗 ${btn.text}`, btn.url, btn.style || 'primary')]);
  });

  // Never leave the user with an empty menu.
  if (rows.length === 0) rows.push([bs.styledCallback(labels.support, 'menu_support', 'success')]);

  return Markup.inlineKeyboard(rows);
}

bot.action('menu_home', async (ctx) => {
  await ctx.answerCbQuery();
  navStack[ctx.from.id] = ['menu_home']; // reset stack — Home always starts fresh
  await sendMainMenu(ctx);
});

// ============ MY PROFILE ============

bot.action('menu_profile', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_profile');
  await renderProfile(ctx);
});

async function renderProfile(ctx) {
  const telegramId = ctx.from.id;
  let user = await fb.getUser(telegramId);

  // Safety net: user record should always exist after /start, but if it's
  // somehow missing, create it now instead of crashing the whole handler
  // silently (which was the root cause of "everything disappears").
  if (!user) {
    user = await fb.createUserIfNotExists(telegramId, ctx.from, null);
  }

  const balance = await fb.getWalletBalance(telegramId);
  const isVip = await fb.isUserVip(telegramId);
  const vipDays = isVip ? await fb.getVipDaysLeft(telegramId) : 0;
  const orders = await fb.getUserOrders(telegramId);
  const orderCount = Object.keys(orders).length;

  const vipLine = isVip ? `👑 VIP Active — ${vipDays} days left` : '👤 Free User';

  const msg = `👤 *My Profile*\n\n✨ Name: ${mdEscape(user.name)}\n🔖 Username: ${user.username ? '@' + mdEscape(user.username) : '-'}\n🆔 Telegram ID: \`${telegramId}\`\n\n${vipLine}\n💰 Wallet: ₹${balance}\n📦 Total Orders: ${orderCount}\n🔗 Referral Code: \`${user.referralCode}\``;

  await smartReply(ctx, msg, backButton(ctx));
}

function backButton(ctx) {
  const telegramId = ctx?.from?.id;
  const stack = telegramId ? navStack[telegramId] : null;
  const canGoBack = stack && stack.length > 1;

  const row = canGoBack
    ? [Markup.button.callback('⬅️ Back', 'nav_back'), Markup.button.callback('🏠 Home', 'menu_home')]
    : [Markup.button.callback('🏠 Home', 'menu_home')];

  return Markup.inlineKeyboard([row]);
}

// Generic handler: pops the nav stack and shows the previous screen directly.
// We call the underlying screen-render functions directly (not re-dispatching
// fake Telegram events, which is fragile). Supports both simple no-argument
// screens and dynamic ones (category name, product id) parsed from the target.
bot.action('nav_back', async (ctx) => {
  await ctx.answerCbQuery();
  const telegramId = ctx.from.id;
  const target = popNav(telegramId);

  // Dynamic targets: cat_<CategoryName>, viewproduct_<id>
  if (target.startsWith('cat_')) {
    const category = target.slice(4);
    return renderCategoryProducts(ctx, category);
  }
  if (target.startsWith('viewproduct_')) {
    const productId = target.slice('viewproduct_'.length);
    const product = await fb.getProduct(productId);
    if (product) return sendProductCard(ctx, productId, product);
    return sendMainMenu(ctx);
  }

  const screenRenderers = {
    menu_home: () => sendMainMenu(ctx),
    menu_profile: () => renderProfile(ctx),
    menu_wallet: () => renderWallet(ctx),
    menu_browse: () => showCategories(ctx),
    menu_free: () => renderFreeProducts(ctx),
    menu_proplan: () => renderProPlan(ctx),
    menu_purchases: () => renderPurchases(ctx),
    menu_orders: () => renderOrderStatus(ctx),
    menu_referrals: () => sendReferralInfo(ctx),
    menu_stats: () => renderStats(ctx),
    menu_paymenthistory: () => renderPaymentHistory(ctx),
    menu_support: () => renderSupport(ctx),
    menu_language: () => renderLanguage(ctx),
    menu_checkin: () => renderCheckIn(ctx),
    menu_leaderboard: () => renderLeaderboard(ctx)
  };

  const renderer = screenRenderers[target];
  if (renderer) return renderer();
  return sendMainMenu(ctx);
});

// ============ PRO PLAN ============

bot.action('menu_proplan', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_proplan');
  await renderProPlan(ctx);
});

async function renderProPlan(ctx) {
  const telegramId = ctx.from.id;
  const settings = await fb.getProPlanSettings();
  const isVip = await fb.isUserVip(telegramId);

  if (isVip) {
    const daysLeft = await fb.getVipDaysLeft(telegramId);
    return smartReply(
      ctx,
      `👑 *You're already VIP!*\n\n✨ ${daysLeft} days remaining.\n\nWant to extend? Buy again to add more days.`,
      navButtons([[Markup.button.callback(`💳 Extend — ₹${settings.price}`, 'buyproplan')]], telegramId)
    );
  }

  const msg = `👑 *Upgrade to VIP*\n\n💰 ₹${settings.price} · ${settings.description}\n\n✨ *What you unlock:*\n✅ ${settings.durationDays} din unlimited downloads\n✅ Koi bhi paid product FREE\n✅ Wallet balance ki zarurat nahi\n✅ Naye products bhi free\n\n🛡 Secure UPI payment · Instant activation`;

  await smartReply(ctx, msg, navButtons([[Markup.button.callback(`💳 Upgrade Now — ₹${settings.price}`, 'buyproplan')]], telegramId));
}

bot.action('buyproplan', async (ctx) => {
  const telegramId = ctx.from.id;
  const settings = await fb.getProPlanSettings();

  await ctx.answerCbQuery();
  const paymentSettings = await fb.getPaymentSettings();
  const tcText = paymentSettings.termsAndConditions || 'Payment is final once activated.';

  await smartReply(
    ctx,
    `${tcText}\n\n👑 *Pro Plan* — ₹${settings.price}\n\nContinue to payment?`,
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ I Agree, Continue', 'agreepayproplan')],
      [Markup.button.callback('❌ Cancel', 'menu_home')]
    ])
  );
});

bot.action('agreepayproplan', async (ctx) => {
  const telegramId = ctx.from.id;
  const settings = await fb.getProPlanSettings();

  await ctx.answerCbQuery('Generating QR...');
  await deleteTriggerMessage(ctx);

  const paymentSettings = await fb.getPaymentSettings();
  const qr = await fampay.generateQr(paymentSettings.upiId, settings.price, paymentSettings);

  const order = await fb.createOrder({
    userId: String(telegramId),
    productId: 'PRO_PLAN',
    productName: `Pro Plan (${settings.durationDays} days)`,
    amount: settings.price,
    paymentMethod: 'fampay',
    isProPlan: true,
    proPlanDuration: settings.durationDays
  });

  if (!qr.success) {
    await fb.updateOrderStatus(order.id, 'failed');
    console.error('FamPay Pro Plan QR failed for order', order.id, ':', qr.error);
    return ctx.reply(
      `❌ *QR generate nahi ho paya*\n\nWajah: ${mdEscape(typeof qr.error === 'string' ? qr.error : JSON.stringify(qr.error))}\n\nThodi der baad try karo.`,
      { parse_mode: 'Markdown', ...navButtons([[Markup.button.callback('🔄 Try Again', 'buyproplan')]], telegramId) }
    );
  }

  await fb.updateOrderStatus(order.id, 'pending', { famOrderId: qr.orderId });
  userState[telegramId] = { step: 'awaiting_utr', data: { orderId: order.id } };

  const sentMsg = await ctx.replyWithPhoto(qr.qrImageUrl, {
    caption: `📱 *Scan & Pay* — ₹${settings.price}\n\nPro Plan (${settings.durationDays} days)\n\n1️⃣ QR scan karke payment karo\n2️⃣ Payment ke baad UTR number is chat mein bhejo\n3️⃣ Verification ~30 sec mein ho jayega\n\n⏱ QR 10 minute mein expire ho jayega.`,
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('❌ Cancel Order', `cancelorder_${order.id}`)]
    ])
  });

  await trackPaymentMessage(order.id, sentMsg);
  await sendUpiLinkIfAny(telegramId, qr.upiLink);
  scheduleAutoCancel(order.id);
});

// ============ FREE PRODUCTS ============

bot.action('menu_free', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_free');
  await renderFreeProducts(ctx);
});

async function renderFreeProducts(ctx) {
  const telegramId = ctx.from.id;
  const all = await fb.getAllProducts(true);
  const freeEntries = Object.entries(all).filter(([id, p]) => p.price === 0);

  if (freeEntries.length === 0) {
    return smartReply(ctx, '🎁 Abhi koi free product available nahi hai. Jaldi aayega! 🙏', backButton(ctx));
  }

  const buttons = freeEntries.map(([id, p]) => [Markup.button.callback(`🎁 ${p.name} | FREE`, `viewproduct_${id}`)]);

  await smartReply(ctx, '✨ 「 *Free Products* 」\n\n✨ Tap any product to view full details.', navButtons(buttons, telegramId));
}

// ============ ORDER STATUS ============

bot.action('menu_orders', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_orders');
  await renderOrderStatus(ctx);
});

async function renderOrderStatus(ctx) {
  const telegramId = ctx.from.id;
  const orders = await fb.getUserOrders(telegramId);
  const list = Object.values(orders).sort((a, b) => b.createdAt - a.createdAt);

  if (list.length === 0) {
    return smartReply(ctx, '📋 Abhi tak koi order nahi hai.', backButton(ctx));
  }

  let msg = '✨ 「 *Order Status* 」\n\n';
  list.slice(0, 10).forEach(o => {
    const inQueue = o.status === 'paid' && o.isQamify && ['queued', 'uncertain', 'processing', 'fulfilled', 'pending'].includes(o.fulfilment || 'pending');
    const statusEmoji = o.status === 'delivered' ? '✅' : o.status === 'pending' || o.status === 'pending_review' || inQueue ? '⏳' : o.status === 'failed' ? '❌' : o.status === 'refunded' ? '↩️' : '🔄';
    const statusLabel = o.status === 'pending_review' ? 'Under Review' : inQueue ? 'Processing' : o.status.charAt(0).toUpperCase() + o.status.slice(1);
    const dateStr = o.createdAt ? new Date(o.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }) : '';
    msg += `${statusEmoji} *${mdEscape(o.productName)}*\n💰 ₹${o.amount} · _${statusLabel}_ · ${dateStr}\n\n`;
  });

  const buttons = [];

  await smartReply(ctx, msg.trim(), navButtons(buttons, telegramId));
}

// ============ MY STATS ============

bot.action('menu_stats', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_stats');
  await renderStats(ctx);
});

async function renderStats(ctx) {
  const telegramId = ctx.from.id;
  const orders = await fb.getUserOrders(telegramId);
  const list = Object.values(orders);
  const paidOrders = list.filter(o => o.status === 'paid' || o.status === 'delivered');
  const totalSpent = paidOrders.reduce((sum, o) => sum + (o.amount || 0), 0);
  const user = await fb.getUser(telegramId);

  const msg = `📊 *My Stats*\n\n🛒 Total Orders: *${list.length}*\n✅ Completed: *${paidOrders.length}*\n💰 Total Spent: *₹${totalSpent}*\n📅 Member since: ${new Date(user.joinedAt).toLocaleDateString()}`;

  await smartReply(ctx, msg, backButton(ctx));
}

// ============ PAYMENT HISTORY ============

bot.action('menu_paymenthistory', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_paymenthistory');
  await renderPaymentHistory(ctx);
});

async function renderPaymentHistory(ctx) {
  const telegramId = ctx.from.id;
  const orders = await fb.getUserOrders(telegramId);
  const paidOrders = Object.values(orders).filter(o => o.status === 'paid' || o.status === 'delivered');

  const txns = await fb.getUserWalletTransactions(telegramId);

  // Merge orders (FamPay/Binance + wallet purchases) and raw wallet transactions
  // (top-ups, referral bonuses, refunds) into one timeline.
  const entries = [
    ...paidOrders.map(o => ({
      createdAt: o.createdAt,
      label: `${o.paymentMethod === 'wallet' ? '💰' : '💳'} ${mdEscape(o.productName)} — ₹${o.amount}`
    })),
    ...txns.map(t => ({
      createdAt: t.createdAt,
      label: `${t.type === 'credit' ? '➕' : '➖'} ₹${t.amount} — ${t.reason}`
    }))
  ];

  if (entries.length === 0) {
    return smartReply(ctx, '🧾 Koi payment history nahi mili.', backButton(ctx));
  }

  let msg = '✨ 「 *Payment History* 」\n\n';
  entries.sort((a, b) => b.createdAt - a.createdAt).slice(0, 15).forEach(e => {
    const dateStr = new Date(e.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    msg += `${e.label}\n_${dateStr}_\n\n`;
  });

  await smartReply(ctx, msg.trim(), backButton(ctx));
}

// ============ LANGUAGE ============

bot.action('menu_language', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_language');
  await renderLanguage(ctx);
});

async function renderLanguage(ctx) {
  await smartReply(ctx, '🌐 Abhi sirf Hinglish support hai.\n\n✨ Full Hindi/English switch jaldi aa raha hai! 🙏', backButton(ctx));
}

// ============ DAILY CHECK-IN ============

bot.action('menu_checkin', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_checkin');
  await renderCheckIn(ctx);
});

async function renderCheckIn(ctx) {
  const telegramId = ctx.from.id;
  const settings = await fb.getCheckInSettings();

  if (!settings.active) {
    return smartReply(ctx, '🎯 Daily Check-in abhi available nahi hai.', backButton(ctx));
  }

  const result = await fb.performCheckIn(telegramId);

  if (!result.success && result.reason === 'already_checked_in') {
    return smartReply(
      ctx,
      `✅ *Aaj already check-in kar chuke ho!*\n\n🔥 Current Streak: *${result.streak} din*\n\nKal wapas aana aur streak jaari rakhna! ⏰`,
      backButton(ctx)
    );
  }

  if (!result.success) {
    return smartReply(ctx, '⚠️ Check-in abhi available nahi hai.', backButton(ctx));
  }

  await smartReply(
    ctx,
    `🎯 *Daily Check-in Successful!*\n\n💰 +₹${result.bonus} wallet mein add ho gaya\n🔥 Streak: *${result.streak} din*\n\n✨ Roz check-in karke streak badhao aur zyada bonus paao!`,
    backButton(ctx)
  );
}

// ============ LEADERBOARD ============

bot.action('menu_leaderboard', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_leaderboard');
  await renderLeaderboard(ctx);
});

async function renderLeaderboard(ctx) {
  const [topBuyers, topReferrers] = await Promise.all([
    fb.getTopBuyers(5),
    fb.getTopReferrers(5)
  ]);

  let msg = '🏆 「 *Leaderboard* 」\n\n';

  msg += '💰 *Top Buyers*\n';
  if (topBuyers.length === 0) {
    msg += '_Koi purchase abhi nahi hui_\n';
  } else {
    const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
    topBuyers.forEach((b, i) => {
      msg += `${medals[i]} ${mdEscape(b.name)} — ₹${b.totalSpent}\n`;
    });
  }

  msg += '\n🔗 *Top Referrers*\n';
  if (topReferrers.length === 0) {
    msg += '_Koi referral abhi nahi hua_\n';
  } else {
    const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣'];
    topReferrers.forEach((r, i) => {
      msg += `${medals[i]} ${mdEscape(r.name)} — ${r.referralCount} referrals\n`;
    });
  }

  await smartReply(ctx, msg.trim(), backButton(ctx));
}

// ============ SUPPORT (menu action version) ============

bot.action('menu_support', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_support');
  await renderSupport(ctx);
});

async function renderSupport(ctx) {
  const telegramId = ctx.from.id;
  const settings = await fb.getBotSettings();

  let msg = `📞 *Customer Support*\n\n💫 Koi bhi issue ho, humse contact karo:\n\n`;
  const buttons = [];

  if (settings.supportTelegram) {
    const handle = settings.supportTelegram.replace('@', '');
    msg += `💬 Telegram: @${mdEscape(handle)}\n`;
    buttons.push([Markup.button.url('💬 Message on Telegram', `https://t.me/${handle}`)]);
  }
  if (settings.supportWhatsapp) {
    const number = settings.supportWhatsapp.replace(/[^0-9]/g, '');
    msg += `📱 WhatsApp: +${number}\n`;
    buttons.push([Markup.button.url('📱 Message on WhatsApp', `https://wa.me/${number}`)]);
  }
  if (!settings.supportTelegram && !settings.supportWhatsapp) {
    msg += 'Support details jaldi update honge.';
  }

  await smartReply(ctx, msg, navButtons(buttons, telegramId));
}

// ============ MY PURCHASES ============

bot.action('menu_purchases', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_purchases');
  await renderPurchases(ctx);
});

async function renderPurchases(ctx) {
  const telegramId = ctx.from.id;
  const orders = await fb.getUserOrders(telegramId);
  const delivered = Object.values(orders).filter(o => o.status === 'delivered').sort((a, b) => b.createdAt - a.createdAt);

  if (delivered.length === 0) {
    return smartReply(ctx, '📦 Abhi tak koi purchase nahi hai.', backButton(ctx));
  }

  const buttons = delivered.slice(0, 15)
    .filter(o => o.productId && o.productId !== 'PRO_PLAN' && o.productId !== 'WALLET_TOPUP')
    .map(o => [Markup.button.callback(`✅ ${o.productName} — ₹${o.amount}`, `redeliver_${o.id}`)]);

  await smartReply(ctx, '✨ 「 *My Purchases* 」\n\n✨ Tap to view or re-download:', navButtons(buttons, telegramId));
}

// ============ MY REFERRALS (menu action version) ============

bot.action('menu_referrals', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_referrals');
  await sendReferralInfo(ctx);
});

async function sendReferralInfo(ctx) {
  const telegramId = ctx.from.id;
  const user = await fb.getUser(telegramId);
  const settings = await fb.getReferralSettings();
  const botInfo = await bot.telegram.getMe();

  const allUsers = await fb.getAllUsers();
  const referredUsers = Object.values(allUsers).filter(u => u.referredBy === String(telegramId));
  const convertedCount = referredUsers.filter(u => u.hasFirstPurchase).length;

  const link = `https://t.me/${botInfo.username}?start=${user.referralCode}`;
  const bonusText = settings.bonusType === 'percent'
    ? `${settings.bonusAmount}% of their first purchase`
    : `₹${settings.bonusAmount}`;

  await smartReply(
    ctx,
    `✨ 「 *My Referrals* 」\n\n💎 Apne friends ko invite karo aur unki pehli purchase pe *${bonusText}* wallet bonus paao!\n\n👥 Total Referred: *${referredUsers.length}*\n✅ Converted (purchased): *${convertedCount}*\n\n🔗 Your referral link:\n\`${link}\``,
    backButton(ctx)
  );
}

// ============ BROWSE PRODUCTS ============

bot.action('menu_browse', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_browse');
  await showCategories(ctx);
});

// ============ PRODUCTS / CATALOG (flat button list style) ============

async function showCategories(ctx) {
  const telegramId = ctx.from.id;
  const categories = await fb.getAllCategories();
  if (categories.length === 0) {
    return smartReply(ctx, '🛍 Abhi koi product available nahi hai. Jaldi aayega! 🙏', backButton(ctx));
  }

  // Category names are free text (can be long / multi-byte) but Telegram caps
  // callback_data at 64 BYTES — use a short stable hash instead of the name.
  const buttons = categories.map(cat => [Markup.button.callback(`📁 ${sanitizeForTelegram(cat, 40)}`, `cat_${catId(cat)}`)]);
  buttons.push([Markup.button.callback('🏠 Home', 'menu_home')]);
  await smartReply(ctx, '🛍 *Browse Products*\n\nCategory choose karo:', Markup.inlineKeyboard(buttons));
}

function catId(cat) { return crypto.createHash('md5').update(String(cat)).digest('hex').slice(0, 10); }

bot.action(/^cat_(.+)$/, async (ctx) => {
  const allCats = await fb.getAllCategories();
  const category = allCats.find(c => catId(c) === ctx.match[1]) || ctx.match[1]; // legacy buttons still work
  const telegramId = ctx.from.id;
  const products = await fb.getProductsByCategory(category);
  const entries = Object.entries(products);

  if (entries.length === 0) {
    return ctx.answerCbQuery('Is category mein abhi product nahi hai.');
  }

  await ctx.answerCbQuery();
  pushNav(telegramId, `cat_${category}`);
  await renderCategoryProducts(ctx, category);
});

async function renderCategoryProducts(ctx, category) {
  const telegramId = ctx.from.id;
  const products = await fb.getProductsByCategory(category);
  const entries = Object.entries(products);

  if (entries.length === 0) {
    return smartReply(ctx, `📁 *${mdEscape(category)}*\n\nIs category mein abhi koi product nahi hai.`, backButton(ctx));
  }

  const buttons = entries.map(([id, p]) => [Markup.button.callback(productButtonLabel(p), `viewproduct_${id}`)]);

  await smartReply(
    ctx,
    `📁 *${mdEscape(category)}*\n\n✨ Explore our full catalogue below — tap any product to view full details.`,
    navButtons(buttons, telegramId)
  );
}

function productButtonLabel(p) {
  const name = sanitizeForTelegram(p.name, 40);
  if (p.source === 'qamify') {
    const sold = !(p.stock > 0);
    return `${sold ? '❌' : (p.emoji || '🛒')} ${name} | ${sold ? 'Sold out' : '₹' + p.price}`;
  }
  return `🛒 ${name} | ${p.price === 0 ? 'FREE' : '₹' + p.price}`;
}

// ---- Product detail view (tap from any flat list) ----
bot.action(/^viewproduct_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  const product = await fb.getProduct(productId);

  if (!product || (!product.active && !fb.isAdmin(ctx.from.id))) {
    await ctx.answerCbQuery('⚠️ Yeh product ab available nahi hai.', { show_alert: true });
    return smartReply(ctx, '⚠️ Yeh product remove kar diya gaya hai. Aapka purchase record safe hai — Order Status mein check kar sakte ho.', backButton(ctx));
  }

  await ctx.answerCbQuery();
  await fb.incrementProductViews(productId);
  pushNav(ctx.from.id, `viewproduct_${productId}`);
  await sendProductCard(ctx, productId, product);
});

// ---- Reusable product card sender (used by category browse + search) ----
// Deletes the message that triggered a callback (if any) before sending
// new content that can't use editMessageText (photos, media groups). This
// prevents old button-bearing messages from being left behind in the chat.
async function deleteTriggerMessage(ctx) {
  if (ctx.callbackQuery) {
    try { await ctx.deleteMessage(); } catch (e) { /* already gone or too old — fine */ }
  }
}

async function sendProductCard(ctx, id, p) {
  const telegramId = ctx.from.id;
  await deleteTriggerMessage(ctx);

  const { avg, count } = await fb.getProductAvgRating(id);
  const ratingLine = count > 0 ? `\n⭐ ${avg}/5 _(${count} reviews)_` : '';
  const stockLine = (p.stock !== undefined && p.stock !== -1) ? `\n📦 Stock: ${p.stock}` : '';
  const viewsLine = p.views ? `\n👁 ${p.views} views` : '';
  const priceLabel = p.price === 0 ? '*FREE* 🎁' : `*₹${p.price}*`;

  const safeName = sanitizeForTelegram(p.name, 200);
  // Description gets a generous cap up front (most descriptions are far
  // shorter than this) — the truncateMarkdownSafe() calls below are the
  // real guarantee against exceeding Telegram's caption limits, since they
  // operate on the final assembled+escaped string and can never leave
  // unbalanced "*" bold markers behind.
  const safeDescription = sanitizeForTelegram(p.description, 3000);
  const escapedDescription = mdEscape(safeDescription);

  const isFree = p.price === 0;
  const isQm = p.source === 'qamify';
  const soldOut = isQm && !(p.stock > 0);
  const rows = [
    [soldOut
      ? Markup.button.callback('❌ Out of Stock', 'noop')
      : isFree
        ? Markup.button.callback('📥 Download Free', `freedownload_${id}`)
        : Markup.button.callback('🛒 Buy Now', `buy_${id}`)],
    [Markup.button.callback('⭐ Reviews', `reviews_${id}`)]
  ];
  // Admin-configured custom button (e.g. "Join Community", "Watch Tutorial")
  if (p.customButtonText && p.customButtonUrl) {
    rows.push([Markup.button.url(`🔗 ${sanitizeForTelegram(p.customButtonText, 60)}`, p.customButtonUrl)]);
  }

  const buttons = navButtons(rows, telegramId);
  let qmLines = '';
  if (isQm) {
    const rs = await fb.getResellerSettings();
    const min = p.qamify?.minQty || 1;
    const max = reseller.effectiveMax(p, rs);
    qmLines = `\n⚡ Instant delivery · 🔢 Qty ${min}${max > min && max < 999 ? `–${max}` : '+'}`;
    if (p.qamify?.cooldownSec > 0) qmLines += `\n⏳ Order gap: ${Math.ceil(p.qamify.cooldownSec / 60)} min`;
    if (p.instructions) qmLines += `\n\nℹ️ _${mdEscape(sanitizeForTelegram(p.instructions, 220))}_`;
  }
  const titleEmoji = isQm && p.emoji ? `${p.emoji} ` : '✨ ';
  const fullCaption = truncateMarkdownSafe(
    `${titleEmoji}*${mdEscape(safeName)}*\n\n${escapedDescription}\n\n💰 Price: ${priceLabel}${isQm ? ' / unit' : ''}${ratingLine}${stockLine}${viewsLine}${qmLines}`,
    4096
  );

  // Support multiple images: an imageFileIds array (from the admin panel's
  // multi-photo upload), an imageUrls array, a single imageFileId, or a
  // single imageUrl — replyWithPhoto accepts URLs and file_ids interchangeably.
  const images = Array.isArray(p.imageFileIds) && p.imageFileIds.length > 0
    ? p.imageFileIds
    : (Array.isArray(p.imageUrls) && p.imageUrls.length > 0
      ? p.imageUrls
      : (p.imageFileId ? [p.imageFileId] : (p.imageUrl ? [p.imageUrl] : [])));

  if (images.length > 1) {
    // Telegram hard-limits sendMediaGroup captions to 1024 characters (vs
    // 4096 for a normal message/photo caption), and a media group can't
    // carry any inline buttons at all. So: keep the media-group caption
    // short (name + price only — always well under 1024), then send the
    // full caption + buttons as a separate follow-up message, which is
    // also where the Buy/Download button lives.
    const shortCaption = `✨ *${mdEscape(safeName)}*\n\n💰 Price: ${priceLabel}`;

    const mediaGroup = images.slice(0, 10).map((url, i) => ({
      type: 'photo',
      media: url,
      caption: i === 0 ? shortCaption : undefined,
      parse_mode: i === 0 ? 'Markdown' : undefined
    }));
    await ctx.replyWithMediaGroup(mediaGroup);
    await ctx.reply(fullCaption, { parse_mode: 'Markdown', ...buttons });
  } else if (images.length === 1) {
    // sendPhoto's caption limit is 1024, not 4096 — re-truncate for this
    // specific path so a long description can't break just this branch.
    const photoCaption = truncateMarkdownSafe(fullCaption, 1024);
    await ctx.replyWithPhoto(images[0], { caption: photoCaption, parse_mode: 'Markdown', ...buttons });
  } else {
    await ctx.reply(fullCaption, { parse_mode: 'Markdown', ...buttons });
  }
}

// ============ SEARCH ============

bot.command('search', async (ctx) => {
  userState[ctx.from.id] = { step: 'awaiting_search_query' };
  await ctx.reply('🔍 Product ka naam type karo dhundhne ke liye:');
});

// ============ REVIEWS ============

bot.action(/^reviews_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  await ctx.answerCbQuery();

  const reviews = await fb.getProductReviews(productId);
  const list = Object.values(reviews).sort((a, b) => b.createdAt - a.createdAt);

  if (list.length === 0) {
    return ctx.reply(
      'Abhi koi review nahi hai. Purchase karne ke baad tum pehla review de sakte ho! 🙌',
      Markup.inlineKeyboard([[Markup.button.callback('✍️ Write a Review', `writereview_${productId}`)]])
    );
  }

  let msg = `⭐ *Reviews*\n\n`;
  list.slice(0, 8).forEach(r => {
    const stars = '⭐'.repeat(r.rating);
    msg += `${stars} — ${r.userName}\n${r.comment ? r.comment + '\n' : ''}\n`;
  });

  await ctx.reply(msg, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([[Markup.button.callback('✍️ Write a Review', `writereview_${productId}`)]])
  });
});

bot.action(/^writereview_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  await ctx.answerCbQuery();
  await ctx.reply(
    'Rating do (1-5 stars):',
    Markup.inlineKeyboard([
      [1, 2, 3, 4, 5].map(n => Markup.button.callback('⭐'.repeat(n), `rate_${productId}_${n}`))
    ])
  );
});

bot.action(/^rate_(.+)_(\d)$/, async (ctx) => {
  const productId = ctx.match[1];
  const rating = parseInt(ctx.match[2]);
  await ctx.answerCbQuery();

  userState[ctx.from.id] = { step: 'awaiting_review_comment', data: { productId, rating } };
  await ctx.reply('Ek chhota comment likho (ya "skip" bhejo):');
});

// ============ BUY FLOW ============

bot.action(/^buy_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  const product = await fb.getProduct(productId);
  const telegramId = ctx.from.id;

  if (!product || !product.active) {
    return ctx.answerCbQuery('Yeh product available nahi hai.');
  }

  // ---- Reseller (Qamify) product: repeat purchases allowed, quantity picker, live stock ----
  if (product.source === 'qamify') {
    const fresh = (await reseller.refreshProduct(productId)) || product;
    const avail = await reseller.checkAvailability(fresh, fresh.qamify?.minQty || 1);
    if (!avail.ok) return ctx.answerCbQuery(avail.message, { show_alert: true });
    await ctx.answerCbQuery();
    return showQtyPicker(ctx, productId, fresh);
  }

  // Already bought? Don't let them pay again — offer re-delivery instead.
  const boughtOrder = await fb.getBoughtOrder(telegramId, productId);
  if (boughtOrder) {
    await ctx.answerCbQuery();
    return ctx.reply(
      `✅ Yeh product aap pehle hi khareed chuke ho!\n\n*${mdEscape(product.name)}*\n\nDobara download karna hai?`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📥 Re-download', `redeliver_${boughtOrder.id}`)],
          [Markup.button.callback('🏠 Home', 'menu_home')]
        ])
      }
    );
  }

  if (product.stock !== undefined && product.stock !== -1 && product.stock <= 0) {
    return ctx.answerCbQuery('Yeh product abhi out of stock hai.');
  }

  await ctx.answerCbQuery();

  // VIP users get every paid product free, instantly
  const isVip = await fb.isUserVip(telegramId);
  if (isVip && product.price > 0) {
    const order = await fb.createOrder({
      userId: String(telegramId),
      productId,
      productName: product.name,
      amount: 0,
      originalAmount: product.price,
      paymentMethod: 'vip_free',
      productSnapshot: {
        deliveryType: product.deliveryType,
        fileId: product.fileId || null,
        deliveryLink: product.deliveryLink || null
      }
    });
    await fb.updateOrderStatus(order.id, 'paid');
    await fb.decrementStock(productId);
    await checkAndAlertLowStock(productId);
    return deliverProduct(ctx, product, order.id);
  }

  await showOrderSummary(ctx, productId, product, null);
});

// ---- Free products: instant delivery, no payment flow at all ----
bot.action(/^freedownload_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  const product = await fb.getProduct(productId);
  const telegramId = ctx.from.id;

  if (!product || !product.active) {
    return ctx.answerCbQuery('Yeh product available nahi hai.');
  }
  if (product.price !== 0) {
    // Safety net in case an old button/cached message still points here
    // for a product whose price was changed after the card was sent.
    return ctx.answerCbQuery('Yeh product ab free nahi hai.', { show_alert: true });
  }

  // Already have it? Offer re-download instead of creating a duplicate order.
  const boughtOrder = await fb.getBoughtOrder(telegramId, productId);
  if (boughtOrder) {
    await ctx.answerCbQuery();
    return ctx.reply(
      `✅ Yeh product aap pehle hi le chuke ho!\n\n*${mdEscape(product.name)}*\n\nDobara download karna hai?`,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('📥 Re-download', `redeliver_${boughtOrder.id}`)],
          [Markup.button.callback('🏠 Home', 'menu_home')]
        ])
      }
    );
  }

  if (product.stock !== undefined && product.stock !== -1 && product.stock <= 0) {
    return ctx.answerCbQuery('Yeh product abhi out of stock hai.');
  }

  await ctx.answerCbQuery();

  const order = await fb.createOrder({
    userId: String(telegramId),
    productId,
    productName: product.name,
    amount: 0,
    originalAmount: 0,
    paymentMethod: 'free',
    productSnapshot: {
      deliveryType: product.deliveryType,
      fileId: product.fileId || null,
      deliveryLink: product.deliveryLink || null
    }
  });
  await fb.updateOrderStatus(order.id, 'paid');
  await fb.decrementStock(productId);
  await checkAndAlertLowStock(productId);
  await deliverProduct(ctx, product, order.id);
});

// Builds the payment-method button rows based on which gateways the admin
// currently has enabled — never shows a button for a disabled gateway.
function paymentMethodButtons(paymentSettings, productId, couponSuffix) {
  const rows = [];
  if (paymentSettings.fampayEnabled !== false) {
    rows.push([Markup.button.callback('💳 Pay via FamPay', `payfampay_${productId}${couponSuffix}`)]);
  }
  if (paymentSettings.binanceEnabled) {
    rows.push([Markup.button.callback('🟡 Pay via Binance', `paybinance_${productId}${couponSuffix}`)]);
  }
  return rows;
}

// ============ QUOTES (single source of truth for "what does this cost right now") ============
// Every payment path (wallet / FamPay / Binance) goes through these helpers so
// quantity, coupon and reseller pricing can never drift between screens.

const payLocks = new Set(); // per-user in-flight guard against double-tap purchases

async function getQuote(telegramId, productId, couponCode) {
  const product = await fb.getProduct(productId);
  if (!product) return null;
  const isQamify = product.source === 'qamify';
  const qty = isQamify ? await reseller.getCartQty(telegramId, productId, product) : 1;
  const subtotal = product.price * qty;

  let discount = 0;
  let couponUsed = null;
  if (couponCode) {
    const check = await fb.validateCoupon(couponCode, subtotal);
    if (check.valid) { discount = check.discount; couponUsed = couponCode; }
  }
  return { product, productId, isQamify, qty, subtotal, discount, couponUsed, finalPrice: Math.max(0, subtotal - discount) };
}

// getQuote + all "may this user buy this right now?" checks. Answers the
// callback itself and returns null when the purchase must stop.
async function prepareQuote(ctx, telegramId, productId, couponCode) {
  const existing = await fb.getProduct(productId);
  if (!existing) { await ctx.answerCbQuery('Product not found.'); return null; }
  if (!existing.active) { await ctx.answerCbQuery('Yeh product available nahi hai.', { show_alert: true }); return null; }

  if (existing.source === 'qamify') {
    await reseller.refreshProduct(productId, 8000); // live price/stock right before paying
  } else {
    if (await fb.hasUserBoughtProduct(telegramId, productId)) {
      await ctx.answerCbQuery();
      await smartReply(ctx, '✅ Yeh product aap pehle hi khareed chuke ho.', backButton(ctx));
      return null;
    }
    if (existing.stock !== undefined && existing.stock !== -1 && existing.stock <= 0) {
      await ctx.answerCbQuery('Yeh product abhi out of stock hai.', { show_alert: true });
      return null;
    }
  }

  const q = await getQuote(telegramId, productId, couponCode);
  if (!q) { await ctx.answerCbQuery('Product not found.'); return null; }
  if (!q.product.active) { await ctx.answerCbQuery('Yeh product available nahi hai.', { show_alert: true }); return null; }

  if (q.isQamify) {
    const avail = await reseller.checkAvailability(q.product, q.qty);
    if (!avail.ok) { await ctx.answerCbQuery(avail.message, { show_alert: true }); return null; }
  }
  return q;
}

async function createOrderFromQuote(telegramId, q, paymentMethod, extra = {}) {
  const p = q.product;
  const qmFields = q.isQamify ? reseller.buildOrderFields(q.productId, p, q.qty) : {};
  return fb.createOrder({
    userId: String(telegramId),
    productId: q.productId,
    productName: qmFields.displayName || p.name,
    amount: q.finalPrice,
    originalAmount: q.subtotal,
    couponUsed: q.couponUsed || null,
    paymentMethod,
    productSnapshot: {
      deliveryType: p.deliveryType,
      fileId: p.fileId || null,
      deliveryLink: p.deliveryLink || null
    },
    ...qmFields,
    ...extra
  });
}

const qtyTag = (q) => (q.qty > 1 ? ` ×${q.qty}` : '');
const couponSuffixOf = (couponCode) => (couponCode ? '_' + couponCode : '');

// ============ QUANTITY PICKER (reseller products) ============

async function showQtyPicker(ctx, productId, product) {
  const telegramId = ctx.from.id;
  const settings = await fb.getResellerSettings();
  const min = product.qamify?.minQty || 1;
  const max = Math.max(min, reseller.effectiveMax(product, settings));
  const qty = await reseller.getCartQty(telegramId, productId, product);
  const total = product.price * qty;

  const presets = [...new Set([min, 2, 5, 10, 25].filter(n => n >= min && n <= max))].slice(0, 4);
  const rows = [
    [
      Markup.button.callback('➖', `qtyset_${productId}_${Math.max(min, qty - 1)}`),
      Markup.button.callback(`${qty}`, 'noop'),
      Markup.button.callback('➕', `qtyset_${productId}_${Math.min(max, qty + 1)}`)
    ],
    presets.map(n => Markup.button.callback(n === qty ? `✅ ${n}` : `${n}`, `qtyset_${productId}_${n}`)),
    [Markup.button.callback('✏️ Custom Quantity', `qtycustom_${productId}`)],
    [Markup.button.callback(`✅ Continue — ₹${total}`, `qtygo_${productId}`)]
  ];

  const text = `🔢 *Select Quantity*\n\n${product.emoji ? product.emoji + ' ' : ''}*${mdEscape(sanitizeForTelegram(product.name, 200))}*\n💰 ₹${product.price} / unit\n📦 In stock: ${product.stock}\n↔️ Allowed: ${min}–${max}\n\n🧮 Quantity: *${qty}*\n💎 Total: *₹${total}*`;
  await smartReply(ctx, text, navButtons(rows, telegramId));
}

bot.action(/^qtyset_(prod_[a-z0-9]+)_(\d+)$/, async (ctx) => {
  const productId = ctx.match[1];
  const want = parseInt(ctx.match[2], 10);
  const product = await fb.getProduct(productId);
  if (!product || product.source !== 'qamify') return ctx.answerCbQuery('Product not found.');

  const settings = await fb.getResellerSettings();
  const min = product.qamify?.minQty || 1;
  const max = Math.max(min, reseller.effectiveMax(product, settings));
  const qty = Math.min(max, Math.max(min, want));
  const current = await reseller.getCartQty(ctx.from.id, productId, product);

  if (qty === current) return ctx.answerCbQuery(want !== qty ? `Limit: ${min}–${max}` : undefined);
  await reseller.setCartQty(ctx.from.id, productId, qty);
  await ctx.answerCbQuery();
  await showQtyPicker(ctx, productId, product);
});

bot.action(/^qtycustom_(prod_[a-z0-9]+)$/, async (ctx) => {
  await ctx.answerCbQuery();
  userState[ctx.from.id] = { step: 'awaiting_qty', data: { productId: ctx.match[1] } };
  await ctx.reply('🔢 Kitni quantity chahiye? Number bhejo (e.g. 7):');
});

bot.action(/^qtypick_(prod_[a-z0-9]+)$/, async (ctx) => {
  const product = await reseller.refreshProduct(ctx.match[1]);
  if (!product || product.source !== 'qamify') return ctx.answerCbQuery('Product not found.');
  await ctx.answerCbQuery();
  await showQtyPicker(ctx, ctx.match[1], product);
});

bot.action(/^qtygo_(prod_[a-z0-9]+)$/, async (ctx) => {
  const productId = ctx.match[1];
  const product = await reseller.refreshProduct(productId, 8000);
  if (!product || !product.active) return ctx.answerCbQuery('Yeh product available nahi hai.', { show_alert: true });
  const qty = await reseller.getCartQty(ctx.from.id, productId, product);
  const avail = await reseller.checkAvailability(product, qty);
  if (!avail.ok) return ctx.answerCbQuery(avail.message, { show_alert: true });
  await ctx.answerCbQuery();
  await showOrderSummary(ctx, productId, product, null);
});

// ============ ORDER SUMMARY ============

async function showOrderSummary(ctx, productId, product, appliedCoupon) {
  const telegramId = ctx.from.id;
  const balance = await fb.getWalletBalance(telegramId);
  const paymentSettings = await fb.getPaymentSettings();
  const q = await getQuote(telegramId, productId, appliedCoupon ? appliedCoupon.code : null);
  if (!q) return smartReply(ctx, '⚠️ Product not found.', backButton(ctx));

  const couponLine = q.couponUsed ? `\n🎟 Coupon \`${mdEscape(q.couponUsed)}\` applied: *-₹${q.discount}*` : '';
  const couponSuffix = couponSuffixOf(q.couponUsed);

  const rows = [
    [Markup.button.callback('💰 Pay via Wallet', `paywallet_${productId}${couponSuffix}`)],
    ...paymentMethodButtons(paymentSettings, productId, couponSuffix)
  ];
  if (q.isQamify) rows.push([Markup.button.callback('🔢 Change Quantity', `qtypick_${productId}`)]);
  if (!q.couponUsed) rows.push([Markup.button.callback('🎟 Apply Coupon', `applycoupon_${productId}`)]);
  // Reseller stock costs real money per unit, so Pro Plan (free products) doesn't apply to it.
  if (!q.isQamify) rows.push([Markup.button.callback('👑 Get Free with Pro Plan', 'menu_proplan')]);

  const priceLine = q.isQamify ? `Price: ₹${q.product.price} × ${q.qty} = ₹${q.subtotal}` : `Price: ₹${q.product.price}`;
  const text = `🧾 *Order Summary*\n\n✨ ${mdEscape(q.product.name)}\n${priceLine}${couponLine}\n\n💎 *Total: ₹${q.finalPrice}*\n💰 Wallet Balance: ₹${balance}\n\n👇 Payment method choose karo:`;

  await smartReply(ctx, text, navButtons(rows, telegramId));
}

bot.action(/^applycoupon_(.+)$/, async (ctx) => {
  const productId = ctx.match[1];
  await ctx.answerCbQuery();
  userState[ctx.from.id] = { step: 'awaiting_coupon_code', data: { productId } };
  await ctx.reply('🎟 Coupon code type karo:');
});

// ---- Pay via Wallet ----
bot.action(/^paywallet_(prod_[a-z0-9]+|PRO_PLAN)(?:_(.+))?$/, async (ctx) => {
  const productId = ctx.match[1];
  const couponCode = ctx.match[2];
  const telegramId = ctx.from.id;

  const lockKey = `wallet:${telegramId}`;
  if (payLocks.has(lockKey)) return ctx.answerCbQuery('⏳ Processing… ek second ruko.');
  payLocks.add(lockKey);

  try {
    const q = await prepareQuote(ctx, telegramId, productId, couponCode);
    if (!q) return;

    const balance = await fb.getWalletBalance(telegramId);
    if (balance < q.finalPrice) {
      await ctx.answerCbQuery();
      return smartReply(
        ctx,
        `❌ *Insufficient wallet balance*\n\n💰 Balance: ₹${balance}\n💳 Required: ₹${q.finalPrice}\n\nFamPay ya Binance se add money karo pehle.`,
        navButtons([[Markup.button.callback('➕ Add Money', 'addmoney')]], telegramId)
      );
    }

    await ctx.answerCbQuery('Processing...');

    // Order record FIRST, then debit — a crash can never take money without a record.
    const order = await createOrderFromQuote(telegramId, q, 'wallet');
    try {
      if (q.finalPrice > 0) await fb.debitWallet(telegramId, q.finalPrice, 'purchase');
    } catch (e) {
      await fb.updateOrderStatus(order.id, 'failed', { failReason: e.message });
      return smartReply(ctx, '❌ *Payment failed.*\n\nWallet balance kam hai ya kuch galat hua. Dobara try karo.', backButton(ctx));
    }
    await fb.updateOrderIf(order.id, o => o.status === 'pending', { status: 'paid', paidAt: Date.now() });

    // ---- Reseller product: fetch from Qamify and deliver ----
    if (q.isQamify) {
      await smartReply(ctx, `⏳ *Processing your order…*\n\n${mdEscape(order.productName)}\nQamify se stock nikal raha hoon, bas ek second.`, {});
      const result = await reseller.fulfil(order.id);
      const text = result.ok
        ? '✅ *Payment successful!*\n\nDelivery upar/neeche bhej di gayi hai. Baad mein bhi *My Purchases* se dobara dekh sakte ho.'
        : (result.reason === 'refunded'
          ? '↩️ *Order refund ho gaya* — details upar message mein hain.'
          : '⏳ *Order processing…*\n\nPayment mil gaya hai. Delivery automatically ho jayegi — *Order Status* mein progress dekho.');
      return smartReply(ctx, text, backButton(ctx));
    }

    // ---- Regular product ----
    if (q.couponUsed) await fb.incrementCouponUsage(q.couponUsed);
    await fb.processReferralBonus(telegramId, q.finalPrice);
    await fb.decrementStock(productId);
    await checkAndAlertLowStock(productId);

    await deliverProduct(ctx, q.product, order.id);
  } catch (err) {
    console.error('Wallet payment error:', err);
    await smartReply(ctx, '❌ *Payment failed.*\n\nPlease try again ya support se contact karo.', backButton(ctx));
  } finally {
    payLocks.delete(lockKey);
  }
});

// ---- Pay via FamPay: T&C screen ----
bot.action(/^payfampay_(prod_[a-z0-9]+|PRO_PLAN)(?:_(.+))?$/, async (ctx) => {
  const productId = ctx.match[1];
  const couponCode = ctx.match[2];
  const q = await prepareQuote(ctx, ctx.from.id, productId, couponCode);
  if (!q) return;

  await ctx.answerCbQuery();
  const paymentSettings = await fb.getPaymentSettings();
  const tcText = paymentSettings.termsAndConditions || 'Payment is final once product is delivered.';

  await smartReply(
    ctx,
    `${tcText}\n\n💳 *${mdEscape(q.product.name)}*${qtyTag(q)} — ₹${q.finalPrice}\n\nContinue to payment?`,
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ I Agree, Continue', `agreepay_${productId}${couponSuffixOf(couponCode)}`)],
      [Markup.button.callback('❌ Cancel', 'menu_home')]
    ])
  );
});

// ---- Pay via Binance (manual, screenshot review): T&C screen ----
bot.action(/^paybinance_(prod_[a-z0-9]+|PRO_PLAN)(?:_(.+))?$/, async (ctx) => {
  const productId = ctx.match[1];
  const couponCode = ctx.match[2];

  const paymentSettings = await fb.getPaymentSettings();
  if (!paymentSettings.binanceEnabled) {
    await ctx.answerCbQuery();
    return smartReply(ctx, '⚠️ Binance payment abhi available nahi hai.', backButton(ctx));
  }

  const q = await prepareQuote(ctx, ctx.from.id, productId, couponCode);
  if (!q) return;

  await ctx.answerCbQuery();
  const tcText = paymentSettings.termsAndConditions || 'Payment is final once product is delivered.';

  await smartReply(
    ctx,
    `${tcText}\n\n🟡 *${mdEscape(q.product.name)}*${qtyTag(q)} — ₹${q.finalPrice}\n\nContinue to payment?`,
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ I Agree, Continue', `agreebinance_${productId}${couponSuffixOf(couponCode)}`)],
      [Markup.button.callback('❌ Cancel', 'menu_home')]
    ])
  );
});

// ---- After T&C agreement: create order + generate FamPay QR ----
bot.action(/^agreepay_(prod_[a-z0-9]+|PRO_PLAN)(?:_(.+))?$/, async (ctx) => {
  const productId = ctx.match[1];
  const couponCode = ctx.match[2];
  const telegramId = ctx.from.id;

  const lockKey = `qr:${telegramId}`;
  if (payLocks.has(lockKey)) return ctx.answerCbQuery('⏳ QR ban raha hai… ek second ruko.');
  payLocks.add(lockKey);

  try {
    const q = await prepareQuote(ctx, telegramId, productId, couponCode);
    if (!q) return;

    await ctx.answerCbQuery('Generating QR...');
    await deleteTriggerMessage(ctx);

    const paymentSettings = await fb.getPaymentSettings();
    const qr = await fampay.generateQr(paymentSettings.upiId, q.finalPrice, paymentSettings);

    const order = await createOrderFromQuote(telegramId, q, 'fampay');

    if (!qr.success) {
      await fb.updateOrderStatus(order.id, 'failed');
      console.error('FamPay QR generation failed for order', order.id, ':', qr.error);
      return ctx.reply(
        `❌ *QR generate nahi ho paya*\n\nWajah: ${mdEscape(typeof qr.error === 'string' ? qr.error : JSON.stringify(qr.error))}\n\nThodi der baad try karo ya support se contact karo.`,
        { parse_mode: 'Markdown', ...navButtons([[Markup.button.callback('🔄 Try Again', `payfampay_${productId}${couponSuffixOf(couponCode)}`)]], telegramId) }
      );
    }

    await fb.updateOrderStatus(order.id, 'pending', { famOrderId: qr.orderId });
    userState[telegramId] = { step: 'awaiting_utr', data: { orderId: order.id } };

    const caption = `📱 *Scan & Pay* — ₹${q.finalPrice}\n\n${mdEscape(sanitizeForTelegram(order.productName, 200))}\n\n1️⃣ QR scan karke payment karo\n2️⃣ Payment ke baad UTR number is chat mein bhejo\n3️⃣ Verification ~30 sec mein ho jayega\n\n⏱ QR 10 minute mein expire ho jayega.`;

    const sentMsg = await ctx.replyWithPhoto(qr.qrImageUrl, {
      caption,
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('❌ Cancel Order', `cancelorder_${order.id}`)]
      ])
    });

    await trackPaymentMessage(order.id, sentMsg);
    await sendUpiLinkIfAny(telegramId, qr.upiLink);
    scheduleAutoCancel(order.id);
  } finally {
    payLocks.delete(lockKey);
  }
});

// ---- After T&C agreement (Binance): show pay-to details, ask for screenshot ----
bot.action(/^agreebinance_(prod_[a-z0-9]+|PRO_PLAN)(?:_(.+))?$/, async (ctx) => {
  const productId = ctx.match[1];
  const couponCode = ctx.match[2];
  const telegramId = ctx.from.id;

  const q = await prepareQuote(ctx, telegramId, productId, couponCode);
  if (!q) return;

  await ctx.answerCbQuery();
  await deleteTriggerMessage(ctx);

  const paymentSettings = await fb.getPaymentSettings();
  const usdRate = paymentSettings.usdRate || 90;
  const usdAmount = (q.finalPrice / usdRate).toFixed(2);

  const order = await createOrderFromQuote(telegramId, q, 'binance', { usdAmount, usdRate });

  userState[telegramId] = { step: 'awaiting_binance_screenshot', data: { orderId: order.id } };

  const caption = `🟡 *Pay via Binance*\n\n${mdEscape(order.productName)}\n💰 ₹${q.finalPrice} ≈ *$${usdAmount}*\n\n📤 Binance ID: \`${mdEscape(paymentSettings.binanceId || 'not set')}\`\n\n1️⃣ Upar diye Binance ID pe $${usdAmount} bhejo\n2️⃣ Payment screenshot yahin chat mein bhejo\n3️⃣ Admin review karke approve karega\n\n⏱ Order 10 minute mein expire ho jayega agar screenshot nahi bheja.`;

  const sentMsg = await ctx.reply(caption, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('❌ Cancel Order', `cancelorder_${order.id}`)]
    ])
  });

  await trackPaymentMessage(order.id, sentMsg);
  scheduleAutoCancel(order.id);
});

// ---- Cancel a pending order (also used for Binance's pending_review state) ----
bot.action(/^cancelorder_(.+)$/, async (ctx) => {
  const orderId = ctx.match[1];
  await ctx.answerCbQuery();

  const order = await fb.getOrder(orderId);
  if (order && String(order.userId) !== String(ctx.from.id) && !fb.isAdmin(ctx.from.id)) {
    return ctx.answerCbQuery('Not your order.', { show_alert: true });
  }
  if (order && order.status === 'pending' && order.famTxnId) {
    // UTR already submitted → money may be on its way; don't cancel a payment mid-verification
    return ctx.answerCbQuery('Payment verify ho raha hai, thoda wait karo.', { show_alert: true });
  }
  if (order && (order.status === 'pending' || order.status === 'pending_review')) {
    await fb.updateOrderStatus(orderId, 'failed', { cancelledByUser: true });
    if (userState[ctx.from.id]?.data?.orderId === orderId) delete userState[ctx.from.id];
    await finishPaymentMessage(order, '❌ *Order Cancelled*', ctx);
  } else {
    await smartReply(ctx, '❌ Order cancel kar diya gaya.', backButton(ctx));
  }
});

// ---- Low stock alert helper ----
async function checkAndAlertLowStock(productId) {
  const alert = await fb.checkLowStock(productId);
  if (!alert) return;

  const adminIds = (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
  for (const adminId of adminIds) {
    try {
      await bot.telegram.sendMessage(adminId, `⚠️ *Low Stock Alert*\n\n"${mdEscape(alert.productName)}" — only ${alert.stock} left!`, { parse_mode: 'Markdown' });
    } catch (e) {}
  }
}

// ============ PRODUCT DELIVERY ============

// Redeliver now takes an orderId (not productId) so it can fall back to the
// order's saved productSnapshot if the admin has since deleted the product —
// this is what makes re-download keep working after deletion.
bot.action(/^redeliver_(.+)$/, async (ctx) => {
  const orderId = ctx.match[1];
  await ctx.answerCbQuery();

  const order = await fb.getOrder(orderId);
  if (!order) return ctx.reply('⚠️ Order not found.');

  // Security: only the buyer (or an admin) can re-trigger their own delivery
  if (String(order.userId) !== String(ctx.from.id) && !fb.isAdmin(ctx.from.id)) {
    return ctx.answerCbQuery('Not your order.', { show_alert: true });
  }

  if (order.isQamify) {
    if (!order.qamifyItems || !order.qamifyItems.length) {
      return ctx.reply('⚠️ Is order ki delivery details abhi available nahi hain. Order Status check karo ya support se contact karo.');
    }
    try { await reseller.redeliver(order, ctx.from.id); }
    catch (e) { console.error('Redeliver failed:', e.message); await ctx.reply('⚠️ Details bhejne mein issue aaya. Thodi der baad try karo.'); }
    return;
  }

  const liveProduct = await fb.getProduct(order.productId);
  const product = liveProduct || {
    name: order.productName,
    ...order.productSnapshot
  };

  if (!product.deliveryType || (!product.fileId && !product.deliveryLink)) {
    return ctx.reply('⚠️ Delivery details is order ke liye available nahi hain. Support se contact karo.');
  }

  await deliverProduct(ctx, product, null, true);
});

async function deliverProduct(ctx, product, orderId, silent) {
  if (!silent) {
    // Edit the triggering message (e.g. "Processing...") to show delivery
    // status instead of stacking a new message on top of it.
    await smartReply(ctx, `✅ *Payment successful!*\n\nDelivering ${mdEscape(product.name)}...`, {});
  } else {
    await deleteTriggerMessage(ctx);
  }

  try {
    if (product.deliveryType === 'file' && product.fileId) {
      await ctx.replyWithDocument(product.fileId, {
        caption: `📦 ${product.name}\n\nThank you for your purchase! 🙏`
      });
    } else if (product.deliveryType === 'link' && product.deliveryLink) {
      // Sent as plain text (no Markdown parsing) — links often contain
      // underscores, asterisks, etc. which Telegram Markdown would otherwise
      // interpret as formatting and corrupt or hide the link entirely.
      await ctx.reply(
        `📦 ${product.name}\n\n🔗 Download Link:\n${product.deliveryLink}\n\nThank you for your purchase! 🙏`
      );
    } else {
      await ctx.reply('⚠️ Delivery content set nahi hai. Support se contact karo, jald hi resolve hoga.');
    }

    if (orderId) {
      await fb.updateOrderStatus(orderId, 'delivered', { deliveredAt: Date.now() });
    }
  } catch (err) {
    console.error('Delivery error:', err);
    await ctx.reply(
      '⚠️ *Delivery mein issue aaya.*\n\nAapka payment safe hai — support team ko turant inform kar diya gaya hai, jald hi resolve hoga.',
      { parse_mode: 'Markdown', ...backButton(ctx) }
    );

    const adminIds = (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
    for (const adminId of adminIds) {
      try {
        await bot.telegram.sendMessage(adminId, `🚨 *Delivery Failed*\n\nOrder: ${orderId || 'N/A'}\nProduct: ${mdEscape(product.name)}\nUser: ${ctx.from.id}\nError: ${mdEscape(err.message)}`, { parse_mode: 'Markdown' });
      } catch (e) {}
    }
  }
}

// ============ WALLET ============
// Full wallet screen (Home menu → 💰 Wallet, or /wallet): balance, total added,
// total spent, referral earnings, quick top-up amounts and transaction history.

async function renderWallet(ctx) {
  const telegramId = ctx.from.id;
  let user = await fb.getUser(telegramId);
  if (!user) user = await fb.createUserIfNotExists(telegramId, ctx.from, null);

  const balance = await fb.getWalletBalance(telegramId);
  const txns = await fb.getUserWalletTransactions(telegramId);
  const sum = (arr) => arr.reduce((n, t) => n + (t.amount || 0), 0);

  const credits = txns.filter(t => t.type === 'credit');
  const totalAdded = sum(credits.filter(t => t.reason === 'topup'));
  const referralEarn = sum(credits.filter(t => /referral/i.test(t.reason || '')));
  const totalSpent = sum(txns.filter(t => t.type === 'debit'));

  const msg =
    `💰 *My Wallet*\n\n` +
    `💵 Balance: *₹${balance}*\n` +
    `➕ Total Added: ₹${totalAdded}\n` +
    `🛒 Total Spent: ₹${totalSpent}\n` +
    `🤝 Referral Earnings: ₹${referralEarn}\n\n` +
    `_Quick add ke liye amount choose karo ya Add Money dabao._`;

  const markup = Markup.inlineKeyboard([
    [
      bs.styledCallback('+₹50', 'quickadd_50', 'primary'),
      bs.styledCallback('+₹100', 'quickadd_100', 'primary'),
      bs.styledCallback('+₹200', 'quickadd_200', 'primary'),
      bs.styledCallback('+₹500', 'quickadd_500', 'primary')
    ],
    [bs.styledCallback('➕ Add Money', 'addmoney', 'success')],
    [
      bs.styledCallback('🧾 Transactions', 'wallet_history', 'primary'),
      bs.styledCallback('🎁 Free Bonus', 'menu_checkin', 'success')
    ],
    [bs.styledCallback('🏠 Home', 'menu_home', 'danger')]
  ]);

  await smartReply(ctx, msg, markup);
}

bot.action('menu_wallet', async (ctx) => {
  await ctx.answerCbQuery();
  pushNav(ctx.from.id, 'menu_wallet');
  await renderWallet(ctx);
});

bot.command('wallet', async (ctx) => {
  pushNav(ctx.from.id, 'menu_wallet');
  await renderWallet(ctx);
});

bot.action('wallet_history', async (ctx) => {
  await ctx.answerCbQuery();
  const txns = (await fb.getUserWalletTransactions(ctx.from.id))
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 15);

  if (txns.length === 0) {
    return smartReply(ctx, '🧾 Abhi koi wallet transaction nahi hai.', Markup.inlineKeyboard([
      [bs.styledCallback('➕ Add Money', 'addmoney', 'success')],
      [bs.styledCallback('⬅️ Back', 'menu_wallet', 'primary'), bs.styledCallback('🏠 Home', 'menu_home', 'danger')]
    ]));
  }

  let msg = '🧾 *Wallet Transactions*\n\n';
  txns.forEach(t => {
    const d = new Date(t.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
    msg += `${t.type === 'credit' ? '🟢 +' : '🔴 -'}₹${t.amount} — ${mdEscape(String(t.reason || ''))}\n_${d}_\n\n`;
  });

  await smartReply(ctx, msg.trim(), Markup.inlineKeyboard([
    [bs.styledCallback('⬅️ Back', 'menu_wallet', 'primary'), bs.styledCallback('🏠 Home', 'menu_home', 'danger')]
  ]));
});

// Shows FamPay / Binance choices for a top-up amount
async function showTopupMethods(ctx, amount) {
  const paymentSettings = await fb.getPaymentSettings();
  const rows = [];
  if (paymentSettings.fampayEnabled !== false) {
    rows.push([Markup.button.callback('💳 Pay via FamPay', 'topupfampay_WALLET_TOPUP')]);
  }
  if (paymentSettings.binanceEnabled) {
    rows.push([Markup.button.callback('🟡 Pay via Binance', 'topupbinance_WALLET_TOPUP')]);
  }

  if (rows.length === 0) {
    return ctx.reply('⚠️ Abhi koi payment method available nahi hai. Support se contact karo.');
  }

  userState[ctx.from.id] = { step: 'awaiting_topup_method', data: { amount } };
  await ctx.reply(
    `💰 *Add ₹${amount} to Wallet*\n\n👇 Payment method choose karo:`,
    { parse_mode: 'Markdown', ...Markup.inlineKeyboard([...rows, [Markup.button.callback('❌ Cancel', 'menu_wallet')]]) }
  );
}

bot.action(/^quickadd_(\d+)$/, async (ctx) => {
  await ctx.answerCbQuery();
  const amount = parseInt(ctx.match[1]);
  if (!amount || amount < 10) return;
  delete userState[ctx.from.id];
  await showTopupMethods(ctx, amount);
});

bot.action('addmoney', async (ctx) => {
  await ctx.answerCbQuery();
  userState[ctx.from.id] = { step: 'awaiting_addmoney_amount' };
  await ctx.reply('💰 Kitna amount add karna hai? (₹ mein number bhejo, e.g. 100)\n\nMinimum: ₹10');
});

// ============ ADMIN COMMANDS ============

// ---- Admin utility: test any UPI ID's QR generation without creating a
// real order. Useful for checking a new/custom @fam handle actually
// produces a scannable QR before switching Payment Settings over to it. ----
bot.command('testupi', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;

  const parts = ctx.message.text.trim().split(/\s+/);
  const upiId = parts[1];
  const amount = parseInt(parts[2]) || 1;

  if (!upiId || !upiId.includes('@')) {
    return ctx.reply('Usage: `/testupi yourname@fam [amount]`\n\nGenerates a real QR for that UPI ID so you can test-scan it before using it in Payment Settings.', { parse_mode: 'Markdown' });
  }

  await ctx.reply(`⏳ Generating test QR for \`${mdEscape(upiId)}\`...`, { parse_mode: 'Markdown' });

  const paymentSettings = await fb.getPaymentSettings();
  const qr = await fampay.generateQr(upiId, amount, paymentSettings);

  if (!qr.success) {
    return ctx.reply(`❌ *QR generation failed*\n\nUPI ID: \`${mdEscape(upiId)}\`\nError: ${mdEscape(typeof qr.error === 'string' ? qr.error : JSON.stringify(qr.error))}\n\nIska matlab FamPay ki API ne khud is UPI ID ko reject kar diya — ye account/UPI ID ka issue hai, bot ke code ka nahi.`, { parse_mode: 'Markdown' });
  }

  await ctx.replyWithPhoto(qr.qrImageUrl, {
    caption: `🧪 *Test QR* — ₹${amount}\n\nUPI ID: \`${mdEscape(upiId)}\`\n\nCamera se QR scan karke dekho. Agar fail hota hai to ye FamPay/account ka issue hai, code ka nahi.\n\n⚠️ Ye sirf test hai — koi real order nahi bana, koi payment expect na karo.`,
    parse_mode: 'Markdown'
  });
  await sendUpiLinkIfAny(ctx.from.id, qr.upiLink);
});

bot.command('salesreport', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;

  const weekly = await fb.getSalesReport(7);
  const monthly = await fb.getSalesReport(30);

  let msg = `📊 *Sales Report*\n\n`;
  msg += `*Last 7 days:*\n💰 ₹${weekly.totalSales} — ${weekly.orderCount} orders\n`;
  if (weekly.topProducts.length) msg += `Top: ${weekly.topProducts.join(', ')}\n`;
  msg += `\n*Last 30 days:*\n💰 ₹${monthly.totalSales} — ${monthly.orderCount} orders\n`;
  if (monthly.topProducts.length) msg += `Top: ${monthly.topProducts.join(', ')}\n`;

  await ctx.reply(msg, { parse_mode: 'Markdown' });
});

bot.command('ban', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;
  const parts = ctx.message.text.split(' ');
  const targetId = parts[1];
  const reason = parts.slice(2).join(' ');

  if (!targetId) return ctx.reply('Usage: /ban <telegram_id> <reason>');

  await fb.banUser(targetId, reason);
  await ctx.reply(`🚫 User ${targetId} banned.`);
});

bot.command('unban', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;
  const targetId = ctx.message.text.split(' ')[1];

  if (!targetId) return ctx.reply('Usage: /unban <telegram_id>');

  await fb.unbanUser(targetId);
  await ctx.reply(`✅ User ${targetId} unbanned.`);
});

bot.command('msg', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;
  const parts = ctx.message.text.split(' ');
  const targetId = parts[1];
  const message = parts.slice(2).join(' ');

  if (!targetId || !message) return ctx.reply('Usage: /msg <telegram_id> <message>');

  try {
    await bot.telegram.sendMessage(targetId, `📩 *Message from Admin:*\n\n${message}`, { parse_mode: 'Markdown' });
    await ctx.reply(`✅ Message sent to ${targetId}.`);
  } catch (err) {
    await ctx.reply(`❌ Failed to send — user may have blocked the bot.`);
  }
});

// Document handler: during the admin product wizard, this saves the file
// for delivery. Otherwise (outside a wizard), admins get the raw file_id
// as a fallback utility for manual use.
bot.on('document', async (ctx) => {
  if (!fb.isAdmin(ctx.from.id)) return;

  const handled = await adminPanel.handleAdminDocument(ctx);
  if (handled) return;

  await ctx.reply(`📎 File ID:\n\`${ctx.message.document.file_id}\`\n\nUse /admin → Products → Add Product to use this in the wizard.`, { parse_mode: 'Markdown' });
});

// Photo handler: during the admin product wizard, this saves the product
// image. Otherwise, admins get the raw file_id for manual broadcast/DM use.
bot.on('photo', async (ctx) => {
  // Binance payment-proof screenshot — checked first since regular (non-admin)
  // buyers need to be able to send this.
  const state = userState[ctx.from.id];
  if (state && state.step === 'awaiting_binance_screenshot') {
    return handleBinanceScreenshot(ctx, state);
  }

  if (!fb.isAdmin(ctx.from.id)) return;

  const handled = await adminPanel.handleAdminPhoto(ctx);
  if (handled) return;

  const sizes = ctx.message.photo;
  const largest = sizes[sizes.length - 1];
  await ctx.reply(`🖼 Photo File ID:\n\`${largest.file_id}\`\n\nUse /admin → Broadcast or Direct Message to attach images with this.`, { parse_mode: 'Markdown' });
});

// ---- Binance screenshot received: mark order pending_review, notify admins ----
async function handleBinanceScreenshot(ctx, state) {
  const { orderId } = state.data;
  delete userState[ctx.from.id];

  const order = await fb.getOrder(orderId);
  if (!order) return ctx.reply('⚠️ Order not found. Support se contact karo.');
  if (order.status !== 'pending') {
    return ctx.reply('⚠️ Yeh order ab active nahi hai (expire ya cancel ho chuka hai).');
  }

  const sizes = ctx.message.photo;
  const fileId = sizes[sizes.length - 1].file_id;

  await fb.updateOrderStatus(orderId, 'pending_review', { screenshotFileId: fileId, screenshotSubmittedAt: Date.now() });
  await finishPaymentMessage(order, `⏳ *Screenshot Received*\n\n${mdEscape(order.productName)} — $${order.usdAmount}\n\nAdmin review kar raha hai, thodi der mein confirm ho jayega.`);

  const adminIds = (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
  for (const adminId of adminIds) {
    try {
      await bot.telegram.sendPhoto(adminId, fileId, {
        caption: `🟡 *New Binance Payment*\n\n📦 ${mdEscape(order.productName)}\n💰 ₹${order.amount} ($${order.usdAmount})\n👤 User: \`${order.userId}\`\n🆔 Order: \`${order.id}\``,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('✅ Approve', `admin_binapprove_${order.id}`), Markup.button.callback('❌ Reject', `admin_binreject_${order.id}`)]
        ])
      });
    } catch (e) {}
  }
}

// ============ TEXT HANDLER (for multi-step states) ============

bot.on('text', async (ctx) => {
  // Admin wizard steps take priority over the regular user-facing flows
  const adminHandled = await adminPanel.handleAdminText(ctx);
  if (adminHandled) return;

  const state = userState[ctx.from.id];
  if (!state) return; // ignore, no active flow

  if (state.step === 'awaiting_utr') {
    const utr = ctx.message.text.trim();

    if (!/^\d{6,20}$/.test(utr)) {
      return ctx.reply('⚠️ Yeh UTR number sahi nahi lag raha. UTR sirf numbers ka hota hai (usually 12 digits). Bank ke payment confirmation mein "UTR" ya "Reference No." dhundo aur wahi bhejo.');
    }

    // Same UTR can never pay for two orders
    const dup = await fb.getOrdersWhere(o => o.utr === utr && o.id !== state.data.orderId && ['pending', 'pending_review', 'paid', 'delivered'].includes(o.status));
    if (dup.length > 0) {
      return ctx.reply('⚠️ Yeh UTR pehle hi kisi order ke liye use ho chuka hai. Sahi UTR bhejo ya support se contact karo.');
    }

    delete userState[ctx.from.id];
    const order = await fb.getOrder(state.data.orderId);
    if (!order) return ctx.reply('⚠️ Order not found. Support se contact karo.');

    // Edit the QR message itself into "verifying" (instead of sending a
    // new message) so the user only ever sees ONE payment card that
    // updates in place, right through to success/failure.
    await finishPaymentMessage(order, '⏳ *Verifying...*\n\nUTR verify ho raha hai, ~30 second lagenge...');

    const paymentSettings = await fb.getPaymentSettings();
    const submission = await fampay.submitUtr({
      amount: order.amount,
      utr,
      referenceId: order.id,
      orderId: order.famOrderId
    }, paymentSettings);

    if (!submission.success) {
      await finishPaymentMessage(order, `❌ *UTR Submit Failed*\n\n${mdEscape(submission.error || 'unknown error')}\n\nSupport se contact karo.`);
      return;
    }

    await fb.updateOrderStatus(order.id, 'pending', { famTxnId: submission.txnId, utr });
    return; // the polling loop (checkAndProcessOrder) picks this up and delivers on success
  }

  if (state.step === 'awaiting_qty') {
    const n = parseInt(ctx.message.text.trim(), 10);
    const productId = state.data.productId;
    const product = await reseller.refreshProduct(productId, 8000);
    if (!product || !product.active) { delete userState[ctx.from.id]; return ctx.reply('⚠️ Yeh product ab available nahi hai.'); }
    if (!Number.isInteger(n) || n < 1) return ctx.reply('⚠️ Valid number bhejo (e.g. 5).');

    const avail = await reseller.checkAvailability(product, n);
    if (!avail.ok && (avail.code === 'below_min' || avail.code === 'above_max')) {
      return ctx.reply(`⚠️ ${avail.message}`);
    }
    delete userState[ctx.from.id];
    await reseller.setCartQty(ctx.from.id, productId, n);
    return showQtyPicker(ctx, productId, product);
  }

  if (state.step === 'awaiting_search_query') {
    delete userState[ctx.from.id];
    const query = ctx.message.text.trim();
    const results = await fb.searchProducts(query);
    const entries = Object.entries(results);

    if (entries.length === 0) {
      return ctx.reply(`🔍 Koi product "${query.slice(0, 60)}" naam se nahi mila.`);
    }

    const buttons = entries.map(([id, p]) => [Markup.button.callback(productButtonLabel(p), `viewproduct_${id}`)]);
    buttons.push([Markup.button.callback('🏠 Home', 'menu_home')]);

    await ctx.reply(`🔍 *${entries.length} result(s) for "${mdEscape(query)}"*`, { parse_mode: 'Markdown', ...Markup.inlineKeyboard(buttons) });
    return;
  }

  if (state.step === 'awaiting_review_comment') {
    delete userState[ctx.from.id];
    const { productId, rating } = state.data;
    const comment = ctx.message.text.trim().toLowerCase() === 'skip' ? '' : ctx.message.text.trim();

    await fb.addReview(productId, ctx.from.id, ctx.from.first_name, rating, comment);
    return ctx.reply('✅ Review submit ho gaya, thank you! 🙏');
  }

  if (state.step === 'awaiting_coupon_code') {
    delete userState[ctx.from.id];
    const { productId } = state.data;
    const code = ctx.message.text.trim().toUpperCase();
    const product = await fb.getProduct(productId);

    if (!product) return ctx.reply('Product not found.');

    const base = await getQuote(ctx.from.id, productId, null);
    const check = await fb.validateCoupon(code, base ? base.subtotal : product.price);
    if (!check.valid) {
      await ctx.reply(`❌ ${check.reason}`);
      return showOrderSummary(ctx, productId, product, null);
    }

    await ctx.reply(`✅ Coupon applied! Discount: ₹${check.discount}`);
    return showOrderSummary(ctx, productId, product, { code, discount: check.discount });
  }

  if (state.step === 'awaiting_addmoney_amount') {
    const amount = parseInt(ctx.message.text.trim());

    if (isNaN(amount) || amount < 10) {
      return ctx.reply('❌ Valid amount daalo (minimum ₹10).');
    }

    delete userState[ctx.from.id];
    return showTopupMethods(ctx, amount);
  }
});

// ---- Wallet top-up: method picked → show T&C → confirm ----
bot.action(/^topupfampay_WALLET_TOPUP$/, async (ctx) => {
  const state = userState[ctx.from.id];
  const amount = state?.data?.amount;
  if (!amount) return ctx.answerCbQuery('Session expired, dobara try karo.');

  await ctx.answerCbQuery();
  const paymentSettings = await fb.getPaymentSettings();
  const tcText = paymentSettings.termsAndConditions || 'Payment is final once added.';

  await smartReply(
    ctx,
    `${tcText}\n\n💰 *Add ₹${amount} to Wallet (FamPay)*\n\nContinue to payment?`,
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ I Agree, Continue', `agreetopup_${amount}`)],
      [Markup.button.callback('❌ Cancel', 'menu_home')]
    ])
  );
});

bot.action(/^topupbinance_WALLET_TOPUP$/, async (ctx) => {
  const state = userState[ctx.from.id];
  const amount = state?.data?.amount;
  if (!amount) return ctx.answerCbQuery('Session expired, dobara try karo.');

  await ctx.answerCbQuery();
  const paymentSettings = await fb.getPaymentSettings();
  if (!paymentSettings.binanceEnabled) return smartReply(ctx, '⚠️ Binance abhi available nahi hai.', backButton(ctx));
  const tcText = paymentSettings.termsAndConditions || 'Payment is final once added.';

  await smartReply(
    ctx,
    `${tcText}\n\n💰 *Add ₹${amount} to Wallet (Binance)*\n\nContinue to payment?`,
    Markup.inlineKeyboard([
      [Markup.button.callback('✅ I Agree, Continue', `agreetopupbinance_${amount}`)],
      [Markup.button.callback('❌ Cancel', 'menu_home')]
    ])
  );
});

bot.action(/^agreetopup_(\d+)$/, async (ctx) => {
  const amount = parseInt(ctx.match[1]);
  const telegramId = ctx.from.id;

  await ctx.answerCbQuery('Generating QR...');
  await deleteTriggerMessage(ctx);

  const paymentSettings = await fb.getPaymentSettings();
  const qr = await fampay.generateQr(paymentSettings.upiId, amount, paymentSettings);

  const order = await fb.createOrder({
    userId: String(telegramId),
    productId: 'WALLET_TOPUP',
    productName: 'Wallet Top-up',
    amount,
    paymentMethod: 'fampay',
    isWalletTopup: true
  });

  if (!qr.success) {
    await fb.updateOrderStatus(order.id, 'failed');
    return ctx.reply('❌ QR generate nahi ho paya. Try again.');
  }

  await fb.updateOrderStatus(order.id, 'pending', { famOrderId: qr.orderId });
  userState[telegramId] = { step: 'awaiting_utr', data: { orderId: order.id } };

  const sentMsg = await ctx.replyWithPhoto(qr.qrImageUrl, {
    caption: `📱 *Scan & Pay* — ₹${amount}\n\nWallet Top-up\n\n1️⃣ QR scan karke payment karo\n2️⃣ Payment ke baad UTR number is chat mein bhejo\n3️⃣ Verification ~30 sec mein ho jayega\n\n⏱ QR 10 minute mein expire ho jayega.`,
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('❌ Cancel Order', `cancelorder_${order.id}`)]
    ])
  });

  await trackPaymentMessage(order.id, sentMsg);
  await sendUpiLinkIfAny(telegramId, qr.upiLink);
  scheduleAutoCancel(order.id);
});

// ---- Wallet top-up via Binance (manual, screenshot review) ----
bot.action(/^agreetopupbinance_(\d+)$/, async (ctx) => {
  const amount = parseInt(ctx.match[1]);
  const telegramId = ctx.from.id;

  await ctx.answerCbQuery();
  await deleteTriggerMessage(ctx);

  const paymentSettings = await fb.getPaymentSettings();
  const usdRate = paymentSettings.usdRate || 90;
  const usdAmount = (amount / usdRate).toFixed(2);

  const order = await fb.createOrder({
    userId: String(telegramId),
    productId: 'WALLET_TOPUP',
    productName: 'Wallet Top-up',
    amount,
    paymentMethod: 'binance',
    usdAmount,
    usdRate,
    isWalletTopup: true
  });

  userState[telegramId] = { step: 'awaiting_binance_screenshot', data: { orderId: order.id } };

  const caption = `🟡 *Pay via Binance*\n\nWallet Top-up\n💰 ₹${amount} ≈ *$${usdAmount}*\n\n📤 Binance ID: \`${mdEscape(paymentSettings.binanceId || 'not set')}\`\n\n1️⃣ Upar diye Binance ID pe $${usdAmount} bhejo\n2️⃣ Payment screenshot yahin chat mein bhejo\n3️⃣ Admin review karke approve karega\n\n⏱ Order 10 minute mein expire ho jayega agar screenshot nahi bheja.`;

  const sentMsg = await ctx.reply(caption, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([[Markup.button.callback('❌ Cancel Order', `cancelorder_${order.id}`)]])
  });

  await trackPaymentMessage(order.id, sentMsg);
  scheduleAutoCancel(order.id);
});

// ============ ADMIN API — Bot Profile Management ============
// Protected by ADMIN_API_SECRET (set in Railway env vars). admin.html calls
// these endpoints to change bot name/description/photo since the Telegram
// Bot API requires the bot token, which must never be exposed to the browser.

function checkAdminApiSecret(req, res) {
  const secret = req.headers['x-admin-secret'];
  if (!secret || secret !== process.env.ADMIN_API_SECRET) {
    res.status(401).json({ success: false, error: 'Unauthorized' });
    return false;
  }
  return true;
}

app.post('/admin-api/set-bot-name', async (req, res) => {
  if (!checkAdminApiSecret(req, res)) return;
  try {
    const { name } = req.body;
    await bot.telegram.setMyName(name);
    res.json({ success: true });
  } catch (err) {
    console.error('setMyName failed:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/admin-api/set-bot-description', async (req, res) => {
  if (!checkAdminApiSecret(req, res)) return;
  try {
    const { description, shortDescription } = req.body;
    if (description) await bot.telegram.setMyDescription(description);
    if (shortDescription) await bot.telegram.setMyShortDescription(shortDescription);
    res.json({ success: true });
  } catch (err) {
    console.error('setMyDescription failed:', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// NOTE: Telegram's Bot API has no method for a bot to change its own profile
// photo — that can only be done manually via @BotFather (/setuserpic).
// This endpoint is intentionally not implemented; admin.html shows a direct
// link to BotFather instead of a broken button.

// ============ PAYMENT VERIFICATION (Express server) ============

// Checks FamPay's real order status and processes delivery if paid. Shared
// by both the webhook endpoint (in case FamPay does call it) and the
// polling loop below (the reliable path, since webhook_url isn't in
// FamPay's documented create-order fields).
async function checkAndProcessOrder(orderId) {
  const order = await fb.getOrder(orderId);
  if (!order) return { processed: false, reason: 'not_found' };
  // Only 'pending' (or an auto-expired 'failed' one whose UTR later verifies) can be settled
  if (!['pending', 'failed'].includes(order.status)) {
    return { processed: false, reason: 'already_done' };
  }
  if (!order.famTxnId) return { processed: false, reason: 'no_utr_yet' }; // UTR not submitted yet

  const paymentSettings = await fb.getPaymentSettings();
  const statusCheck = await fampay.checkVerificationStatus(order.famTxnId, paymentSettings);
  const status = statusCheck ? String(statusCheck.status).toLowerCase() : null;

  if (status === 'failed' || status === 'cancelled') {
    await fb.updateOrderStatus(orderId, 'failed');
    await finishPaymentMessage(order, `❌ *Payment ${status === 'cancelled' ? 'Cancelled' : 'Failed'}*\n\nUTR match nahi hua ya order expire ho gaya. Support se contact karo agar payment kata hai.`);
    return { processed: true, reason: status };
  }
  if (status !== 'success') {
    return { processed: false, reason: 'still_pending' }; // keep polling
  }

  // ATOMIC claim: if the poller and a webhook (or two overlapping polls) both get
  // here, exactly ONE wins — no double delivery / double wallet credit.
  const claimed = await fb.updateOrderIf(orderId, o => ['pending', 'failed'].includes(o.status), { status: 'paid', famVerifiedAt: Date.now(), paidAt: Date.now() });
  if (!claimed) return { processed: false, reason: 'already_done' };

  // Turn the "Pay Now / Cancel" message into a clean success confirmation —
  // removes the buttons so the user can't tap a stale Pay Now / Cancel after
  // payment already went through.
  await finishPaymentMessage(order, `✅ *Payment Successful!*\n\n💎 ${mdEscape(order.productName)} — ₹${order.amount}\n\nDelivering now...`);

  const freshOrder = await fb.getOrder(orderId);
  return completeOrderDelivery(freshOrder);
}

// Shared "payment confirmed, now deliver" logic — used by both the FamPay
// polling path (checkAndProcessOrder) and the Binance manual-approve path
// (admin_binapprove_ handler), so wallet top-up / Pro Plan / product
// delivery behaves identically no matter which gateway confirmed the order.
async function completeOrderDelivery(order) {
  const orderId = order.id;

  // Wallet top-up
  if (order.productId === 'WALLET_TOPUP' || order.isWalletTopup) {
    await fb.creditWallet(order.userId, order.amount, 'topup');
    await bot.telegram.sendMessage(order.userId, `✅ *₹${order.amount} added to your wallet!*\n\n💰 Naya balance check karne ke liye Wallet mein jao.`, { parse_mode: 'Markdown' });
    await fb.updateOrderStatus(orderId, 'delivered', { deliveredAt: Date.now() });
    return { processed: true, reason: 'topup_done' };
  }

  // Pro Plan subscription
  if (order.productId === 'PRO_PLAN' || order.isProPlan) {
    const duration = order.proPlanDuration || 30;
    const newExpiry = await fb.activateProPlan(order.userId, duration);
    await bot.telegram.sendMessage(
      order.userId,
      `👑 *Pro Plan Activated!*\n\n✨ Aap ab VIP hain — sab paid products FREE mein download kar sakte ho.\n\n📅 Expires: ${new Date(newExpiry).toLocaleDateString()}`,
      { parse_mode: 'Markdown' }
    );
    await fb.updateOrderStatus(orderId, 'delivered', { deliveredAt: Date.now() });
    return { processed: true, reason: 'proplan_done' };
  }

  // Reseller (Qamify) purchase: fetch from API + deliver (referral/coupon handled after real delivery)
  if (order.isQamify) {
    const r = await reseller.fulfil(order.id);
    return { processed: true, reason: r.ok ? 'delivered' : (r.reason || 'pending') };
  }

  // Regular product purchase
  const product = await fb.getProduct(order.productId);
  await fb.processReferralBonus(order.userId, order.amount);
  if (order.couponUsed) await fb.incrementCouponUsage(order.couponUsed);
  await fb.decrementStock(order.productId);
  await checkAndAlertLowStock(order.productId);

  if (product) {
    try {
      if (product.deliveryType === 'file' && product.fileId) {
        await bot.telegram.sendDocument(order.userId, product.fileId, {
          caption: `📦 *${mdEscape(product.name)}*\n\n🙏 Thank you for your purchase!`,
          parse_mode: 'Markdown'
        });
      } else if (product.deliveryType === 'link' && product.deliveryLink) {
        // Plain text (no Markdown) — links often contain underscores/asterisks
        // which Markdown parsing would otherwise corrupt or hide.
        await bot.telegram.sendMessage(
          order.userId,
          `✅ Payment successful!\n\n📦 ${product.name}\n\n🔗 Download Link:\n${product.deliveryLink}\n\n🙏 Thank you!`
        );
      }
      await fb.updateOrderStatus(orderId, 'delivered', { deliveredAt: Date.now() });
    } catch (deliveryErr) {
      console.error('Delivery error:', deliveryErr);
    }
  }

  return { processed: true, reason: 'delivered' };
}

// ---- Admin approves/rejects a Binance payment screenshot ----
bot.action(/^admin_binapprove_(.+)$/, async (ctx) => {
  if (!fb.isAdmin(ctx.from.id) && !(await fb.isStaff(ctx.from.id))) return ctx.answerCbQuery('Not authorized.');
  const orderId = ctx.match[1];
  const order = await fb.getOrder(orderId);
  if (!order) return ctx.answerCbQuery('Order not found.');
  if (order.status !== 'pending_review') {
    await ctx.answerCbQuery('Already processed.');
    try { await ctx.editMessageCaption(ctx.callbackQuery.message.caption + '\n\n_(already processed)_', { parse_mode: 'Markdown' }); } catch (e) {}
    return;
  }

  await ctx.answerCbQuery('Approving...');
  // Atomic: two admins tapping Approve can never deliver twice
  const claimedBin = await fb.updateOrderIf(orderId, o => o.status === 'pending_review', { status: 'paid', binanceVerifiedAt: Date.now(), paidAt: Date.now() });
  if (!claimedBin) return;

  try { await ctx.editMessageCaption(`✅ *Approved*\n\n${ctx.callbackQuery.message.caption}`, { parse_mode: 'Markdown' }); } catch (e) {}

  try {
    await bot.telegram.sendMessage(order.userId, `✅ *Payment Approved!*\n\n💎 ${mdEscape(order.productName)} — ₹${order.amount}\n\nDelivering now...`, { parse_mode: 'Markdown' });
  } catch (e) {}

  const freshOrder = await fb.getOrder(orderId);
  await completeOrderDelivery(freshOrder);
});

bot.action(/^admin_binreject_(.+)$/, async (ctx) => {
  if (!fb.isAdmin(ctx.from.id) && !(await fb.isStaff(ctx.from.id))) return ctx.answerCbQuery('Not authorized.');
  const orderId = ctx.match[1];
  const order = await fb.getOrder(orderId);
  if (!order) return ctx.answerCbQuery('Order not found.');
  if (order.status !== 'pending_review') {
    await ctx.answerCbQuery('Already processed.');
    return;
  }

  await ctx.answerCbQuery('Rejecting...');
  const rejected = await fb.updateOrderIf(orderId, o => o.status === 'pending_review', { status: 'failed', binanceRejectedAt: Date.now() });
  if (!rejected) return;

  try { await ctx.editMessageCaption(`❌ *Rejected*\n\n${ctx.callbackQuery.message.caption}`, { parse_mode: 'Markdown' }); } catch (e) {}

  try {
    await bot.telegram.sendMessage(order.userId, `❌ *Payment Rejected*\n\n${mdEscape(order.productName)} ka screenshot verify nahi ho paya. Support se contact karo agar payment kata hai.`, { parse_mode: 'Markdown' });
  } catch (e) {}
});

// Saves the chat/message id of the QR (or Binance instructions) message onto
// the order so it can be found and cleaned up later — from a cancel tap, the
// 10-minute auto-cancel timer, or a successful/failed verification.
async function trackPaymentMessage(orderId, sentMsg) {
  if (!sentMsg) return;
  await fb.updateOrderStatus(orderId, 'pending', {
    paymentMsgChatId: sentMsg.chat.id,
    paymentMsgId: sentMsg.message_id,
    // whether the tracked message is a photo (QR) or plain text (Binance) —
    // photo messages can't use editMessageText, only editMessageCaption
    paymentMsgIsPhoto: !!sentMsg.photo
  });
}

// Sends the raw UPI deep-link as its own plain-text follow-up message (no
// parse_mode at all) so the person can tap it to open their UPI app
// directly if the QR won't scan. This is intentionally NOT embedded in the
// QR caption or as an inline URL button: Telegram's Bot API rejects
// non-http(s)/tg URL schemes on buttons outright ("Unsupported URL
// protocol" — this previously crashed QR generation entirely for every
// UPI ID), and embedding it inside Markdown-parsed caption text risks the
// same kind of parse failure if the link ever contains an unbalanced
// Markdown special character. A plain, unparsed message is safe from both.
async function sendUpiLinkIfAny(chatId, upiLink) {
  if (!upiLink) return;
  try {
    await bot.telegram.sendMessage(chatId, `📲 Scan na ho to seedha tap karo:\n${upiLink}`);
  } catch (err) { /* non-critical — QR image is still there either way */ }
}

// Removes the QR/instructions message once an order reaches a final state
// (success, failed, or cancelled) so a stale "Pay Now / Cancel" card never
// lingers in the chat. Tries an in-place edit first (keeps the chat tidy);
// if that's not possible (message too old, or Telegram rejects editing a
// photo's text) it deletes the message and sends a fresh one instead.
// `ctx`, if passed (i.e. this was triggered by the user tapping Cancel),
// is used so we can edit the *exact* message they tapped on directly.
async function finishPaymentMessage(order, text, ctx) {
  if (ctx && ctx.callbackQuery) {
    try {
      if (ctx.callbackQuery.message.photo) {
        await ctx.editMessageCaption(text, { parse_mode: 'Markdown' });
      } else {
        await ctx.editMessageText(text, { parse_mode: 'Markdown' });
      }
      return;
    } catch (err) { /* fall through to chat/message-id based cleanup below */ }
  }

  if (order.paymentMsgChatId && order.paymentMsgId) {
    try {
      if (order.paymentMsgIsPhoto) {
        await bot.telegram.editMessageCaption(order.paymentMsgChatId, order.paymentMsgId, undefined, text, { parse_mode: 'Markdown' });
      } else {
        await bot.telegram.editMessageText(order.paymentMsgChatId, order.paymentMsgId, undefined, text, { parse_mode: 'Markdown' });
      }
      return;
    } catch (err) {
      // Message too old / already changed / can't be edited — delete it so
      // it doesn't sit there with dead buttons, then send a fresh message.
      try { await bot.telegram.deleteMessage(order.paymentMsgChatId, order.paymentMsgId); } catch (e) {}
    }
  }

  try {
    await bot.telegram.sendMessage(order.userId, text, { parse_mode: 'Markdown' });
  } catch (err) { /* user may have blocked the bot */ }
}

// Fires once, 10 minutes after order creation. If the order is still
// pending (FamPay: no UTR resolved yet) or pending_review (Binance:
// screenshot never sent / not yet reviewed), auto-cancels it and cleans
// up the QR/instructions message so it doesn't sit there forever.
function scheduleAutoCancel(orderId) {
  setTimeout(async () => {
    try {
      // Only orders with NO payment proof yet: a FamPay order with a submitted UTR is
      // still being verified, and a Binance order in 'pending_review' is waiting for an
      // admin — cancelling those would reject genuine, already-made payments.
      const cancelled = await fb.updateOrderIf(orderId, o => o.status === 'pending' && !o.famTxnId && !o.screenshotFileId, { status: 'failed', autoCancelled: true });
      if (!cancelled) return;
      const order = cancelled;
      await finishPaymentMessage(order, '⏱ *Order Expired*\n\n10 minute ke andar payment confirm nahi hua, order automatically cancel ho gaya. Dobara try karo.');
    } catch (err) {
      console.error('Auto-cancel error:', err);
    }
  }, 10 * 60 * 1000);
}

// ---- Polling loop: FamPay's documented create-order payload has no
// webhook_url field, so we can't rely on a push callback. Every 20s we
// check all pending FamPay orders from the last hour and process any that
// have completed. This is the reliable confirmation path.
let paymentPollBusy = false;
setInterval(async () => {
  if (paymentPollBusy) return; // a slow tick must never overlap the next one
  paymentPollBusy = true;
  try {
    const cutoff = Date.now() - 60 * 60 * 1000; // only check orders from the last hour
    const pending = await fb.getPendingOrdersByMethod('fampay', cutoff);

    for (const [orderId] of pending) {
      try { await checkAndProcessOrder(orderId); }
      catch (e) { console.error('Order processing error', orderId, e); }
    }

    // Safety net for restarts: the 10-min auto-cancel timers live in memory, so
    // sweep stale unpaid orders here too (only ones with NO payment proof).
    const stale = await fb.getOrdersWhere(o => o.status === 'pending' && !o.famTxnId && !o.screenshotFileId &&
      ['fampay', 'binance'].includes(o.paymentMethod) && Date.now() - (o.createdAt || 0) > 11 * 60 * 1000);
    for (const o of stale) {
      const c = await fb.updateOrderIf(o.id, x => x.status === 'pending' && !x.famTxnId && !x.screenshotFileId, { status: 'failed', autoCancelled: true });
      if (c) await finishPaymentMessage(c, '⏱ *Order Expired*\n\n10 minute ke andar payment confirm nahi hua, order automatically cancel ho gaya. Dobara try karo.');
    }
  } catch (err) {
    console.error('Payment polling error:', err);
  } finally {
    paymentPollBusy = false;
  }
}, 20000);

// Premium auto-redirect landing pages. These are OUR pages — if FamPay ever
// starts honoring a redirect field, or if you link users here manually,
// this sends them straight back into the bot instead of leaving them
// stranded on a static confirmation page.
function redirectPage({ icon, title, message, autoRedirect = true }) {
  return `<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${title}</title>
<style>
  *{box-sizing:border-box; margin:0; padding:0;}
  body{
    background:#0d1117; color:#e6edf3; font-family:'Segoe UI', system-ui, sans-serif;
    min-height:100vh; display:flex; align-items:center; justify-content:center; text-align:center; padding:24px;
  }
  .card{ max-width:380px; }
  .icon{ font-size:64px; margin-bottom:20px; }
  h1{ font-size:22px; margin-bottom:12px; }
  p{ color:#7d8b9a; font-size:14px; line-height:1.6; margin-bottom:28px; }
  a.btn{
    display:inline-block; background:#5eead4; color:#04120f; text-decoration:none;
    padding:14px 32px; border-radius:8px; font-weight:700; font-size:15px;
  }
  .spinner{ width:20px; height:20px; border:3px solid #232b36; border-top-color:#5eead4; border-radius:50%; margin:0 auto 16px; animation:spin 0.8s linear infinite; }
  @keyframes spin{ to{ transform:rotate(360deg); } }
</style>
</head>
<body>
  <div class="card">
    <div class="icon">${icon}</div>
    <h1>${title}</h1>
    <p>${message}</p>
    ${autoRedirect ? '<div class="spinner"></div><p style="margin-top:-20px; font-size:12px;">Redirecting to Telegram...</p>' : ''}
    <a class="btn" href="tg://resolve?domain=${process.env.BOT_USERNAME || ''}" id="openBot">Open Bot</a>
  </div>
  <script>
    const botUsername = ${JSON.stringify(process.env.BOT_USERNAME || '')};
    if (botUsername) {
      const link = 'https://t.me/' + botUsername;
      document.getElementById('openBot').href = link;
      ${autoRedirect ? 'setTimeout(() => { window.location.href = link; }, 1200);' : ''}
    }
  </script>
</body></html>`;
}

app.get('/payment-success', (req, res) => {
  res.send(redirectPage({
    icon: '✅',
    title: 'Payment Received!',
    message: 'Your payment is being confirmed. Your product will be delivered in the bot within a few seconds.'
  }));
});

app.get('/payment-failed', (req, res) => {
  res.send(redirectPage({
    icon: '❌',
    title: 'Payment Failed',
    message: 'Something went wrong with your payment. Please return to the bot and try again.'
  }));
});

app.get('/payment-timeout', (req, res) => {
  res.send(redirectPage({
    icon: '⏱️',
    title: 'Payment Timed Out',
    message: 'The payment session expired. Please return to the bot and try again.'
  }));
});

app.get('/', (req, res) => res.send('Bot server running ✅'));
app.get('/health', async (req, res) => {
  const s = await fb.getResellerSettings();
  res.json({
    ok: true,
    uptimeSec: Math.round(process.uptime()),
    reseller: { enabled: !!(s.enabled && s.apiKey), lastSyncAt: s.lastSyncAt || null, lastError: s.lastError || null }
  });
});

// ============ QUEUE PROCESSING (polling-based) ============
// Local JSON storage has no real-time push events like Firebase's
// child_added/child_changed — instead, we poll the broadcast/DM queues and
// the products list every few seconds and process anything new.

let broadcastBusy = false;
async function processBroadcastQueue() {
  if (broadcastBusy) return;
  broadcastBusy = true;
  try { await processBroadcastQueueInner(); } finally { broadcastBusy = false; }
}

async function processBroadcastQueueInner() {
  const queue = await fb.getBroadcastQueue();

  for (const [id, data] of Object.entries(queue)) {
    // ---- Handle unsend requests ----
    if (data.deleteRequested && !data.deleted) {
      const sentMessages = data.sentMessages || {};
      const entries = Object.entries(sentMessages);
      if (entries.length === 0) {
        await fb.updateBroadcastEntry(id, { deleted: true, deleteError: 'No message references saved' });
        continue;
      }
      let unsentCount = 0;
      for (const [uid, ref] of entries) {
        try { await bot.telegram.deleteMessage(ref.chatId, ref.messageId); unsentCount++; }
        catch (err) { /* too old (48h+) or already gone — skip */ }
        await new Promise(r => setTimeout(r, 50));
      }
      await fb.updateBroadcastEntry(id, { deleted: true, deletedAt: Date.now(), unsentCount });
      console.log(`🗑️ Broadcast unsent from ${unsentCount}/${entries.length} chats`);
      continue;
    }

    // ---- Handle new (unsent) broadcasts ----
    // `sending` is set BEFORE the (slow) send loop — otherwise the next 5s tick would
    // start the same broadcast again and every user would get it twice.
    if (data.sent || data.sending) continue;
    await fb.updateBroadcastEntry(id, { sending: true, sendingStartedAt: Date.now() });

    const users = await fb.getAllUsers();
    const userIds = Object.keys(users);

    const inlineKeyboard = [];
    if (data.buttonText && data.buttonUrl) inlineKeyboard.push([{ text: data.buttonText, url: data.buttonUrl }]);
    if (data.isPopup) inlineKeyboard.push([{ text: '❌ Close', callback_data: 'closepopup' }]);
    const extra = { parse_mode: 'Markdown' };
    if (inlineKeyboard.length > 0) extra.reply_markup = { inline_keyboard: inlineKeyboard };

    const prefix = data.isPopup ? '🔔 *Notification*' : '📢 *Announcement*';
    const fileIds = Array.isArray(data.fileIds) ? data.fileIds : [];
    const imageIds = Array.isArray(data.imageIds) ? data.imageIds : [];

    let successCount = 0;
    const sentMessages = {};

    for (const uid of userIds) {
      try {
        let sentMsg;
        if (imageIds.length > 0) {
          sentMsg = await bot.telegram.sendPhoto(uid, imageIds[0], { caption: `${prefix}\n\n${data.message}`, ...extra });
          for (const imgId of imageIds.slice(1)) {
            try { await bot.telegram.sendPhoto(uid, imgId); } catch (e) {}
          }
        } else {
          sentMsg = await bot.telegram.sendMessage(uid, `${prefix}\n\n${data.message}`, extra);
        }
        for (const fid of fileIds) {
          try { await bot.telegram.sendDocument(uid, fid); } catch (e) {}
        }
        sentMessages[uid] = { chatId: sentMsg.chat.id, messageId: sentMsg.message_id };
        successCount++;
        await fb.setUserField(uid, 'lastUnseenBroadcastId', id);
      } catch (e) { /* user blocked bot — skip */ }
      await new Promise(r => setTimeout(r, 50));
    }

    await fb.updateBroadcastEntry(id, {
      sending: false, sent: true, sentAt: Date.now(), sentCount: successCount,
      targetCount: userIds.length, seenCount: 0, sentMessages
    });
    console.log(`📢 Broadcast sent to ${successCount}/${userIds.length} users`);
  }
}

let dmBusy = false;
async function processDmQueue() {
  if (dmBusy) return;
  dmBusy = true;
  try { await processDmQueueInner(); } finally { dmBusy = false; }
}

async function processDmQueueInner() {
  const queue = await fb.getDmQueue();

  for (const [id, data] of Object.entries(queue)) {
    // ---- Handle unsend requests ----
    if (data.deleteRequested && !data.deleted) {
      if (!data.sentChatId || !data.sentMessageId) {
        await fb.updateDmEntry(id, { deleted: true, deleteError: 'No message reference saved' });
        continue;
      }
      try {
        await bot.telegram.deleteMessage(data.sentChatId, data.sentMessageId);
        await fb.updateDmEntry(id, { deleted: true, deletedAt: Date.now() });
      } catch (err) {
        await fb.updateDmEntry(id, { deleted: true, deleteError: err.message });
      }
      continue;
    }

    // ---- Handle new (unsent) DMs ----
    if (data.sent || data.sending || !data.userId || !data.message) continue;
    await fb.updateDmEntry(id, { sending: true });

    const inlineKeyboard = [];
    if (data.buttonText && data.buttonUrl) inlineKeyboard.push([{ text: data.buttonText, url: data.buttonUrl }]);
    if (data.isPopup) inlineKeyboard.push([{ text: '❌ Close', callback_data: 'closepopup' }]);
    const extra = { parse_mode: 'Markdown' };
    if (inlineKeyboard.length > 0) extra.reply_markup = { inline_keyboard: inlineKeyboard };

    try {
      const prefix = data.isPopup ? '🔔 *Notification*' : '📩 *Message from Admin:*';
      const fileIds = Array.isArray(data.fileIds) ? data.fileIds : [];
      const imageIds = Array.isArray(data.imageIds) ? data.imageIds : [];
      let sentMsg;

      if (imageIds.length > 0) {
        sentMsg = await bot.telegram.sendPhoto(data.userId, imageIds[0], { caption: `${prefix}\n\n${data.message}`, ...extra });
        for (const imgId of imageIds.slice(1)) {
          try { await bot.telegram.sendPhoto(data.userId, imgId); } catch (e) {}
        }
      } else {
        sentMsg = await bot.telegram.sendMessage(data.userId, `${prefix}\n\n${data.message}`, extra);
      }
      for (const fid of fileIds) {
        try { await bot.telegram.sendDocument(data.userId, fid); } catch (e) {}
      }

      await fb.updateDmEntry(id, {
        sent: true, sentAt: Date.now(), success: true,
        sentChatId: sentMsg.chat.id, sentMessageId: sentMsg.message_id
      });
      await fb.setUserField(data.userId, 'lastUnseenDmId', id);
    } catch (err) {
      await fb.updateDmEntry(id, { sent: true, sentAt: Date.now(), success: false, error: err.message });
    }
  }
}

async function processNewProductNotifications() {
  const products = await fb.getAllProducts(false);

  for (const [id, product] of Object.entries(products)) {
    if (!product.active || product.notifiedNewProduct) continue;
    // Only notify for products created in the last 2 minutes — protects
    // against re-notifying on bot restart for older products.
    if (!product.createdAt || Date.now() - product.createdAt > 2 * 60 * 1000) continue;

    await fb.updateProduct(id, { notifiedNewProduct: true });

    const users = await fb.getAllUsers();
    const userIds = Object.keys(users);
    const priceLabel = product.price === 0 ? 'FREE 🎁' : `₹${product.price}`;

    for (const uid of userIds) {
      try {
        await bot.telegram.sendMessage(
          uid,
          `🆕 *New Product Added!*\n\n✨ ${mdEscape(product.name)}\n💰 ${priceLabel}\n\n${mdEscape(product.description || '')}`,
          { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '👀 View Product', callback_data: `viewproduct_${id}` }]] } }
        );
      } catch (e) {}
      await new Promise(r => setTimeout(r, 50));
    }
    console.log(`🆕 New product notification sent for "${product.name}"`);
  }
}

setInterval(async () => {
  try { await processBroadcastQueue(); } catch (err) { console.error('Broadcast queue error:', err); }
}, 5000);

setInterval(async () => {
  try { await processDmQueue(); } catch (err) { console.error('DM queue error:', err); }
}, 5000);

setInterval(async () => {
  try { await processNewProductNotifications(); } catch (err) { console.error('Product notification error:', err); }
}, 10000);

// Closes a popup-style message by deleting it
bot.action('closepopup', async (ctx) => {
  await ctx.answerCbQuery();
  try { await ctx.deleteMessage(); } catch (e) {}
});

// ============ START SERVERS ============

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🌐 Webhook server running on port ${PORT}`));

// ============ GLOBAL ERROR HANDLER ============
// Without this, any unhandled error in a handler (bad data, network blip,
// etc.) fails completely silently — the user sees nothing happen at all,
// which is what caused "My Profile" to appear to do nothing. This ensures
// something is always shown, and logs the real error for debugging.

bot.catch(async (err, ctx) => {
  console.error('❌ Unhandled bot error:', err);
  try {
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('⚠️ Something went wrong, please try again.', { show_alert: true });
    }
    await ctx.reply('⚠️ Kuch galat ho gaya. Please /start dobara karo ya thodi der baad try karo.');
  } catch (e) {
    // Even the fallback failed (e.g. user blocked bot) — nothing more we can do
  }
});

// ============ RESELLER (Qamify) BACKGROUND JOBS ============
// catalog auto-sync, retry queue for queued/uncertain orders, crash recovery, balance alerts
reseller.start(bot);

// ============ AUTO BACKUP ============
// Local JSON storage is wiped on most hosts' redeploys, so every N hours the full
// data snapshot is sent to the owners' Telegram (restore it from /admin → Backup).
const AUTO_BACKUP_HOURS = Number(process.env.AUTO_BACKUP_HOURS ?? 12);
if (AUTO_BACKUP_HOURS > 0) {
  setInterval(async () => {
    try {
      const buffer = Buffer.from(JSON.stringify(fb.getFullBackup()), 'utf8');
      const owners = (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(x => x.trim()).filter(Boolean);
      for (const id of owners) {
        try {
          await bot.telegram.sendDocument(id, { source: buffer, filename: `auto_backup_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.json` },
            { caption: '💾 Automatic backup (contains secrets & customer data — keep private).' });
        } catch (e) { /* owner hasn't started the bot */ }
      }
    } catch (e) { console.error('Auto-backup failed:', e.message); }
  }, AUTO_BACKUP_HOURS * 3600 * 1000).unref();
}

bot.launch({ dropPendingUpdates: false }).then(() => console.log('🤖 Bot started successfully'));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));

// Exposed only when required as a module (tests) — never when run with `node bot.js`
if (require.main !== module) {
  module.exports = { bot, app, checkAndProcessOrder, completeOrderDelivery, userState };
}
