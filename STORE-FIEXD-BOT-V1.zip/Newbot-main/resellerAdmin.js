// ============================================================
// ADMIN → 🤝 RESELLER (Qamify) SECTION
// ============================================================
// Owner-only control panel: connection, pricing/markup, catalog sync,
// stuck-order recovery and profit reporting. Wired into adminPanel.js.
// ============================================================

const { Markup } = require('telegraf');
const reseller = require('./reseller');
const { cents } = require('./qamify');

function ago(ts) {
  if (!ts) return 'never';
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

const maskKey = (k) => (k ? `${k.slice(0, 6)}…${k.slice(-4)}` : 'not set');

function setupResellerAdmin({ bot, fb, mdEscape, adminState, isOwner }) {
  // Plain-text (no Markdown) helper for anything that may contain API-supplied text
  const plain = (t) => String(t ?? '').replace(/[\u0000-\u001f]/g, ' ');

  async function render(ctx) {
    const s = await fb.getResellerSettings();
    const prods = await fb.getQamifyProducts();
    const live = prods.filter(p => p.active).length;
    const stuck = (await reseller.getStuckOrders()).filter(o => o.fulfilment !== 'fulfilled').length;
    const ps = await fb.getPaymentSettings();
    const rate = Number(s.usdRate) || Number(ps.usdRate) || 90;

    const status = !s.apiKey ? '⚪ Not configured' : s.enabled ? '🟢 Enabled' : '🔴 Disabled';
    const markup = s.markupType === 'flat' ? `₹${s.markupValue} flat / unit` : `${s.markupValue}%`;
    const sync = s.lastSyncAt
      ? `${ago(s.lastSyncAt)}${s.lastSyncStats ? ` (+${s.lastSyncStats.added || 0} new, ${s.lastSyncStats.updated || 0} upd, ${s.lastSyncStats.disabled || 0} hidden)` : ''}`
      : 'never';

    const text =
      `🤝 *Reseller — Qamify API*\n\n` +
      `Status: ${status}\n` +
      `🔑 Key: \`${maskKey(s.apiKey)}\`\n` +
      `🌐 ${mdEscape(s.baseUrl)}\n` +
      `💵 Balance: ${s.lastBalanceCents != null ? '$' + cents(s.lastBalanceCents) : '?'} _(${ago(s.lastBalanceAt)})_\n\n` +
      `📈 Markup: ${markup}\n` +
      `💱 Rate: ₹${rate} = $1${s.usdRate ? '' : ' _(from Payment Settings)_'}\n` +
      `🔄 Auto-sync: ${s.autoSync ? `ON / ${s.syncIntervalMin}m` : 'OFF'} · last ${sync}\n` +
      `🆕 Auto-publish new: ${s.autoPublish ? 'ON' : 'OFF'}\n` +
      `📁 Category: ${mdEscape(s.defaultCategory)}\n` +
      `🔔 Low-balance alert: $${s.lowBalanceUsd} · Max qty/order: ${s.maxQtyPerOrder || 'no cap'}\n\n` +
      `📦 Products: ${prods.length} synced · ${live} live\n` +
      `🚨 Orders needing attention: ${stuck}` +
      (s.lastError ? `\n\n⚠️ Last error: ${mdEscape(plain(s.lastError).slice(0, 200))}` : '');

    const rows = [
      [Markup.button.callback(s.enabled ? '🔴 Disable Reseller' : '🟢 Enable Reseller', 'admin_qm_toggle')],
      [Markup.button.callback('🔄 Sync Now', 'admin_qm_sync'), Markup.button.callback('🧪 Test Connection', 'admin_qm_test')],
      [Markup.button.callback('🔑 Set API Key', 'admin_qm_key'), Markup.button.callback('🌐 Base URL', 'admin_qm_url')],
      [Markup.button.callback('📈 Markup', 'admin_qm_markup'), Markup.button.callback('💱 USD Rate', 'admin_qm_rate')],
      [Markup.button.callback('👁 Publish All', 'admin_qm_publishall'), Markup.button.callback('🙈 Hide All', 'admin_qm_hideall')],
      [Markup.button.callback(s.autoSync ? '⏸ Auto-sync OFF' : '▶️ Auto-sync ON', 'admin_qm_toggleauto'), Markup.button.callback('⏱ Interval', 'admin_qm_interval')],
      [Markup.button.callback(s.autoPublish ? '🆕 Auto-publish: turn OFF' : '🆕 Auto-publish: turn ON', 'admin_qm_togglepub'), Markup.button.callback('📁 Category', 'admin_qm_category')],
      [Markup.button.callback('🔔 Low-balance $', 'admin_qm_lowbal'), Markup.button.callback('🔢 Max Qty', 'admin_qm_maxqty')],
      [Markup.button.callback('🔓 Unlock Custom Prices', 'admin_qm_unlock')],
      [Markup.button.callback('📊 Profit Report', 'admin_qm_profit'), Markup.button.callback('🚨 Stuck Orders', 'admin_qm_stuck')],
      [Markup.button.callback('📜 Qamify Orders', 'admin_qm_orders'), Markup.button.callback('🧾 Sold Summary', 'admin_qm_sold')],
      [Markup.button.callback('⬅️ Back', 'admin_home')]
    ];

    const extra = { parse_mode: 'Markdown', ...Markup.inlineKeyboard(rows) };
    if (ctx.callbackQuery) {
      try { await ctx.editMessageText(text, extra); return; } catch (e) { /* unchanged / not editable */ }
    }
    await ctx.reply(text, extra);
  }

  const guard = (handler) => async (ctx) => {
    if (!(await isOwner(ctx))) return ctx.answerCbQuery('Owner only.');
    return handler(ctx);
  };

  bot.action('admin_reseller', guard(async (ctx) => { await ctx.answerCbQuery(); await render(ctx); }));

  bot.action('admin_qm_toggle', guard(async (ctx) => {
    const s = await fb.getResellerSettings();
    if (!s.enabled && !s.apiKey) return ctx.answerCbQuery('Pehle API key set karo.', { show_alert: true });
    await fb.updateResellerSettings({ enabled: !s.enabled });
    await ctx.answerCbQuery(!s.enabled ? '🟢 Enabled' : '🔴 Disabled');
    await render(ctx);
  }));

  bot.action('admin_qm_sync', guard(async (ctx) => {
    await ctx.answerCbQuery('🔄 Syncing…');
    try {
      const st = await reseller.syncCatalog();
      if (st.skipped) await ctx.reply('⏳ Sync already running.');
      else if (st.warning) await ctx.reply(`⚠️ ${st.warning}`);
      else {
        let msg = `✅ Sync done — ${st.total} products\n➕ New: ${st.added}\n✏️ Updated: ${st.updated}\n🙈 Auto-hidden: ${st.disabled}\n♻️ Restored: ${st.restored}`;
        if (st.priceChanges && st.priceChanges.length) {
          msg += `\n\n💲 Price changes (${st.priceChanges.length}):\n` + st.priceChanges.slice(0, 10).map(c => `• ${plain(c.name).slice(0, 40)}: ₹${c.from} → ₹${c.to}`).join('\n');
        }
        await ctx.reply(msg);
      }
    } catch (e) {
      await ctx.reply(`❌ Sync failed: ${plain(e.message)}`);
    }
    await render(ctx);
  }));

  bot.action('admin_qm_test', guard(async (ctx) => {
    await ctx.answerCbQuery('🧪 Testing…');
    const r = await reseller.testConnection();
    if (r.ok) {
      await ctx.reply(`✅ Connected\n\n🏪 Reseller: ${plain(r.reseller)}\n📌 Status: ${plain(r.status)}\n🧱 API build: ${plain(r.build)}\n💵 Balance: $${cents(r.balanceCents)}${r.rate ? `\n⏱ Rate limit: ${r.rate.remaining}/${r.rate.limit} left` : ''}`);
    } else {
      await ctx.reply(`❌ Connection failed\n\nCode: ${plain(r.code)}\n${plain(r.error)}`);
    }
    await render(ctx);
  }));

  // ---- simple prompt-based editors ----
  const prompts = {
    admin_qm_key: ['awaiting_qm_apikey', '🔑 Naya Qamify API key bhejo (format: shopname_ + 48 hex). Message turant delete kar diya jayega.'],
    admin_qm_url: ['awaiting_qm_baseurl', '🌐 Base URL bhejo (default: https://api.qamify.site):'],
    admin_qm_markup: ['awaiting_qm_markup', '📈 Markup bhejo:\n• `30%` → cost pe 30% extra\n• `₹15` → har unit pe flat ₹15 extra', true],
    admin_qm_rate: ['awaiting_qm_rate', '💱 ₹ kitne ka $1? (e.g. 90). `0` bhejo to Payment Settings wala rate use hoga:'],
    admin_qm_interval: ['awaiting_qm_interval', '⏱ Auto-sync interval minutes mein (1–1440, e.g. 10):'],
    admin_qm_lowbal: ['awaiting_qm_lowbal', '🔔 Low-balance alert level USD mein (e.g. 5). `0` = alert off:'],
    admin_qm_maxqty: ['awaiting_qm_maxqty', '🔢 Ek order mein max quantity (e.g. 20). `0` = sirf Qamify ka limit:'],
    admin_qm_category: ['awaiting_qm_category', '📁 Naye imported products ki default category ka naam bhejo:']
  };
  for (const [action, [step, prompt, md]] of Object.entries(prompts)) {
    bot.action(action, guard(async (ctx) => {
      await ctx.answerCbQuery();
      adminState[ctx.from.id] = { step, data: {} };
      await ctx.reply(prompt, md ? { parse_mode: 'Markdown' } : {});
    }));
  }

  bot.action('admin_qm_toggleauto', guard(async (ctx) => {
    const s = await fb.getResellerSettings();
    await fb.updateResellerSettings({ autoSync: !s.autoSync });
    await ctx.answerCbQuery(!s.autoSync ? 'Auto-sync ON' : 'Auto-sync OFF');
    await render(ctx);
  }));

  bot.action('admin_qm_togglepub', guard(async (ctx) => {
    const s = await fb.getResellerSettings();
    await fb.updateResellerSettings({ autoPublish: !s.autoPublish });
    await ctx.answerCbQuery(!s.autoPublish ? 'New products will go LIVE automatically' : 'New products stay hidden until you publish');
    await render(ctx);
  }));

  async function setAllActive(ctx, active) {
    const list = await fb.getQamifyProducts();
    let n = 0;
    for (const p of list) {
      if (active && p.autoDisabled) continue; // never publish products that vanished upstream
      if (p.active !== active) { await fb.updateProduct(p.id, { active, ignored: false }); n++; }
    }
    await ctx.answerCbQuery(`${active ? '👁 Published' : '🙈 Hidden'} ${n} product(s)`, { show_alert: true });
    await render(ctx);
  }
  bot.action('admin_qm_publishall', guard((ctx) => setAllActive(ctx, true)));
  bot.action('admin_qm_hideall', guard((ctx) => setAllActive(ctx, false)));

  bot.action('admin_qm_unlock', guard(async (ctx) => {
    const list = await fb.getQamifyProducts();
    let n = 0;
    for (const p of list) {
      const locked = p.lockedFields || [];
      if (locked.includes('price')) { await fb.updateProduct(p.id, { lockedFields: locked.filter(f => f !== 'price') }); n++; }
    }
    const changed = await reseller.repriceAll();
    await ctx.answerCbQuery(`🔓 ${n} unlocked, ${changed} repriced`, { show_alert: true });
    await render(ctx);
  }));

  bot.action('admin_qm_profit', guard(async (ctx) => {
    await ctx.answerCbQuery();
    const [d1, d7, d30] = await Promise.all([reseller.getProfitReport(1), reseller.getProfitReport(7), reseller.getProfitReport(30)]);
    const line = (label, r) => `*${label}*\n🧾 ${r.orders} orders · ${r.units} units\n💰 Revenue ₹${r.revenue} · 🏭 Cost ₹${r.costInr}\n${r.profit >= 0 ? '📈' : '📉'} Profit *₹${r.profit}*`;
    await ctx.reply(`📊 *Reseller Profit*\n\n${line('Last 24h', d1)}\n\n${line('Last 7 days', d7)}\n\n${line('Last 30 days', d30)}\n\n_Cost uses the USD rate at time of sale. Refunded/failed orders are excluded._`, {
      parse_mode: 'Markdown', ...Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', 'admin_reseller')]])
    });
  }));

  bot.action('admin_qm_stuck', guard(async (ctx) => {
    await ctx.answerCbQuery();
    const list = (await reseller.getStuckOrders()).sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)).slice(0, 8);
    if (!list.length) {
      return ctx.reply('✅ Koi stuck reseller order nahi hai.', Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', 'admin_reseller')]]));
    }
    let text = `🚨 Orders needing attention (${list.length})\n\n`;
    const rows = [];
    for (const o of list) {
      text += `• ${plain(o.productName)} — ₹${o.amount}\n  ${o.id}\n  state: ${o.fulfilment || 'pending'} · attempts ${o.fulfilAttempts || 0} · ${ago(o.createdAt)}${o.lastError ? '\n  err: ' + plain(o.lastError).slice(0, 80) : ''}\n\n`;
      rows.push([
        Markup.button.callback('🔁 Retry', `admin_qmretry_${o.id}`),
        Markup.button.callback('↩️ Refund', `admin_qmrefund_${o.id}`)
      ]);
    }
    text += 'Retry pehle Qamify se same idempotency key par reconcile karta hai (double-purchase nahi hota). Refund tabhi hota hai jab Qamify pe order exist nahi karta.';
    rows.push([Markup.button.callback('⬅️ Back', 'admin_reseller')]);
    await ctx.reply(text, Markup.inlineKeyboard(rows));
  }));

  bot.action(/^admin_qmretry_(.+)$/, guard(async (ctx) => {
    await ctx.answerCbQuery('🔁 Retrying…');
    const r = await reseller.adminRetry(ctx.match[1]);
    await ctx.reply(r.ok ? '✅ Order delivered.' : `ℹ️ Result: ${r.reason || 'pending'}${r.error ? ' — ' + plain(r.error) : ''}`);
  }));

  bot.action(/^admin_qmrefund_(.+)$/, guard(async (ctx) => {
    await ctx.answerCbQuery('↩️ Checking Qamify…');
    const r = await reseller.adminRefund(ctx.match[1]);
    if (r.ok) return ctx.reply('✅ Customer ko wallet mein refund kar diya.');
    const why = {
      was_committed_delivered: 'Qamify pe order mil gaya tha — refund ki jagah customer ko deliver kar diya ✅',
      already_fulfilled: 'Order already deliver ho chuka hai.',
      in_progress: 'Order abhi process ho raha hai, thodi der baad try karo.',
      not_refundable: 'Order refund-able state mein nahi hai.',
      cannot_verify: `Qamify verify nahi ho paya (${plain(r.error)}). Double-charge se bachne ke liye refund roka gaya — baad mein retry karo.`
    }[r.reason] || r.reason;
    await ctx.reply(`ℹ️ ${why}`);
  }));

  bot.action('admin_qm_orders', guard(async (ctx) => {
    await ctx.answerCbQuery();
    try {
      const client = await reseller.getClient();
      const list = (await client.listOrders({ limit: 10 }));
      const text = list.length
        ? '📜 Last Qamify orders\n\n' + list.map(o => `${plain(o.code)} · ${plain(o.product_name)} ×${o.qty}\n  $${plain(o.total)} · ${plain(o.status)}`).join('\n\n')
        : 'Abhi tak koi order nahi.';
      await ctx.reply(text, Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', 'admin_reseller')]]));
    } catch (e) { await ctx.reply(`❌ ${plain(e.message)}`); }
  }));

  bot.action('admin_qm_sold', guard(async (ctx) => {
    await ctx.answerCbQuery();
    try {
      const client = await reseller.getClient();
      const d = await client.getSold();
      const items = (d.items || []).slice(0, 15);
      const text = `🧾 Qamify sold summary\n\nTotal: ${d.total_qty} units · $${plain(d.total_spent)}\n\n` +
        (items.map(i => `• ${plain(i.product_name)} — ${i.qty} units / ${i.orders} orders · $${plain(i.spent)}`).join('\n') || 'No data');
      await ctx.reply(text, Markup.inlineKeyboard([[Markup.button.callback('⬅️ Back', 'admin_reseller')]]));
    } catch (e) { await ctx.reply(`❌ ${plain(e.message)}`); }
  }));

  // ---- text steps (called from adminPanel.handleAdminText) ----
  async function handleText(ctx, state, text) {
    const uid = ctx.from.id;
    const done = async (msg) => { delete adminState[uid]; await ctx.reply(msg); await render(ctx); return true; };
    const num = () => Number(String(text).replace(/[₹$,\s]/g, ''));

    switch (state.step) {
      case 'awaiting_qm_apikey': {
        try { await ctx.deleteMessage(); } catch (e) { /* can't delete in some chats */ }
        if (!/^\S{1,80}_[0-9a-fA-F]{48}$/.test(text)) {
          await ctx.reply('⚠️ Key ka format galat lag raha hai (shopname_ + 48 hex characters). Dobara bhejo ya /admin se cancel karo.');
          return true;
        }
        await fb.updateResellerSettings({ apiKey: text, lastError: null });
        delete adminState[uid];
        const r = await reseller.testConnection();
        if (r.ok) {
          await fb.updateResellerSettings({ enabled: true });
          await ctx.reply(`✅ Key saved & verified\n🏪 ${plain(r.reseller)} (${plain(r.status)})\n💵 Balance $${cents(r.balanceCents)}\n\nReseller ENABLED. "🔄 Sync Now" dabao catalog import karne ke liye.`);
        } else {
          await ctx.reply(`⚠️ Key saved, lekin connection fail: ${plain(r.code)} — ${plain(r.error)}`);
        }
        await render(ctx);
        return true;
      }
      case 'awaiting_qm_baseurl':
        if (!/^https?:\/\/[^\s]+$/i.test(text)) { await ctx.reply('⚠️ Valid URL bhejo (https://…).'); return true; }
        await fb.updateResellerSettings({ baseUrl: text.replace(/\/+$/, '') });
        return done('✅ Base URL updated.');
      case 'awaiting_qm_markup': {
        const t = text.trim();
        let type, value;
        const pm = t.match(/^(\d+(?:\.\d+)?)\s*%$/);
        const fm = t.match(/^(?:₹|rs\.?|flat)\s*(\d+(?:\.\d+)?)$/i);
        if (pm) { type = 'percent'; value = Number(pm[1]); }
        else if (fm) { type = 'flat'; value = Number(fm[1]); }
        else { await ctx.reply('⚠️ Format: `30%` ya `₹15`', { parse_mode: 'Markdown' }); return true; }
        if (value < 0 || value > 1000) { await ctx.reply('⚠️ Value 0–1000 ke beech rakho.'); return true; }
        await fb.updateResellerSettings({ markupType: type, markupValue: value });
        const changed = await reseller.repriceAll();
        return done(`✅ Markup set: ${type === 'flat' ? '₹' + value + ' flat' : value + '%'} — ${changed} product(s) repriced (custom-locked prices skip hote hain).`);
      }
      case 'awaiting_qm_rate': {
        const v = num();
        if (!Number.isFinite(v) || v < 0) { await ctx.reply('⚠️ Valid number bhejo (0 = Payment Settings ka rate).'); return true; }
        await fb.updateResellerSettings({ usdRate: v });
        const changed = await reseller.repriceAll();
        return done(`✅ Rate updated — ${changed} product(s) repriced.`);
      }
      case 'awaiting_qm_interval': {
        const v = Math.floor(num());
        if (!(v >= 1 && v <= 1440)) { await ctx.reply('⚠️ 1 se 1440 ke beech number bhejo.'); return true; }
        await fb.updateResellerSettings({ syncIntervalMin: v });
        return done(`✅ Auto-sync every ${v} min.`);
      }
      case 'awaiting_qm_lowbal': {
        const v = num();
        if (!Number.isFinite(v) || v < 0) { await ctx.reply('⚠️ Valid number bhejo.'); return true; }
        await fb.updateResellerSettings({ lowBalanceUsd: v });
        return done(`✅ Low-balance alert: $${v}.`);
      }
      case 'awaiting_qm_maxqty': {
        const v = Math.floor(num());
        if (!Number.isFinite(v) || v < 0) { await ctx.reply('⚠️ Valid number bhejo.'); return true; }
        await fb.updateResellerSettings({ maxQtyPerOrder: v });
        return done(`✅ Max qty per order: ${v || 'no bot-side cap'}.`);
      }
      case 'awaiting_qm_category':
        if (!text || text.length > 60) { await ctx.reply('⚠️ 1–60 characters ka naam bhejo.'); return true; }
        await fb.updateResellerSettings({ defaultCategory: text });
        return done('✅ Default category updated (sirf naye imports ke liye).');
      default:
        return false;
    }
  }

  return { handleText, render };
}

module.exports = { setupResellerAdmin };
