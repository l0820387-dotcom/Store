# v3.1 — Coloured buttons + Wallet + Show/Hide menu buttons

- **💰 Wallet** button on Home menu (also /wallet): balance, total added, total spent, referral earnings, quick +₹50/100/200/500 top-up, Add Money (FamPay/Binance), transaction history. Wallet is hide/show/recolour-able from admin like other buttons.
- Fix: colours now apply to every screen incl. /admin and reply keyboards (patched Telegraf's per-update Telegram object).
- **Every** button in the bot now gets a colour (fallback alternates blue/green).
- Telegram coloured inline buttons (blue / green / red) via Bot API `style`. Home menu defaults to blue/green alternating; every other screen is auto-coloured (Buy/Pay/✅ = green, Cancel/❌ = red, admin/menu = blue; Home/Back stay neutral).
- /admin → 🔘 Menu Buttons → **🎨 Button Colours**: tap any built-in button to cycle Blue → Green → Red → Default. Custom link buttons: tap to change colour.
- /admin → 🔘 Menu Buttons → **👁 Show / Hide Buttons**: hide any Home menu button (rows collapse automatically), "Show All" to restore.
- New `buttonStyle.js`; `BUTTON_COLORS=off` in .env disables colours. Needs a Telegram app that supports Bot API 9.4+ (older clients just show normal buttons).

# v3.0 — Qamify Reseller + fixes

## New: Reseller system (Qamify API v1.2)
- `qamify.js` API client (idempotency, Retry-After, error classification), `reseller.js` service, `resellerAdmin.js` panel.
- Catalog auto-sync (upsert by Qamify id), markup % / flat ₹ over USD cost, rate from Payment Settings or own.
- Quantity picker (min/max/stock/cooldown aware), live stock/price re-check before payment.
- Works with Wallet, FamPay and Binance. Auto-refund to wallet on definite failures.
- Crash-safe: idempotency key saved BEFORE the API call; lost responses reconcile via `/v1/orders/by-idempotency/:key`, never a 2nd purchase.
- Admin: /admin → 🤝 Reseller — test connection, sync, markup, publish/hide, stuck orders (retry/refund), profit report, Qamify orders/sold, low-balance alerts.

## Bugs fixed
- Double delivery/credit races (FamPay poller vs webhook, two Binance approvers) → atomic order claims.
- Orders with a submitted UTR were auto-cancelled after 10 min; users could cancel mid-verification / cancel others' orders.
- Coupon usage & referral bonus applied before delivery; wallet debited before order record.
- Overlapping poll ticks; broadcasts/DMs could be sent twice (5s tick vs slow send).
- Callback_data >64 bytes for long category names (buttons died) → hashed ids.
- Duplicate UTR reuse; double-tap purchase; ban screen left button spinner; search query Markdown injection.
- debitWallet crash on missing user; in-memory auto-cancel lost on restart (now swept by poller).

## Ops
- `DATA_DIR` for persistent volume, `AUTO_BACKUP_HOURS`, `/health`, anti-spam throttle, `npm test`.
