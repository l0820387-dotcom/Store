// ============================================================
// QAMIFY RESELLER API CLIENT  (https://api.qamify.site/docs — v1.2)
// ============================================================
// Zero dependencies (uses Node 18+ global fetch). Follows the docs' contract:
//   • Auth via Bearer key, money in integer cents, timestamps in unix seconds
//   • POST /v1/orders REQUIRES an idempotency key; a lost response is NEVER
//     recovered by buying again — always reuse the same key or look it up
//   • 429 → honour Retry-After, 5xx/503/network → "ambiguous", reconcile
// ============================================================

const IDEM_RE = /^[A-Za-z0-9_-]{8,128}$/;

class QamifyError extends Error {
  constructor({ status = 0, code = 'unknown', message = 'Qamify API error', retryAfter = null, extra = {}, ambiguous = false }) {
    super(message);
    this.name = 'QamifyError';
    this.status = status;
    this.code = code;
    this.retryAfter = retryAfter;   // seconds
    this.extra = extra;             // e.g. { min_qty, max_qty }
    this.ambiguous = ambiguous;     // true = we can't tell if the server committed
  }
}

// Maps an API error to what the caller should DO about it.
//   no_charge_final : nothing was charged, retrying won't help → refund customer
//   no_stock        : upstream out of stock → refund customer
//   reseller_balance: OUR Qamify balance too low → refund customer + alert admin
//   cooldown        : per-product order gap → retry later (nothing charged)
//   retry_later     : rate limited / lockout → retry later
//   auth            : key invalid / revoked / suspended → refund + alert admin
//   ambiguous       : unknown outcome → reconcile with SAME idempotency key
function classify(err) {
  if (!(err instanceof QamifyError)) return 'ambiguous';
  const { status, code } = err;
  if (err.ambiguous || status >= 500 || status === 0) return 'ambiguous';
  if (code === 'cooldown') return 'cooldown';
  if (code === 'rate_limited' || code === 'locked_out') return 'retry_later';
  if (status === 401 || status === 403) return 'auth';
  if (code === 'out_of_stock') return 'no_stock';
  if (code === 'insufficient_balance' || code === 'invalid_balance') return 'reseller_balance';
  if (status === 400 || status === 404 || status === 409 || status === 413) return 'no_charge_final';
  if (status === 429) return 'retry_later';
  return 'ambiguous';
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function cents(n) { return (Number(n) / 100).toFixed(2); }

function createClient({ apiKey, baseUrl = 'https://api.qamify.site', timeoutMs = 15000 } = {}) {
  if (!apiKey) throw new QamifyError({ code: 'no_api_key', message: 'Qamify API key is not configured' });
  const base = String(baseUrl).replace(/\/+$/, '');
  const client = { lastRateLimit: null };

  async function request(method, path, { body, headers = {}, query } = {}) {
    let url = base + path;
    if (query) {
      const qs = new URLSearchParams();
      for (const [k, v] of Object.entries(query)) if (v !== undefined && v !== null) qs.set(k, String(v));
      const str = qs.toString();
      if (str) url += '?' + str;
    }

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    let res;
    try {
      res = await fetch(url, {
        method,
        headers: {
          Authorization: `Bearer ${apiKey}`,
          Accept: 'application/json',
          ...(body ? { 'Content-Type': 'application/json' } : {}),
          ...headers
        },
        body: body ? JSON.stringify(body) : undefined,
        signal: ctrl.signal
      });
    } catch (e) {
      clearTimeout(timer);
      throw new QamifyError({
        code: e.name === 'AbortError' ? 'timeout' : 'network_error',
        message: e.name === 'AbortError' ? `Request timed out after ${timeoutMs}ms` : (e.cause?.code || e.message),
        ambiguous: true
      });
    }
    clearTimeout(timer);

    const rl = {
      limit: res.headers.get('x-ratelimit-limit'),
      remaining: res.headers.get('x-ratelimit-remaining'),
      reset: res.headers.get('x-ratelimit-reset')
    };
    if (rl.limit) client.lastRateLimit = { ...rl, at: Date.now() };

    let data = null;
    const text = await res.text();
    try { data = text ? JSON.parse(text) : null; } catch (_) { data = null; }

    if (!res.ok || !data || data.ok === false) {
      const e = data && data.error ? data.error : {};
      const headerRetry = parseInt(res.headers.get('retry-after'), 10);
      const retryAfter = e.retry_after_seconds ?? e.retry_after ?? (Number.isFinite(headerRetry) ? headerRetry : null);
      const { code, message, retry_after, retry_after_seconds, ...extra } = e;
      throw new QamifyError({
        status: res.status,
        code: code || (data ? 'error' : 'invalid_response'),
        message: message || `HTTP ${res.status}`,
        retryAfter,
        extra,
        // A non-JSON body or a 5xx can't prove whether a write was committed
        ambiguous: !data || res.status >= 500
      });
    }
    return { data, status: res.status };
  }

  // Idempotent GETs are safe to retry on transient failures.
  async function getWithRetry(path, opts, tries = 3) {
    let last;
    for (let i = 0; i < tries; i++) {
      try { return await request('GET', path, opts); }
      catch (e) {
        last = e;
        const kind = classify(e);
        if (kind !== 'ambiguous' && kind !== 'retry_later') throw e;
        if (i < tries - 1) await sleep(Math.min((e.retryAfter || 0) * 1000 || 400 * 2 ** i, 5000));
      }
    }
    throw last;
  }

  client.ping = async () => (await getWithRetry('/v1/ping')).data;
  client.getBalance = async () => (await getWithRetry('/v1/balance')).data;
  client.listProducts = async () => (await getWithRetry('/v1/products')).data.products || [];
  client.getProduct = async (id) => (await getWithRetry(`/v1/products/${encodeURIComponent(id)}`)).data.product;
  client.getOrder = async (code) => (await getWithRetry(`/v1/orders/${encodeURIComponent(code)}`)).data;
  client.listOrders = async ({ limit = 50, offset = 0 } = {}) => (await getWithRetry('/v1/orders', { query: { limit, offset } })).data.orders || [];
  client.getSold = async () => (await getWithRetry('/v1/sold')).data;

  // Read-only recovery. Returns null when no order exists for that key.
  client.getOrderByIdempotencyKey = async (key) => {
    if (!IDEM_RE.test(key)) throw new QamifyError({ code: 'invalid_idempotency_key', message: 'Bad idempotency key', status: 400 });
    try {
      return (await getWithRetry(`/v1/orders/by-idempotency/${encodeURIComponent(key)}`)).data;
    } catch (e) {
      if (e.status === 404 && e.code === 'order_not_found') return null;
      throw e;
    }
  };

  // Places an order. The SAME key is reused on quick transient retries — the
  // API guarantees a matching retry returns the original order (replayed:true).
  client.createOrder = async ({ productId, qty, idempotencyKey }) => {
    if (!IDEM_RE.test(idempotencyKey || '')) {
      throw new QamifyError({ code: 'invalid_idempotency_key', message: 'Idempotency key must match [A-Za-z0-9_-]{8,128}', status: 400 });
    }
    let last;
    for (let i = 0; i < 3; i++) {
      try {
        const { data, status } = await request('POST', '/v1/orders', {
          body: { product_id: Number(productId), qty: Number(qty) },
          headers: { 'Idempotency-Key': idempotencyKey }
        });
        return { ...data, httpStatus: status };
      } catch (e) {
        last = e;
        const kind = classify(e);
        if (kind !== 'ambiguous') throw e;      // definitive answers are returned to the caller
        if (i < 2) await sleep(700 * 2 ** i);   // same key → safe
      }
    }
    throw last;
  };

  return client;
}

module.exports = { createClient, QamifyError, classify, cents, IDEM_RE };
