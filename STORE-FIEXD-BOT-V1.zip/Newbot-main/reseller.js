// ============================================================
// RESELLER SERVICE (Qamify)  — sits between bot.js and qamify.js
// ============================================================
// Responsibilities
//   • Catalog sync (upsert by Qamify id) with markup → INR pricing
//   • Pre-purchase availability checks (stock, qty rules, cooldown, balance)
//   • Crash-safe fulfilment: idempotency key persisted BEFORE the API call,
//     items persisted BEFORE sending to Telegram, ambiguous results are
//     reconciled with the SAME key (never a second purchase)
//   • Auto-refund to wallet for definitive failures, admin alerts otherwise
//   • Background jobs: auto-sync, retry queue, balance/low-balance alerts
// ============================================================

const crypto = require('crypto');
const fb = require('./localdb');
const { createClient, classify, cents, QamifyError } = require('./qamify');

let bot = null;
let cachedClient = { key: '', base: '', client: null };
let syncing = false;
let resuming = false;
const fulfilling = new Set();
const alertSeen = new Map();
let balanceCache = { cents: null, at: 0 };

// ---------------- helpers ----------------

const escHtml = (t) => String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function adminIds() {
  return (process.env.ADMIN_TELEGRAM_IDS || '').split(',').map(s => s.trim()).filter(Boolean);
}

// Sends a plain-text alert to every owner. `key` de-duplicates noisy alerts.
async function alertAdmins(text, { key, cooldownMs = 0, buttons } = {}) {
  if (!bot) return;
  if (key && cooldownMs) {
    const last = alertSeen.get(key) || 0;
    if (Date.now() - last < cooldownMs) return;
    alertSeen.set(key, Date.now());
  }
  const extra = buttons ? { reply_markup: { inline_keyboard: buttons } } : {};
  for (const id of adminIds()) {
    try { await bot.telegram.sendMessage(id, text, extra); } catch (_) { /* admin blocked bot */ }
  }
}

async function safeSend(userId, text, extra = {}) {
  if (!bot) return false;
  try { await bot.telegram.sendMessage(userId, text, extra); return true; }
  catch (e) { console.error(`[reseller] could not message ${userId}:`, e.message); return false; }
}

function getClientFromSettings(s) {
  if (!s.apiKey) throw new QamifyError({ code: 'no_api_key', message: 'Qamify API key is not set (Admin → Reseller → Set API Key)', status: 401 });
  if (cachedClient.client && cachedClient.key === s.apiKey && cachedClient.base === s.baseUrl) return cachedClient.client;
  const client = createClient({ apiKey: s.apiKey, baseUrl: s.baseUrl });
  cachedClient = { key: s.apiKey, base: s.baseUrl, client };
  return client;
}

async function getClient() { return getClientFromSettings(await fb.getResellerSettings()); }

async function isEnabled() {
  const s = await fb.getResellerSettings();
  return !!(s.enabled && s.apiKey);
}

// ---------------- pricing ----------------

async function effectiveUsdRate(settings, paymentSettings) {
  const ps = paymentSettings || await fb.getPaymentSettings();
  return Number(settings.usdRate) || Number(ps.usdRate) || 90;
}

// Whole-rupee selling price. Always rounds UP so rounding never eats margin.
function computePriceInr(unitCents, settings, usdRate) {
  const base = (unitCents / 100) * usdRate;
  const v = Number(settings.markupValue) || 0;
  const raw = settings.markupType === 'flat' ? base + v : base * (1 + v / 100);
  return Math.max(1, Math.ceil(raw - 1e-9));
}

function mapUpstream(p, settings, usdRate) {
  return {
    qamifyId: p.id,
    fields: {
      name: p.name || `Product ${p.id}`,
      description: p.description || '',
      emoji: p.emoji || '',
      instructions: p.instructions || ''
    },
    priceInr: computePriceInr(p.unit_price_cents, settings, usdRate),
    meta: {
      unitCents: p.unit_price_cents,
      stock: Math.max(0, Number(p.stock) || 0),
      minQty: p.min_qty || 1,
      maxQty: p.max_qty || 0,
      unitsPerItem: p.units_per_item || 1,
      cooldownSec: p.order_cooldown_sec || 0,
      soldTotal: p.sold_total || 0,
      syncedAt: Date.now()
    }
  };
}

// Re-prices every synced product (after markup / rate change) except price-locked ones.
async function repriceAll() {
  const settings = await fb.getResellerSettings();
  const rate = await effectiveUsdRate(settings);
  const list = await fb.getQamifyProducts();
  let changed = 0;
  for (const p of list) {
    if ((p.lockedFields || []).includes('price') || !p.qamify?.unitCents) continue;
    const price = computePriceInr(p.qamify.unitCents, settings, rate);
    if (price !== p.price) { await fb.updateProduct(p.id, { price }); changed++; }
  }
  return changed;
}

// ---------------- catalog sync ----------------

async function syncCatalog() {
  if (syncing) return { skipped: true };
  syncing = true;
  try {
    const settings = await fb.getResellerSettings();
    const client = getClientFromSettings(settings);
    const rate = await effectiveUsdRate(settings);
    const list = await client.listProducts();

    const existing = await fb.getQamifyProducts();
    if (list.length === 0 && existing.length > 0) {
      // A sudden empty catalog is far more likely an upstream hiccup than reality —
      // don't mass-hide the whole shop because of it.
      const msg = 'Qamify returned 0 products — sync ignored to protect your catalog';
      await fb.updateResellerSettings({ lastError: msg });
      return { warning: msg, total: 0, added: 0, updated: 0, disabled: 0, restored: 0, priceChanges: [] };
    }

    const items = list.map(p => mapUpstream(p, settings, rate));
    const stats = await fb.upsertQamifyProducts(items, {
      autoPublish: settings.autoPublish,
      defaultCategory: settings.defaultCategory,
      seenIds: list.map(p => p.id)
    });
    await fb.updateResellerSettings({ lastSyncAt: Date.now(), lastSyncStats: { ...stats, priceChanges: stats.priceChanges.length }, lastError: null });

    if (stats.added > 0) {
      await alertAdmins(`🆕 Reseller sync: ${stats.added} naye product import hue${settings.autoPublish ? ' (live)' : ' (hidden — Admin → Reseller → Publish all, ya product-wise ON karo)'}.`, { key: 'sync_new', cooldownMs: 10 * 60 * 1000 });
    }
    if (stats.disabled > 0) {
      await alertAdmins(`⚠️ ${stats.disabled} reseller product(s) Qamify catalog se hat gaye — auto-hide kar diye.`, { key: 'sync_gone', cooldownMs: 60 * 60 * 1000 });
    }
    return stats;
  } catch (e) {
    await fb.updateResellerSettings({ lastError: `Sync failed: ${e.message}` });
    throw e;
  } finally {
    syncing = false;
  }
}

// Fresh single-product read right before a purchase (price/stock can move).
// Never blocks a sale on a failed refresh — fulfilment handles the rest.
async function refreshProduct(productId, maxAgeMs = 10000) {
  const product = await fb.getProduct(productId);
  if (!product || product.source !== 'qamify') return product;
  if (Date.now() - (product.qamify?.syncedAt || 0) < maxAgeMs) return product;

  try {
    const settings = await fb.getResellerSettings();
    const client = getClientFromSettings(settings);
    const rate = await effectiveUsdRate(settings);
    const up = await client.getProduct(product.qamifyId);
    await fb.upsertQamifyProducts([mapUpstream(up, settings, rate)], { autoPublish: settings.autoPublish, defaultCategory: settings.defaultCategory, partial: true });
  } catch (e) {
    if (e instanceof QamifyError && e.code === 'product_not_found') {
      await fb.updateProduct(productId, { stock: 0, active: false, autoDisabled: true });
    } else {
      console.error('[reseller] refreshProduct failed:', e.message);
    }
  }
  return fb.getProduct(productId);
}

// ---------------- balance ----------------

async function getBalance(force = false) {
  if (!force && balanceCache.cents !== null && Date.now() - balanceCache.at < 45000) return balanceCache.cents;
  try {
    const client = await getClient();
    const b = await client.getBalance();
    setBalance(b.balance_cents);
    await checkLowBalance(b.balance_cents);
    return b.balance_cents;
  } catch (e) {
    console.error('[reseller] balance check failed:', e.message);
    return balanceCache.cents; // last known (may be null)
  }
}

function setBalance(c) {
  if (typeof c !== 'number') return;
  balanceCache = { cents: c, at: Date.now() };
  fb.updateResellerSettings({ lastBalanceCents: c, lastBalanceAt: Date.now() }).catch(() => {});
}

async function checkLowBalance(balanceCents) {
  const s = await fb.getResellerSettings();
  if (s.lowBalanceUsd && balanceCents < s.lowBalanceUsd * 100) {
    await alertAdmins(`⚠️ Qamify balance low: $${cents(balanceCents)} (alert level $${s.lowBalanceUsd}). Top-up karo, warna reseller orders fail/refund honge.`, { key: 'low_balance', cooldownMs: 6 * 60 * 60 * 1000 });
  }
}

// ---------------- availability / cart ----------------

// Effective max the customer can order right now.
function effectiveMax(product, settings) {
  const q = product.qamify || {};
  const caps = [];
  if (q.maxQty > 0) caps.push(q.maxQty);
  if (settings.maxQtyPerOrder > 0) caps.push(settings.maxQtyPerOrder);
  if (typeof product.stock === 'number' && product.stock >= 0) caps.push(product.stock);
  return caps.length ? Math.min(...caps) : 999;
}

async function checkAvailability(product, qty = 1) {
  const settings = await fb.getResellerSettings();
  const q = product.qamify || {};
  if (!settings.enabled || !settings.apiKey) return { ok: false, code: 'disabled', message: 'Yeh product abhi available nahi hai.' };
  if (!product.active) return { ok: false, code: 'inactive', message: 'Yeh product abhi available nahi hai.' };
  if (!(product.stock > 0)) return { ok: false, code: 'out_of_stock', message: 'Yeh product abhi out of stock hai.' };

  const min = q.minQty || 1;
  const max = effectiveMax(product, settings);
  if (qty < min) return { ok: false, code: 'below_min', message: `Minimum quantity ${min} hai.`, min, max };
  if (qty > max) return { ok: false, code: 'above_max', message: `Maximum quantity ${max} hai (stock/limit).`, min, max };

  if (q.cooldownSec > 0 && product.qamifyLastOrderAt) {
    const waitMs = product.qamifyLastOrderAt + q.cooldownSec * 1000 - Date.now();
    if (waitMs > 0) {
      const mins = Math.ceil(waitMs / 60000);
      return { ok: false, code: 'cooldown', message: `Is product ka next order ~${mins} min baad possible hai. Thodi der baad try karo.`, waitSec: Math.ceil(waitMs / 1000), min, max };
    }
  }

  const need = (q.unitCents || 0) * qty;
  const bal = await getBalance();
  if (bal !== null && bal < need) {
    return { ok: false, code: 'reseller_balance', message: 'Yeh product abhi temporarily unavailable hai. Thodi der baad try karo.', min, max };
  }
  return { ok: true, min, max };
}

async function getCartQty(telegramId, productId, product) {
  const settings = await fb.getResellerSettings();
  const cart = await fb.getUserField(telegramId, 'cartQty');
  const min = product?.qamify?.minQty || 1;
  let qty = cart && cart.productId === productId ? cart.qty : min;
  qty = Math.max(min, Math.floor(Number(qty) || min));
  const max = product ? effectiveMax(product, settings) : qty;
  return Math.max(1, Math.min(qty, max > 0 ? max : qty));
}

async function setCartQty(telegramId, productId, qty) {
  await fb.setUserField(telegramId, 'cartQty', { productId, qty: Math.floor(qty), at: Date.now() });
}

// Extra fields merged into the order record when a reseller product is bought.
function buildOrderFields(productId, product, qty) {
  return {
    isQamify: true,
    qty,
    unitPrice: product.price,
    qamifyProductId: product.qamifyId,
    // Persisted with the order BEFORE any API call: the ONLY way to safely
    // recover from a lost response is to reuse this exact key.
    idemKey: 'tg' + Date.now().toString(36) + crypto.randomBytes(8).toString('hex'),
    fulfilment: 'pending',
    fulfilAttempts: 0,
    displayName: qty > 1 ? `${product.name} ×${qty}` : product.name
  };
}

// ---------------- delivery to the customer ----------------

function packBlocks(blocks, limit = 3600) {
  const msgs = [];
  let cur = '';
  for (const b of blocks) {
    if (cur && (cur.length + b.length + 1) > limit) { msgs.push(cur); cur = ''; }
    cur += (cur ? '\n' : '') + b;
  }
  if (cur) msgs.push(cur);
  return msgs;
}

// Sends stored credentials + instructions. Throws if Telegram refuses.
async function sendDelivery(userId, order) {
  const items = order.qamifyItems || [];
  const name = order.productName || order.displayName || 'Order';
  const header = `✅ <b>Order Delivered</b>\n\n📦 ${escHtml(name)}\n🧾 Order: <code>${escHtml(order.qamifyCode || order.id)}</code>\n`;

  const tooBig = items.some(i => String(i).length > 3400) || items.length > 15 || items.join('').length > 12000;
  if (tooBig) {
    const body = items.map((c, i) => `#${i + 1}\n${c}`).join('\n\n----------------\n\n');
    await bot.telegram.sendMessage(userId, header + `\n📎 ${items.length} item(s) neeche file mein hain (tap-to-copy ke liye file kholo).`, { parse_mode: 'HTML' });
    await bot.telegram.sendDocument(userId, { source: Buffer.from(body, 'utf8'), filename: `order_${order.qamifyCode || order.id}.txt` });
  } else {
    const blocks = items.map(c => `<pre>${escHtml(c)}</pre>`);
    const msgs = packBlocks(blocks);
    if (msgs.length === 0) msgs.push('');
    await bot.telegram.sendMessage(userId, header + '\n🔑 <b>Credentials</b> (tap karke copy karo)\n' + msgs[0], { parse_mode: 'HTML' });
    for (const m of msgs.slice(1)) await bot.telegram.sendMessage(userId, m, { parse_mode: 'HTML' });
  }

  const ins = (order.qamifyInstructions || '').trim();
  if (ins) {
    const chunks = [];
    for (let i = 0; i < ins.length; i += 3500) chunks.push(ins.slice(i, i + 3500));
    for (let i = 0; i < chunks.length; i++) {
      await bot.telegram.sendMessage(userId, (i === 0 ? '⚠️ <b>Instructions &amp; Terms</b>\n\n' : '') + escHtml(chunks[i]), { parse_mode: 'HTML' });
    }
  }
  await bot.telegram.sendMessage(userId, '🙏 Thank you for your purchase!');
}

// ---------------- fulfilment ----------------

async function refundOrder(orderId, reason, userMessage) {
  const upd = await fb.updateOrderIf(
    orderId,
    o => o.status === 'paid' && !['done', 'fulfilled', 'refunded'].includes(o.fulfilment),
    { status: 'refunded', fulfilment: 'refunded', refundReason: reason, refundedAt: Date.now(), refundCredited: false }
  );
  if (!upd) return null;

  if (upd.amount > 0) await fb.creditWallet(upd.userId, upd.amount, 'refund');
  await fb.updateOrder(orderId, { refundCredited: true });

  await safeSend(upd.userId, userMessage || `↩️ *Order refund*\n\n${upd.productName} deliver nahi ho paya.\n💰 ₹${upd.amount} aapke wallet mein wapas add kar diya gaya hai.`, { parse_mode: 'Markdown' });
  return upd;
}

async function markNeedsReview(order, why) {
  await fb.updateOrder(order.id, { fulfilment: 'needs_review', lastError: why });
  await alertAdmins(
    `🚨 Reseller order needs review\n\nOrder: ${order.id}\nUser: ${order.userId}\nProduct: ${order.productName} (₹${order.amount})\nIdem key: ${order.idemKey}\nReason: ${why}\n\nRetry same key ya refund choose karo (dono safe — retry pehle Qamify se reconcile karta hai).`,
    { buttons: [[{ text: '🔁 Retry', callback_data: `admin_qmretry_${order.id}` }, { text: '↩️ Refund', callback_data: `admin_qmrefund_${order.id}` }]] }
  );
}

async function completeSuccess(order, result) {
  const o = result.order || result;
  const items = (o.items || []).map(i => (typeof i === 'string' ? i : i.content)).filter(v => v !== undefined && v !== null);

  if (!items.length) {
    // Charged upstream but no items in the response — do NOT refund or retry blindly.
    await fb.updateOrder(order.id, { qamifyCode: o.code || null, costCents: o.total_cents ?? null });
    await markNeedsReview(order, `Qamify order ${o.code || '?'} returned no items`);
    return { ok: false, reason: 'no_items' };
  }

  const settings = await fb.getResellerSettings();
  const rate = await effectiveUsdRate(settings);

  // Persist credentials FIRST — a Telegram failure must never lose paid-for items.
  const saved = await fb.updateOrderIf(order.id, o => o.status === 'paid', {
    fulfilment: 'fulfilled',
    qamifyCode: o.code,
    qamifyItems: items,
    qamifyInstructions: o.instructions || '',
    costCents: o.total_cents ?? (o.unit_price_cents || 0) * order.qty,
    usdRateUsed: rate,
    fulfilledAt: Date.now(),
    replayed: !!o.replayed
  });

  if (!saved) {
    // Order was refunded/changed while the API call was in flight — money moved upstream.
    await alertAdmins(`🚨 Order ${order.id} refund/cancel ho chuka tha lekin Qamify ne charge kar diya (code ${o.code}, ${items.length} item). Manual check karo.`);
    return { ok: false, reason: 'state_conflict' };
  }

  if (typeof result.balance_cents === 'number') { setBalance(result.balance_cents); checkLowBalance(result.balance_cents).catch(() => {}); }
  await fb.updateProduct('prod_qm' + order.qamifyProductId, { qamifyLastOrderAt: Date.now() });
  await fb.adjustStock('prod_qm' + order.qamifyProductId, -order.qty);

  return deliverSaved(saved);
}

async function deliverSaved(order) {
  try {
    await sendDelivery(order.userId, order);
  } catch (e) {
    const attempts = (order.sendAttempts || 0) + 1;
    console.error(`[reseller] delivery send failed for ${order.id} (attempt ${attempts}):`, e.message);
    if (attempts >= 6) {
      await fb.updateOrder(order.id, { status: 'delivered', fulfilment: 'done', deliveredAt: Date.now(), deliveryNote: 'send_failed_user_unreachable', sendAttempts: attempts });
      await alertAdmins(`⚠️ Order ${order.id} (${order.qamifyCode}) ka delivery user ${order.userId} ko send nahi ho paya. Items order record mein saved hain.`);
    } else {
      await fb.updateOrder(order.id, { sendAttempts: attempts, nextSendAt: Date.now() + 30000 * attempts });
    }
    return { ok: false, reason: 'send_failed' };
  }

  await fb.updateOrder(order.id, { status: 'delivered', fulfilment: 'done', deliveredAt: Date.now() });
  await finalizePurchase(order.id);
  return { ok: true };
}

// Referral bonus + coupon usage — exactly once, only after a real delivery.
async function finalizePurchase(orderId) {
  const claimed = await fb.updateOrderIf(orderId, o => !o.finalized, { finalized: true });
  if (!claimed) return;
  try {
    if (claimed.amount > 0) await fb.processReferralBonus(claimed.userId, claimed.amount);
    if (claimed.couponUsed) await fb.incrementCouponUsage(claimed.couponUsed);
  } catch (e) { console.error('[reseller] finalizePurchase error:', e.message); }
}

async function handleFailure(order, err) {
  const kind = classify(err);
  const settings = await fb.getResellerSettings();
  const attempts = order.fulfilAttempts || 1;
  const code = err.code || 'unknown';
  console.error(`[reseller] order ${order.id} attempt ${attempts} failed: ${kind}/${code} — ${err.message}`);

  if (kind === 'cooldown' || kind === 'retry_later') {
    const wait = Math.max(5, err.retryAfter || 30);
    if (kind === 'cooldown' && wait > 900) {
      return refundWith(order, 'cooldown_too_long', `⏳ Yeh product abhi order nahi ho sakta (wait ~${Math.ceil(wait / 60)} min). Aapka ₹${order.amount} wallet mein refund kar diya gaya hai — baad mein dobara try karo.`);
    }
    if (attempts >= 10) { await markNeedsReview(order, `Still ${code} after ${attempts} attempts`); return { ok: false, reason: 'needs_review' }; }
    await fb.updateOrder(order.id, { fulfilment: 'queued', nextAttemptAt: Date.now() + wait * 1000 + 2000, lastError: code });
    if (attempts === 1) {
      await safeSend(order.userId, `⏳ *Order queued*\n\n${order.productName}\nAapka payment mil gaya hai. Delivery ~${Math.max(1, Math.ceil(wait / 60))} min mein automatically ho jayegi — kuch karne ki zarurat nahi.`, { parse_mode: 'Markdown' });
    }
    return { ok: false, reason: 'queued' };
  }

  if (kind === 'ambiguous') {
    if (attempts >= 10) { await markNeedsReview(order, `Unresolved after ${attempts} attempts (${code})`); return { ok: false, reason: 'needs_review' }; }
    const backoff = Math.min(30000 * 2 ** (attempts - 1), 5 * 60000);
    await fb.updateOrder(order.id, { fulfilment: 'uncertain', wasUncertain: true, nextAttemptAt: Date.now() + backoff, lastError: code });
    if (attempts === 1) {
      await safeSend(order.userId, `⏳ *Order processing*\n\n${order.productName}\nPayment mil gaya hai, delivery confirm ho rahi hai. Thoda wait karo — automatically aa jayega.`, { parse_mode: 'Markdown' });
    }
    return { ok: false, reason: 'uncertain' };
  }

  if (kind === 'auth') {
    await fb.updateResellerSettings({ lastError: `Auth problem: ${code}` });
    await alertAdmins(`🚨 Qamify API key problem (${code}): ${err.message}\nReseller orders refund ho rahe hain. Key/suspension check karo.`, { key: 'auth_fail', cooldownMs: 30 * 60 * 1000 });
    return refundWith(order, code, `❌ *Order fail ho gaya*\n\n${order.productName} abhi deliver nahi ho sakta.\n💰 ₹${order.amount} wallet mein refund ho gaya hai.`);
  }

  if (kind === 'reseller_balance') {
    await alertAdmins(`🚨 Qamify balance kam hai — customer order (${order.productName} ×${order.qty}) fail hua aur refund ho gaya. Top-up karo!`, { key: 'balance_fail', cooldownMs: 30 * 60 * 1000 });
    return refundWith(order, code, `❌ *Product temporarily unavailable*\n\n${order.productName} abhi deliver nahi ho paya.\n💰 ₹${order.amount} wallet mein refund ho gaya hai. Thodi der baad try karo.`);
  }

  if (kind === 'no_stock') {
    syncCatalog().catch(() => {});
    return refundWith(order, code, `❌ *Out of stock*\n\n${order.productName} abhi stock mein nahi raha.\n💰 ₹${order.amount} wallet mein refund ho gaya hai.`);
  }

  // no_charge_final: qty_out_of_range, product_not_found, pricing_error, …
  syncCatalog().catch(() => {});
  await alertAdmins(`⚠️ Reseller order ${order.id} rejected by Qamify: ${code} — ${err.message}. Customer ko refund kar diya.`, { key: 'reject_' + code, cooldownMs: 10 * 60 * 1000 });
  return refundWith(order, code, `❌ *Order fail ho gaya*\n\n${order.productName} abhi deliver nahi ho paya.\n💰 ₹${order.amount} wallet mein refund ho gaya hai.`);
}

async function refundWith(order, reason, message) {
  const r = await refundOrder(order.id, reason, message);
  return { ok: false, reason: 'refunded', refunded: !!r };
}

// Public entry point. Safe to call repeatedly / concurrently for the same order.
async function fulfil(orderId) {
  if (fulfilling.has(orderId)) return { ok: false, reason: 'in_progress' };
  fulfilling.add(orderId);
  try {
    const claimed = await fb.updateOrderIf(
      orderId,
      o => o.isQamify && o.status === 'paid' && ['pending', 'queued', 'uncertain', undefined].includes(o.fulfilment),
      o => ({
        fulfilment: 'processing',
        processingSince: Date.now(),
        fulfilAttempts: (o.fulfilAttempts || 0) + 1,
        wasUncertain: !!o.wasUncertain || o.fulfilment === 'uncertain'
      })
    );
    if (!claimed) return { ok: false, reason: 'not_claimable' };

    try {
      const client = await getClient();
      let result = null;
      // After any uncertain outcome, reconcile via the read-only lookup first.
      if (claimed.wasUncertain || claimed.fulfilAttempts > 1) {
        result = await client.getOrderByIdempotencyKey(claimed.idemKey);
      }
      if (!result) {
        result = await client.createOrder({ productId: claimed.qamifyProductId, qty: claimed.qty, idempotencyKey: claimed.idemKey });
      }
      return await completeSuccess(claimed, result);
    } catch (err) {
      return await handleFailure(claimed, err);
    }
  } catch (e) {
    console.error('[reseller] fulfil crashed:', e);
    // Unknown state → treat as uncertain so the retry loop reconciles it.
    await fb.updateOrderIf(orderId, o => o.fulfilment === 'processing', { fulfilment: 'uncertain', wasUncertain: true, nextAttemptAt: Date.now() + 30000 }).catch(() => {});
    return { ok: false, reason: 'exception' };
  } finally {
    fulfilling.delete(orderId);
  }
}

// Re-send stored credentials for a past order (Purchases → tap).
async function redeliver(order, toUserId) {
  if (!order.qamifyItems || !order.qamifyItems.length) throw new Error('No stored items for this order');
  await sendDelivery(toUserId || order.userId, order);
}

// ----- admin actions -----

async function adminRetry(orderId) {
  const upd = await fb.updateOrderIf(
    orderId,
    o => o.isQamify && o.status === 'paid' && ['needs_review', 'queued', 'uncertain', 'pending'].includes(o.fulfilment),
    { fulfilment: 'uncertain', wasUncertain: true, fulfilAttempts: 0, nextAttemptAt: 0 }
  );
  if (!upd) return { ok: false, reason: 'not_retryable' };
  return fulfil(orderId);
}

// Refund only after confirming Qamify did NOT commit this order.
async function adminRefund(orderId) {
  const order = await fb.getOrder(orderId);
  if (!order || !order.isQamify) return { ok: false, reason: 'not_found' };
  if (order.status !== 'paid') return { ok: false, reason: 'not_refundable' };
  if (['done', 'fulfilled'].includes(order.fulfilment)) return { ok: false, reason: 'already_fulfilled' };
  if (order.fulfilment === 'processing' || fulfilling.has(orderId)) return { ok: false, reason: 'in_progress' };

  try {
    const client = await getClient();
    const found = await client.getOrderByIdempotencyKey(order.idemKey);
    if (found) {
      // Qamify DID charge us — complete the delivery instead of refunding.
      const claimed = await fb.updateOrderIf(orderId, o => ['needs_review', 'queued', 'uncertain', 'pending'].includes(o.fulfilment), { fulfilment: 'processing', processingSince: Date.now() });
      if (claimed) await completeSuccess(claimed, found);
      return { ok: false, reason: 'was_committed_delivered' };
    }
  } catch (e) {
    return { ok: false, reason: 'cannot_verify', error: e.message };
  }
  const r = await refundOrder(orderId, 'admin_refund');
  return r ? { ok: true } : { ok: false, reason: 'not_refundable' };
}

// ---------------- reporting ----------------

async function getProfitReport(days = 30) {
  const cutoff = Date.now() - days * 86400000;
  const orders = await fb.getOrdersWhere(o => o.isQamify && o.status === 'delivered' && (o.createdAt || 0) >= cutoff);
  let revenue = 0, costInr = 0, units = 0;
  for (const o of orders) {
    revenue += o.amount || 0;
    units += o.qty || 1;
    if (typeof o.costCents === 'number') costInr += (o.costCents / 100) * (o.usdRateUsed || 90);
  }
  return { days, orders: orders.length, units, revenue, costInr: Math.round(costInr), profit: Math.round(revenue - costInr) };
}

async function getStuckOrders() {
  return fb.getOrdersWhere(o => o.isQamify && o.status === 'paid' && ['needs_review', 'uncertain', 'queued', 'processing', 'fulfilled', 'pending'].includes(o.fulfilment || 'pending'));
}

async function testConnection() {
  try {
    const client = await getClient();
    const ping = await client.ping();
    const bal = await client.getBalance();
    setBalance(bal.balance_cents);
    return { ok: true, reseller: ping.reseller, status: ping.status, build: ping.build, balanceCents: bal.balance_cents, rate: client.lastRateLimit };
  } catch (e) {
    return { ok: false, code: e.code || 'error', error: e.message };
  }
}

// ---------------- background jobs ----------------

async function recoverOnBoot() {
  // Anything mid-flight when the process died has an UNKNOWN outcome.
  const stuck = await fb.getOrdersWhere(o => o.isQamify && o.fulfilment === 'processing');
  for (const o of stuck) {
    await fb.updateOrder(o.id, { fulfilment: 'uncertain', wasUncertain: true, nextAttemptAt: 0 });
  }
  if (stuck.length) console.log(`[reseller] recovered ${stuck.length} in-flight order(s) → will reconcile by idempotency key`);
}

async function resumeTick() {
  if (resuming) return;
  resuming = true;
  try {
    const now = Date.now();
    const list = await fb.getOrdersWhere(o => o.isQamify);
    for (const o of list) {
      if (o.status === 'refunded' && o.refundCredited === false) {
        if (o.amount > 0) await fb.creditWallet(o.userId, o.amount, 'refund');
        await fb.updateOrder(o.id, { refundCredited: true });
        continue;
      }
      if (o.status !== 'paid') continue;
      const f = o.fulfilment || 'pending';
      if (f === 'pending' && now - (o.paidAt || o.createdAt || 0) > 60000) await fulfil(o.id);
      else if ((f === 'queued' || f === 'uncertain') && (o.nextAttemptAt || 0) <= now) await fulfil(o.id);
      else if (f === 'processing' && now - (o.processingSince || 0) > 3 * 60000) {
        await fb.updateOrderIf(o.id, x => x.fulfilment === 'processing', { fulfilment: 'uncertain', wasUncertain: true, nextAttemptAt: 0 });
      } else if (f === 'fulfilled' && (o.nextSendAt || 0) <= now) await deliverSaved(o);
    }
  } catch (e) {
    console.error('[reseller] resume tick error:', e);
  } finally { resuming = false; }
}

async function syncTick() {
  try {
    const s = await fb.getResellerSettings();
    if (!s.enabled || !s.apiKey || !s.autoSync) return;
    if (Date.now() - (s.lastSyncAt || 0) >= Math.max(1, s.syncIntervalMin) * 60000) await syncCatalog();
  } catch (e) { console.error('[reseller] auto-sync failed:', e.message); }
}

function start(botInstance) {
  bot = botInstance;
  recoverOnBoot().catch(e => console.error('[reseller] recover error:', e));
  setInterval(resumeTick, 15000);
  setInterval(syncTick, 60000);
  setInterval(() => { isEnabled().then(on => on && getBalance(true)).catch(() => {}); }, 5 * 60000);
  setTimeout(syncTick, 5000);
}

module.exports = {
  start, isEnabled, getClient, testConnection, syncCatalog, refreshProduct, repriceAll,
  getBalance, checkAvailability, effectiveMax, getCartQty, setCartQty,
  buildOrderFields, fulfil, redeliver, refundOrder, adminRetry, adminRefund,
  getProfitReport, getStuckOrders, computePriceInr, effectiveUsdRate, escHtml,
  _test: { classify, completeSuccess, handleFailure }
};
